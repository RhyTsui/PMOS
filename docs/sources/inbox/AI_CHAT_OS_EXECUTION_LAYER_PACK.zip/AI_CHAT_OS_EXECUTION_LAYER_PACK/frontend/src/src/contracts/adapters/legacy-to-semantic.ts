import type { SemanticResultContract, SemanticRegion } from '../semantic/semantic-result-contract';
import type { ActionContract } from '../semantic/action-contract';
import type { EvidenceRef } from '../semantic/evidence-contract';
import type { SourceRef } from '../semantic/source-contract';

export interface LegacyResponseContract {
  id?: string;
  conversationId?: string;
  messageId?: string;
  title?: string;
  answer?: string;
  summary?: string;
  markdown?: string;
  actions?: unknown[];
  sources?: unknown[];
  evidence?: unknown[];
  [key: string]: unknown;
}

export interface LegacyReportQueryResult {
  id?: string;
  title?: string;
  summary?: string;
  viewModel?: LegacyReportQueryViewModel;
  data?: unknown;
  chart?: unknown;
  table?: unknown;
  sources?: unknown[];
  evidence?: unknown[];
  [key: string]: unknown;
}

export interface LegacyReportQueryViewModel {
  id?: string;
  title?: string;
  chartSpec?: unknown;
  vizSpec?: unknown;
  tableData?: unknown;
  insights?: unknown[];
  actions?: unknown[];
  sources?: unknown[];
  evidence?: unknown[];
  [key: string]: unknown;
}

export interface LegacyMetricExplainerUISchema {
  id?: string;
  metricName?: string;
  title?: string;
  explanation?: string;
  drivers?: unknown[];
  chart?: unknown;
  sources?: unknown[];
  evidence?: unknown[];
  actions?: unknown[];
  [key: string]: unknown;
}

export interface AdapterContext {
  conversationId?: string;
  messageId?: string;
  now?: string;
  producer?: SemanticResultContract['producer'];
  version?: string;
}

function nowIso(context: AdapterContext): string {
  return context.now ?? new Date().toISOString();
}

function normalizeAction(action: unknown, index: number): ActionContract {
  if (typeof action === 'object' && action !== null && 'id' in action && 'type' in action && 'intent' in action && 'label' in action) {
    return action as ActionContract;
  }

  return {
    id: `legacy-action-${index + 1}`,
    type: 'custom',
    intent: 'secondary',
    label: typeof action === 'string' ? action : '操作',
    payload: { legacy: action },
    metadata: { migratedFrom: 'legacy-action' },
  };
}

function normalizeSource(source: unknown, index: number): SourceRef {
  if (typeof source === 'object' && source !== null && 'id' in source && 'type' in source && 'title' in source) {
    return source as SourceRef;
  }

  return {
    id: `legacy-source-${index + 1}`,
    type: 'unknown',
    title: typeof source === 'string' ? source : `Legacy Source ${index + 1}`,
    metadata: { legacy: source },
  };
}

function normalizeEvidence(evidence: unknown, index: number): EvidenceRef {
  if (typeof evidence === 'object' && evidence !== null && 'id' in evidence && 'type' in evidence && 'title' in evidence) {
    return evidence as EvidenceRef;
  }

  return {
    id: `legacy-evidence-${index + 1}`,
    type: 'unknown',
    title: typeof evidence === 'string' ? evidence : `Legacy Evidence ${index + 1}`,
    metadata: { legacy: evidence },
  };
}

export function responseContractToSemanticResult(
  legacy: LegacyResponseContract,
  context: AdapterContext = {},
): SemanticResultContract {
  const evidenceRefs = Array.isArray(legacy.evidence) ? legacy.evidence.map(normalizeEvidence) : [];
  const sourceRefs = Array.isArray(legacy.sources) ? legacy.sources.map(normalizeSource) : [];
  const actions = Array.isArray(legacy.actions) ? legacy.actions.map(normalizeAction) : [];

  const regions: SemanticRegion[] = [
    {
      id: 'answer',
      type: 'primary-result',
      componentBinding: 'markdown-result',
      title: legacy.title,
      data: {
        markdown: legacy.markdown ?? legacy.answer ?? legacy.summary ?? '',
      },
      actions,
      evidenceRefs: evidenceRefs.map((item) => item.id),
      sourceRefs: sourceRefs.map((item) => item.id),
      metadata: { migratedFrom: 'ResponseContract' },
    },
  ];

  return {
    contractType: 'semantic-result',
    version: context.version ?? '1.0.0',
    resultId: legacy.id ?? `legacy-response-${Date.now()}`,
    conversationId: context.conversationId ?? legacy.conversationId,
    messageId: context.messageId ?? legacy.messageId,
    screenType: 'conversation-answer',
    title: legacy.title,
    createdAt: nowIso(context),
    producer: context.producer ?? { kind: 'backend', name: 'legacy-response-adapter' },
    regions,
    actions,
    evidenceRefs,
    sourceRefs,
    metadata: { migratedFrom: 'ResponseContract' },
  };
}

export function reportQueryResultToSemanticResult(
  legacy: LegacyReportQueryResult,
  context: AdapterContext = {},
): SemanticResultContract {
  return reportQueryViewModelToSemanticResult(
    legacy.viewModel ?? {
      id: legacy.id,
      title: legacy.title,
      tableData: legacy.table ?? legacy.data,
      chartSpec: legacy.chart,
      sources: legacy.sources,
      evidence: legacy.evidence,
    },
    context,
  );
}

export function reportQueryViewModelToSemanticResult(
  legacy: LegacyReportQueryViewModel,
  context: AdapterContext = {},
): SemanticResultContract {
  const evidenceRefs = Array.isArray(legacy.evidence) ? legacy.evidence.map(normalizeEvidence) : [];
  const sourceRefs = Array.isArray(legacy.sources) ? legacy.sources.map(normalizeSource) : [];
  const actions = Array.isArray(legacy.actions) ? legacy.actions.map(normalizeAction) : [];

  const regions: SemanticRegion[] = [
    {
      id: 'report-data-view',
      type: 'data-view',
      componentBinding: 'data-visualization',
      title: legacy.title,
      data: {
        viewType: 'auto',
        requestedView: 'auto',
        chartSpec: legacy.chartSpec,
        vizSpec: legacy.vizSpec,
        tableData: legacy.tableData,
        insights: legacy.insights,
        migratedFrom: 'ReportQueryViewModel',
      },
      actions,
      evidenceRefs: evidenceRefs.map((item) => item.id),
      sourceRefs: sourceRefs.map((item) => item.id),
      layoutHints: { placement: 'main', width: 'full', scrollMode: 'virtualized' },
      metadata: { migratedFrom: 'ReportQueryViewModel' },
    },
  ];

  return {
    contractType: 'semantic-result',
    version: context.version ?? '1.0.0',
    resultId: legacy.id ?? `legacy-report-${Date.now()}`,
    conversationId: context.conversationId,
    messageId: context.messageId,
    screenType: 'report-result',
    title: legacy.title,
    createdAt: nowIso(context),
    producer: context.producer ?? { kind: 'backend', name: 'legacy-report-query-adapter' },
    regions,
    actions,
    evidenceRefs,
    sourceRefs,
    metadata: { migratedFrom: 'ReportQueryViewModel' },
  };
}

export function metricExplainerUISchemaToSemanticResult(
  legacy: LegacyMetricExplainerUISchema,
  context: AdapterContext = {},
): SemanticResultContract {
  const evidenceRefs = Array.isArray(legacy.evidence) ? legacy.evidence.map(normalizeEvidence) : [];
  const sourceRefs = Array.isArray(legacy.sources) ? legacy.sources.map(normalizeSource) : [];
  const actions = Array.isArray(legacy.actions) ? legacy.actions.map(normalizeAction) : [];

  const regions: SemanticRegion[] = [
    {
      id: 'metric-explanation',
      type: 'insight',
      componentBinding: 'decision-card',
      title: legacy.title ?? legacy.metricName,
      data: {
        metricName: legacy.metricName,
        explanation: legacy.explanation,
        drivers: legacy.drivers,
        chart: legacy.chart,
        migratedFrom: 'MetricExplainerUISchema',
      },
      actions,
      evidenceRefs: evidenceRefs.map((item) => item.id),
      sourceRefs: sourceRefs.map((item) => item.id),
      metadata: { migratedFrom: 'MetricExplainerUISchema' },
    },
  ];

  return {
    contractType: 'semantic-result',
    version: context.version ?? '1.0.0',
    resultId: legacy.id ?? `legacy-metric-explainer-${Date.now()}`,
    conversationId: context.conversationId,
    messageId: context.messageId,
    screenType: 'metric-explainer',
    title: legacy.title ?? legacy.metricName,
    createdAt: nowIso(context),
    producer: context.producer ?? { kind: 'backend', name: 'legacy-metric-explainer-adapter' },
    regions,
    actions,
    evidenceRefs,
    sourceRefs,
    metadata: { migratedFrom: 'MetricExplainerUISchema' },
  };
}
