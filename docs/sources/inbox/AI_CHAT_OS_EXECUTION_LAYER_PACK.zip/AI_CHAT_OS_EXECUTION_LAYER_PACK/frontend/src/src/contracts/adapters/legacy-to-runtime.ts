import type {
  RuntimeDisplayProtocol,
  RuntimeEvent,
  RuntimeEventType,
  RuntimeStatus,
  ToolCallState,
} from '../runtime/runtime-display-protocol';

export interface LegacyAgentProcessEvent {
  id?: string;
  type?: string;
  status?: string;
  timestamp?: string;
  createdAt?: string;
  title?: string;
  summary?: string;
  agentId?: string;
  toolName?: string;
  toolCallId?: string;
  durationMs?: number;
  error?: unknown;
  payload?: unknown;
  [key: string]: unknown;
}

export interface RuntimeAdapterContext {
  runtimeId: string;
  conversationId?: string;
  messageId?: string;
  executionId?: string;
  now?: string;
  version?: string;
}

const STATUS_MAP: Record<string, RuntimeStatus> = {
  pending: 'queued',
  queued: 'queued',
  planning: 'planning',
  running: 'running',
  streaming: 'streaming',
  success: 'succeeded',
  succeeded: 'succeeded',
  partial: 'partially-succeeded',
  failed: 'failed',
  error: 'failed',
  cancelled: 'cancelled',
  retrying: 'retrying',
  recovering: 'recovering',
};

const TYPE_MAP: Record<string, RuntimeEventType> = {
  start: 'runtime-started',
  complete: 'runtime-completed',
  error: 'runtime-failed',
  model_start: 'model-started',
  model_stream_start: 'model-stream-started',
  model_token: 'model-token',
  model_stream_end: 'model-stream-ended',
  agent_start: 'agent-started',
  agent_complete: 'agent-completed',
  agent_error: 'agent-failed',
  tool_start: 'tool-call-started',
  tool_progress: 'tool-call-progress',
  tool_success: 'tool-call-succeeded',
  tool_error: 'tool-call-failed',
  workflow_start: 'workflow-started',
  step_start: 'workflow-step-started',
  step_complete: 'workflow-step-completed',
  step_error: 'workflow-step-failed',
};

function mapStatus(status: unknown): RuntimeStatus {
  if (typeof status !== 'string') return 'running';
  return STATUS_MAP[status] ?? (status as RuntimeStatus);
}

function mapType(type: unknown): RuntimeEventType {
  if (typeof type !== 'string') return 'runtime-started';
  return TYPE_MAP[type] ?? (type as RuntimeEventType);
}

export function agentProcessEventsToRuntimeDisplayProtocol(
  events: LegacyAgentProcessEvent[],
  context: RuntimeAdapterContext,
): RuntimeDisplayProtocol {
  const runtimeEvents: RuntimeEvent[] = events.map((event, index) => ({
    id: event.id ?? `legacy-runtime-event-${index + 1}`,
    runtimeId: context.runtimeId,
    type: mapType(event.type),
    status: mapStatus(event.status),
    timestamp: event.timestamp ?? event.createdAt ?? context.now ?? new Date().toISOString(),
    title: event.title,
    summary: event.summary,
    agentId: event.agentId,
    toolCallId: event.toolCallId,
    durationMs: event.durationMs,
    payload: event.payload ?? event,
    metadata: { migratedFrom: 'AgentProcessEvent' },
  }));

  const toolCalls = buildToolCallStates(events);
  const lastStatus = runtimeEvents.length > 0 ? runtimeEvents[runtimeEvents.length - 1].status : 'idle';

  return {
    contractType: 'runtime-display',
    version: context.version ?? '1.0.0',
    runtimeId: context.runtimeId,
    conversationId: context.conversationId,
    messageId: context.messageId,
    executionId: context.executionId,
    status: lastStatus,
    startedAt: runtimeEvents[0]?.timestamp,
    endedAt: ['succeeded', 'partially-succeeded', 'failed', 'cancelled'].includes(lastStatus) ? runtimeEvents[runtimeEvents.length - 1]?.timestamp : undefined,
    toolCalls,
    events: runtimeEvents,
    metadata: { migratedFrom: 'AgentProcessEvent[]' },
  };
}

function buildToolCallStates(events: LegacyAgentProcessEvent[]): ToolCallState[] {
  const map = new Map<string, ToolCallState>();

  for (const event of events) {
    const toolCallId = typeof event.toolCallId === 'string' ? event.toolCallId : undefined;
    if (!toolCallId) continue;

    const current = map.get(toolCallId) ?? {
      id: toolCallId,
      toolName: typeof event.toolName === 'string' ? event.toolName : 'unknown-tool',
      status: 'running' as RuntimeStatus,
    };

    current.status = mapStatus(event.status);
    current.startedAt = current.startedAt ?? event.timestamp ?? event.createdAt;
    current.endedAt = ['succeeded', 'failed', 'cancelled'].includes(current.status) ? (event.timestamp ?? event.createdAt) : current.endedAt;
    current.durationMs = typeof event.durationMs === 'number' ? event.durationMs : current.durationMs;
    current.outputSummary = typeof event.summary === 'string' ? event.summary : current.outputSummary;

    map.set(toolCallId, current);
  }

  return Array.from(map.values());
}
