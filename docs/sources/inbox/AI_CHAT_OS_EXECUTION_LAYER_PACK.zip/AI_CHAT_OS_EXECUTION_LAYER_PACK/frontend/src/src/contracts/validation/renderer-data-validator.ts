import type { ComponentBinding, SemanticRegion } from '../semantic/semantic-result-contract';
import {
  addIssue,
  createValidationResult,
  isRecord,
  type ContractValidationResult,
} from './contract-validator';
import { validateReportTrendData } from './report-trend-validator';

export function validateRendererData(
  binding: ComponentBinding | string,
  data: unknown,
  region?: SemanticRegion,
  path = '$.data',
): ContractValidationResult<unknown> {
  switch (binding) {
    case 'markdown-result':
      return validateMarkdownData(data, path);
    case 'data-visualization':
      return validateDataVisualizationData(data, region, path);
    case 'ai-runtime':
    case 'workflow-trace':
      return validateRuntimeBindingData(data, region, path);
    case 'asset-reference':
      return validateAssetReferenceData(data, path);
    default:
      return validateUnknownBindingData(binding, data, path);
  }
}

function validateMarkdownData(data: unknown, path: string): ContractValidationResult<unknown> {
  const result = createValidationResult(data);
  if (!isRecord(data)) {
    return addIssue(result, {
      level: 'error',
      code: 'markdown_data_not_object',
      message: 'markdown-result data must be an object.',
      path,
    });
  }
  if (typeof data.markdown !== 'string' && typeof data.text !== 'string') {
    addIssue(result, {
      level: 'error',
      code: 'markdown_text_missing',
      message: 'markdown-result requires markdown or text.',
      path,
    });
  }
  return result;
}

function validateDataVisualizationData(
  data: unknown,
  region: SemanticRegion | undefined,
  path: string,
): ContractValidationResult<unknown> {
  const result = createValidationResult(data);
  if (!isRecord(data)) {
    return addIssue(result, {
      level: 'error',
      code: 'data_visualization_data_not_object',
      message: 'data-visualization data must be an object.',
      path,
    });
  }

  const viewType = data.viewType;
  const requestedView = data.requestedView;
  if (typeof viewType !== 'string' && typeof requestedView !== 'string') {
    addIssue(result, {
      level: 'warning',
      code: 'data_visualization_view_type_missing',
      message: 'data-visualization should define viewType or requestedView.',
      path,
    });
  }

  if (viewType === 'trend' || requestedView === 'trend' || data.chartType === 'line' || data.chartType === 'area') {
    const trendResult = validateReportTrendData(data, region, path);
    result.errors.push(...trendResult.errors);
    result.warnings.push(...trendResult.warnings);
    result.infos.push(...trendResult.infos);
    result.valid = result.errors.length === 0;
  }

  if (viewType === 'sankey' || data.chartType === 'sankey') {
    if (!Array.isArray(data.nodes) || !Array.isArray(data.links)) {
      addIssue(result, {
        level: 'error',
        code: 'sankey_nodes_links_missing',
        message: 'Sankey visualization requires nodes and links arrays.',
        path,
      });
    }
  }

  return result;
}

function validateRuntimeBindingData(
  data: unknown,
  region: SemanticRegion | undefined,
  path: string,
): ContractValidationResult<unknown> {
  const result = createValidationResult(data);
  const hasRegionRuntimeRefs = Array.isArray(region?.runtimeRefs) && region.runtimeRefs.length > 0;
  const hasRuntimeRef = isRecord(data) && (typeof data.runtimeId === 'string' || typeof data.runtimeRef === 'string');
  if (!hasRegionRuntimeRefs && !hasRuntimeRef) {
    addIssue(result, {
      level: 'warning',
      code: 'runtime_binding_missing_runtime_ref',
      message: 'Runtime renderer should receive region.runtimeRefs or data.runtimeId/runtimeRef.',
      path,
    });
  }
  return result;
}

function validateAssetReferenceData(data: unknown, path: string): ContractValidationResult<unknown> {
  const result = createValidationResult(data);
  if (!isRecord(data)) {
    return addIssue(result, {
      level: 'error',
      code: 'asset_data_not_object',
      message: 'asset-reference data must be an object.',
      path,
    });
  }
  if (typeof data.artifactId !== 'string' && typeof data.assetId !== 'string') {
    addIssue(result, {
      level: 'error',
      code: 'asset_id_missing',
      message: 'asset-reference requires artifactId or assetId.',
      path,
    });
  }
  return result;
}

function validateUnknownBindingData(binding: string, data: unknown, path: string): ContractValidationResult<unknown> {
  const result = createValidationResult(data);
  addIssue(result, {
    level: 'warning',
    code: 'unknown_component_binding',
    message: `Unknown componentBinding: ${binding}. Global fallback renderer should be used.`,
    path,
  });
  return result;
}
