import type { SemanticRegion } from '../semantic/semantic-result-contract';
import {
  addIssue,
  createValidationResult,
  isRecord,
  type ContractValidationResult,
} from './contract-validator';

export interface ReportTrendDataPoint {
  date: string;
  value: number;
  series?: string;
  [key: string]: unknown;
}

export interface ReportTrendData {
  viewType?: 'trend' | 'table' | 'chart' | 'summary' | 'sankey' | string;
  requestedView?: 'trend' | 'table' | 'chart' | 'summary' | 'auto' | string;
  chartType?: 'line' | 'area' | 'bar' | 'sankey' | string;
  dateRange?: {
    start: string;
    end: string;
    timezone?: string;
  };
  granularity?: 'hour' | 'day' | 'week' | 'month' | 'quarter' | 'year' | string;
  dataCoverage?: {
    status: 'complete' | 'partial' | 'insufficient' | 'unknown' | string;
    availablePoints: number;
    requiredPoints: number;
    missingReasons?: string[];
  };
  dataset?: ReportTrendDataPoint[];
  series?: Array<{ name: string; points: ReportTrendDataPoint[] }>;
  insights?: Array<{
    id: string;
    title: string;
    summary?: string;
    evidenceRefs?: string[];
    sourceRefs?: string[];
    confidence?: unknown;
  }>;
  [key: string]: unknown;
}

function countDistinctDatePoints(data: ReportTrendData): number {
  const dates = new Set<string>();
  for (const point of Array.isArray(data.dataset) ? data.dataset : []) {
    if (typeof point.date === 'string') dates.add(point.date);
  }
  for (const series of Array.isArray(data.series) ? data.series : []) {
    for (const point of Array.isArray(series.points) ? series.points : []) {
      if (typeof point.date === 'string') dates.add(point.date);
    }
  }
  return dates.size;
}

export function isTrendRequested(data: ReportTrendData): boolean {
  return (
    data.requestedView === 'trend' ||
    data.viewType === 'trend' ||
    data.chartType === 'line' ||
    data.chartType === 'area' ||
    data.chartType === 'trend'
  );
}

export function validateReportTrendData(
  value: unknown,
  region?: SemanticRegion,
  path = '$.data',
): ContractValidationResult<ReportTrendData> {
  const result = createValidationResult<ReportTrendData>(value as ReportTrendData);

  if (!isRecord(value)) {
    return addIssue(result, {
      level: 'error',
      code: 'report_trend_data_not_object',
      message: 'Report trend data must be an object.',
      path,
    });
  }

  const data = value as ReportTrendData;
  const trendRequested = isTrendRequested(data);

  if (trendRequested) {
    if (!isRecord(data.dateRange)) {
      addIssue(result, {
        level: 'error',
        code: 'trend_date_range_missing',
        message: 'Trend view requires dateRange.',
        path: `${path}.dateRange`,
      });
    }

    if (typeof data.granularity !== 'string') {
      addIssue(result, {
        level: 'error',
        code: 'trend_granularity_missing',
        message: 'Trend view requires granularity.',
        path: `${path}.granularity`,
      });
    }

    if (!isRecord(data.dataCoverage)) {
      addIssue(result, {
        level: 'error',
        code: 'trend_data_coverage_missing',
        message: 'Trend view requires dataCoverage.',
        path: `${path}.dataCoverage`,
      });
    }

    const distinctDatePoints = countDistinctDatePoints(data);
    const availablePoints = isRecord(data.dataCoverage) && typeof data.dataCoverage.availablePoints === 'number'
      ? data.dataCoverage.availablePoints
      : distinctDatePoints;

    if (distinctDatePoints < 2 || availablePoints < 2) {
      addIssue(result, {
        level: region?.state === 'degraded' ? 'warning' : 'error',
        code: 'trend_requires_at_least_two_date_points',
        message: 'Trend visualization requires at least two distinct date points. Use degraded insufficient-trend fallback instead.',
        path,
        details: { distinctDatePoints, availablePoints },
      });
    }
  }

  if (Array.isArray(data.insights)) {
    data.insights.forEach((insight, index) => {
      const hasEvidence = Array.isArray(insight.evidenceRefs) && insight.evidenceRefs.length > 0;
      const hasSource = Array.isArray(insight.sourceRefs) && insight.sourceRefs.length > 0;
      if (!hasEvidence && !hasSource) {
        addIssue(result, {
          level: 'warning',
          code: 'trend_insight_missing_evidence_or_source',
          message: 'Trend insight should reference evidenceRefs or sourceRefs.',
          path: `${path}.insights[${index}]`,
        });
      }
    });
  }

  return result;
}
