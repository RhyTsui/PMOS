# AI Chat OS Execution Layer Pack

> 配套 `ENTERPRISE_AI_CHAT_OS_SPEC.md` 与上一轮二级规范包。  
> 本包不是新增顶层概念，而是把“总纲 + 子规范 + 类型真源”推进到可执行落地层：运行时校验、组件注册、适配器、Golden Examples、Guardrail、Observability，以及首个业务用例“问数趋势展示”的契约化落地。

## 0. 本包定位

当前系统已经具备：

```txt
ENTERPRISE_AI_CHAT_OS_SPEC.md
00_SPEC_INDEX.md
semantic-contract/*
runtime/*
frontend-engineering/*
interaction-system/*
visual-system/visual-system-breakdown.md
migration/legacy-contract-mapping.md
frontend/src/src/contracts/* 类型真源
```

本包补齐的是：

```txt
1. Contract 运行时校验
2. Component Registry 实际实现
3. Legacy Schema -> SemanticResultContract / RuntimeDisplayProtocol 适配层
4. 问数趋势展示契约化实现
5. Golden Examples 与测试断言
6. Prompt / Runtime / Contract 的关系规范
7. Guardrail 深化检查
8. Observability / Audit 可执行事件结构
9. Visual System 独立治理文档拆分
```

## 1. 推荐落地路径

将本包内容复制到项目根目录后，建议形成：

```txt
项目根目录/
├─ docs/
│  └─ architecture/
│     ├─ 01_EXECUTION_LAYER_INDEX.md
│     ├─ semantic-contract/runtime-validation.md
│     ├─ frontend-engineering/component-registry-implementation.md
│     ├─ migration/contract-adapter-implementation.md
│     ├─ use-cases/report-trend-contract.md
│     ├─ prompting/prompt-runtime-contract.md
│     ├─ examples/golden-example-spec.md
│     ├─ guardrails/contract-guardrails.md
│     ├─ observability/audit-telemetry.md
│     └─ visual-system/
│        ├─ typography.md
│        ├─ color-system.md
│        ├─ icon-system.md
│        ├─ spacing-system.md
│        ├─ radius-border-system.md
│        ├─ elevation-shadow-system.md
│        └─ motion-system.md
│
├─ frontend/src/src/contracts/
│  ├─ validation/
│  ├─ renderer/
│  ├─ adapters/
│  ├─ observability/
│  ├─ examples/golden/
│  └─ __tests__/
│
└─ scripts/guardrails/
   └─ check-contract-governance.ts
```

如你的项目实际路径不是 `frontend/src/src/contracts`，请整体移动到当前类型真源所在目录，并保持内部相对 import 不变。

## 2. 推荐实施顺序

```txt
P0. 引入 validation/*，先让契约失败可以被显式捕获。
P0. 引入 examples/golden/* 与 __tests__/*，建立回归样例。
P1. 引入 renderer/component-registry-runtime.ts，建立统一 renderer 入口和 fallback。
P1. 引入 adapters/*，先把旧链路映射到 SemanticResultContract / RuntimeDisplayProtocol。
P1. 将问数趋势展示改造为 report-trend contract，用 validator 保护。
P2. 将 ChatContainer / ReportQueryResultCard 改为消费 registry.renderResult()/renderRegion()。
P2. 接入 observability/*，记录 action、renderer error、runtime latency、contract version。
P3. 启用 scripts/guardrails/check-contract-governance.ts 作为 CI 检查。
P3. 拆分 visual-system 文档，不改 5 月 27 的字体与色彩真源值。
```

## 3. 最重要的收口规则

```txt
凡是最终业务结果展示，必须先变成 SemanticResultContract。
凡是执行过程展示，必须先变成 RuntimeDisplayProtocol。
凡是具体 UI 渲染，只能通过 Component Registry 的 renderer 处理。
凡是用户动作，只能使用 ActionContract。
凡是洞察、判断、风险建议，必须挂 evidenceRefs / sourceRefs。
凡是旧 schema，只能作为 adapter 输入，不能作为最终页面渲染协议。
```

## 4. Codex CLI 第一轮指令建议

```txt
请根据 docs/architecture/01_EXECUTION_LAYER_INDEX.md 执行第一轮可执行落地：
1. 将 frontend/src/src/contracts/validation/* 引入项目。
2. 将 examples/golden/* 纳入测试。
3. 在最终结果渲染入口调用 validateSemanticResultContract。
4. 在 runtime 展示入口调用 validateRuntimeDisplayProtocol。
5. 将旧 ResponseContract / ReportQueryResult / ReportQueryViewModel / MetricExplainerUISchema / VizSpec / AgentProcessEvent 通过 adapters/* 转成新契约。
6. 禁止用户页面直接消费旧私有 schema 作为最终结果。
7. 建立 Component Registry，所有 region 渲染必须通过 registry.resolve(binding) 后执行。
```
