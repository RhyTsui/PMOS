# Result Assembly System

## 1. 目标

Result Assembly System 将工具结果、运行结果、多工具结果、fallback 结果组装为 `SemanticResultContract`。

它是 Runtime 执行结果进入前端自主渲染的唯一出口。

```txt
Tool Results
  ↓
NormalizedToolResult
  ↓
Result Assembly
  ↓
SemanticResultContract
```

## 2. 输入

```ts
type ResultAssemblyInput = {
  requirement: UserRequirementContract
  routingTrace: RoutingTrace
  runtimeTraceId?: string
  toolResults: NormalizedToolResult[]
}
```

## 3. 输出

```ts
type ResultAssemblyOutput = {
  semanticResult: SemanticResultContract
  assemblyTrace: ResultAssemblyTrace
}
```

## 4. 核心原则

```txt
1. 工具结果不得直接作为最终 UI。
2. 多工具结果必须统一 sourceRefs / evidenceRefs。
3. fallback 必须生成 warning region 或 disclosure。
4. 数据不足必须生成 insufficient-data 结果，而不是错误画图。
5. 所有 action 必须走 ActionContract。
```
