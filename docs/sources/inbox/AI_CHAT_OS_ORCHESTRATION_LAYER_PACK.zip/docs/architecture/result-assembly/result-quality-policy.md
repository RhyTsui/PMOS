# Result Quality Policy

## 1. 质量维度

```txt
completeness    是否覆盖用户需求
accuracy        数据口径是否正确
freshness       数据是否新鲜
traceability    是否可追溯来源
actionability   是否有下一步动作
trustworthiness 是否有证据和置信度
```

## 2. 低质量结果处理

```txt
1. 缺 sourceRefs：不得展示为确定结论。
2. 缺 evidenceRefs：洞察降级为观察。
3. 数据过期：展示 freshness warning。
4. 权限不足：展示权限申请 action。
5. 置信度低：触发澄清或加风险提示。
```
