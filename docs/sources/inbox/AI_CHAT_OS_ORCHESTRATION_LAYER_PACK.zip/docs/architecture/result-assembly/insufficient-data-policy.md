# Insufficient Data Policy

## 1. 数据不足类型

```txt
empty_result
single_point_trend
missing_metric
missing_dimension
time_range_too_short
permission_limited
freshness_expired
```

## 2. 输出规则

```txt
1. 不得伪造趋势。
2. 不得把单点画成趋势图。
3. 应生成 insufficient-data region。
4. 应提供用户可执行的下一步 ActionContract。
```

## 3. 示例动作

```txt
扩大时间范围
更换指标
申请权限
查看明细表
重新查询
```
