# Tool Result to SemanticResultContract

## 1. 映射流程

```txt
NormalizedToolResult
  -> summary region
  -> data-visualization region
  -> data-table region
  -> evidence-panel region
  -> source-list region
  -> next-actions region
```

## 2. 数据类结果默认 region

```txt
summary               markdown-result
metric overview        metric-card
time series            data-visualization
tabular data           data-table
evidence               evidence-panel
sources                source-list
actions                decision-card / action-list
```

## 3. 趋势结果校验

```txt
1. 至少 2 个时间点才生成 line chart。
2. 单点数据生成 metric-card + table。
3. 数据为空生成 insufficient-data。
4. dataCoverage 必填。
```

## 4. SourceRef 生成

每个工具结果必须生成 SourceRef：

```txt
sourceId
sourceType
datasetName
freshness
permissionVisibility
```

## 5. EvidenceRef 生成

每个结论、洞察、风险建议必须有 EvidenceRef。
