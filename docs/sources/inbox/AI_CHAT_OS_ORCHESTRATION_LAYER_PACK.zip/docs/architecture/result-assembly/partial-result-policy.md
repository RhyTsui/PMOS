# Partial Result Policy

## 1. 何为部分成功

```txt
1. 多个工具调用中部分成功。
2. 部分指标缺失。
3. 部分维度不可用。
4. 部分时间段无数据。
5. fallback 提供了近似数据。
```

## 2. 展示规则

```txt
1. 不隐藏部分失败。
2. 可展示已成功结果。
3. 必须说明缺失部分。
4. 必须提供 retry / adjust query / permission request 等 ActionContract。
```
