# Intent Governance

## 1. 定位

Intent 是用户请求的任务类型，不是最终工具，也不是最终 UI。Intent 只回答：

```txt
用户大概要做什么任务？
```

它必须继续通过 `UserRequirementContract` 补全业务主体、指标、维度、时间和输出偏好。

## 2. Intent 定义结构

```ts
type IntentDefinition = {
  intentId: string
  label: string
  description: string
  businessOwner?: string
  category:
    | 'report'
    | 'analysis'
    | 'diagnosis'
    | 'workflow'
    | 'creative'
    | 'configuration'
    | 'support'

  aliases: string[]
  negativeExamples: string[]
  requiredSlots: string[]
  optionalSlots: string[]

  defaultRequestedView?: string
  allowedRequestedSubjects?: string[]

  outputMapping: {
    defaultScreenType: string
    preferredRegionTypes: string[]
    preferredComponentBindings: string[]
  }

  capabilityHints?: {
    capabilityTypes: string[]
    forbiddenCapabilityTypes?: string[]
  }

  confidencePolicy: {
    minAccept: number
    askClarificationBelow: number
  }
}
```

## 3. 推荐 Intent 分类

```txt
report_query              数据查询
trend_query               趋势查询
performance_analysis      表现分析
diagnosis                 原因诊断 / 归因
comparison                对比分析
drill_down                下钻分析
material_analysis         素材内容分析
material_performance      素材表现分析
workflow_execution        执行工作流
task_schedule             创建定时任务
export_result             导出结果
permission_request        权限申请
help                      帮助 / 解释
```

## 4. 禁止规则

```txt
1. intent 不得直接等于 toolName。
2. intent 不得通过单关键词硬判。
3. intent 不得包含 UI 组件名称。
4. intent 不得绕过 UserRequirementContract 直接进入工具调用。
```

## 5. 素材类意图边界

### 素材数据类

```txt
用户表达：素材数据、素材消耗、素材 ROI、素材 CTR、素材趋势
输出：intent = report_query 或 trend_query
requestedSubject = material
businessDomain = material-performance
```

### 素材内容分析类

```txt
用户表达：分析这个视频、这个图片素材好不好、创意卖点
输出：intent = material_analysis
requestedSubject = material
businessDomain = creative-quality
```

### 素材表现诊断类

```txt
用户表达：为什么素材 ROI 掉了、哪些素材拖累账户
输出：intent = diagnosis
requestedSubject = material
businessDomain = material-performance-diagnosis
```
