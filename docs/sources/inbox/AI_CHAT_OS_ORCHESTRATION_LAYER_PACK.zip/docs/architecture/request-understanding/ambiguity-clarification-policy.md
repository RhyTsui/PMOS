# Ambiguity & Clarification Policy

## 1. 何时认为有歧义

```txt
1. 多个 requestedSubject 置信度接近。
2. 用户缺少必要业务主体。
3. 用户请求执行型动作但缺少对象或时间。
4. 多个 capability 分数接近且输出含义不同。
5. 权限、数据源或粒度限制导致不能确定正确路径。
```

## 2. 何时必须澄清

```txt
1. 会改变数据源权威性的选择。
2. 会导致执行实际操作、审批、导出、预算调整。
3. 关键槽位无安全默认值。
4. 使用 fallback 会显著改变结论含义。
```

## 3. 何时可以默认

```txt
1. 用户未给时间范围，但业务有明确默认窗口，例如 last_7_days。
2. 用户未给展示形式，系统可同时给 summary + chart + table。
3. 用户未给排序，排名类问题可默认按核心指标降序。
```

## 4. ClarificationRequest

```ts
type ClarificationRequest = {
  reason: string
  question: string
  options?: Array<{
    label: string
    value: string
    resultingRequirementPatch?: Partial<UserRequirementContract>
  }>
  blocking: boolean
}
```

## 5. 示例

用户：

```txt
看下素材情况
```

如果上下文没有项目、时间范围、素材范围，系统可以问：

```txt
你想看素材的投放表现数据，还是想分析素材内容质量？
```

选项：

```txt
1. 素材表现数据：消耗、ROI、点击率、转化等
2. 素材内容分析：图片/视频创意、卖点、问题点等
```
