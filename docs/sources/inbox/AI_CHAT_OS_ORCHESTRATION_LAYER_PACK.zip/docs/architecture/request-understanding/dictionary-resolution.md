# Dictionary & Alias Resolution

## 1. 目标

统一业务术语、别名、缩写和同义词，避免不同模块对同一个词产生不同解释。

## 2. Dictionary Entry

```ts
type DictionaryEntry = {
  canonicalId: string
  canonicalName: string
  type: 'metric' | 'dimension' | 'entity' | 'subject' | 'intent' | 'dataset' | 'toolAlias'
  aliases: string[]
  deprecatedAliases?: string[]
  negativeAliases?: string[]
  domain?: string
  mapsTo?: {
    metricId?: string
    dimensionId?: string
    subject?: string
    datasetAuthority?: string
  }
}
```

## 3. 关键映射示例

```txt
素材 / 创意素材 / 视频素材 / 图片素材
  -> subject = material
  -> datasetAuthority = material-performance 或 creative-quality，视 taskType 而定

大盘 / 整体 / 账户整体
  -> subject = account
  -> datasetAuthority = account-daily-performance

日报 / 日报表 / 每日报告
  -> requestedView = summary 或 trend
  -> subject 需要结合上下文决定，不得默认抢占 material subject

ROI / 投产 / 投入产出
  -> metric = roi

消耗 / 花费 / cost / spend
  -> metric = cost
```

## 4. 排除规则

```txt
1. “素材”出现在“日报里的素材维度”时，仍应保留 material subject 候选。
2. “日报”不应自动覆盖 material subject。
3. “ROI”是 metric，不是 intent，不应把问题强行路由到 roi-summary capability。
4. “趋势”是 requestedView，不是 tool。
```
