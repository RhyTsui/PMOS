# UserRequirementContract

## 1. 定位

`UserRequirementContract` 是 Request Understanding System 的核心输出，是 Capability Orchestration System 的核心输入。

它不是 UI 契约，也不是 tool schema。它描述用户的业务需求。

## 2. TypeScript 结构

```ts
type UserRequirementContract = {
  contractVersion: string
  requestId: string
  rawUserMessage: string

  intent: IntentId
  taskType:
    | 'report_query'
    | 'trend_query'
    | 'analysis'
    | 'diagnosis'
    | 'comparison'
    | 'workflow_execution'
    | 'export'
    | 'configuration'

  businessDomain?: string
  requestedSubject?: BusinessSubject
  requestedView?: RequestedView

  metrics?: MetricRef[]
  dimensions?: DimensionRef[]
  filters?: FilterSpec[]

  dateRange?: DateRangeSpec
  granularity?: Granularity

  outputPreference?: OutputPreference

  requiredDatasetAuthority?: string[]
  requiredCapabilities?: string[]

  slots: SlotValue[]

  confidence: number
  ambiguity?: AmbiguityState
  clarification?: ClarificationRequest

  contextRefs?: ContextRef[]
  locale?: string
}
```

## 3. 核心字段说明

### requestedSubject

业务主体：

```txt
account
campaign
adgroup
ad
material
creative
product
audience
keyword
landing_page
```

### requestedView

用户期待的结果视图：

```txt
summary
trend
table
chart
comparison
diagnosis
attribution
ranking
breakdown
export
```

### requiredDatasetAuthority

能力选择阶段用于判断权威数据源：

```txt
account-daily-performance
campaign-performance
material-performance
creative-quality
roi-summary
conversion-performance
```

## 4. 示例：素材趋势

```json
{
  "contractVersion": "1.0",
  "requestId": "req_material_trend_001",
  "rawUserMessage": "看下近30天素材消耗和ROI趋势",
  "intent": "trend_query",
  "taskType": "trend_query",
  "businessDomain": "advertising",
  "requestedSubject": "material",
  "requestedView": "trend",
  "metrics": [
    { "metricId": "cost", "label": "消耗" },
    { "metricId": "roi", "label": "ROI" }
  ],
  "dimensions": [
    { "dimensionId": "date", "label": "日期" },
    { "dimensionId": "material", "label": "素材" }
  ],
  "dateRange": { "type": "relative", "value": "last_30_days" },
  "granularity": "day",
  "requiredDatasetAuthority": ["material-performance"],
  "slots": [],
  "confidence": 0.91
}
```

## 5. 校验规则

```txt
1. requestedView = trend 时必须有 dateRange 和 granularity。
2. requestedSubject = material 且 taskType 为 report/trend/analysis 时，应生成 requiredDatasetAuthority = material-performance。
3. requestedView = chart/trend 时必须至少包含一个 metric。
4. 关键槽位缺失时不得进入工具调用，除非存在安全默认值。
5. confidence < minAccept 时必须触发 clarification 或 fallback 到 explain-intent，不得错误调用工具。
```
