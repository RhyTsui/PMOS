# Request Understanding System

## 1. 目标

Request Understanding System 负责把用户自然语言输入转换为稳定、可校验、可回放的 `UserRequirementContract`。

它不直接选择最终工具，也不直接生成最终 UI。它输出的是能力编排层需要的结构化需求。

```txt
User Message
  ↓
Request Understanding
  ↓
UserRequirementContract
  ↓
Capability Selection
```

## 2. 为什么不能只用 intent

单一 intent 只能说明“任务大类”，不足以决定能力选择。

例如：

```txt
看下近 30 天素材消耗和 ROI 趋势
```

如果只解析为：

```txt
intent = report_query
```

系统仍可能把它路由到 account daily report。

正确解析应包含：

```txt
intent = report_query
requestedSubject = material
requestedView = trend
metrics = cost, roi
dimensions = date, material
dateRange = last_30_days
granularity = day
requiredDatasetAuthority = material-performance
```

## 3. 子模块

```txt
Intent Governance
Slot Schema
Entity Resolution
Dictionary / Alias Resolution
Ambiguity Detection
Clarification Policy
Context Carryover
UserRequirementContract Validation
```

## 4. 输入

```ts
type RequestUnderstandingInput = {
  userMessage: string
  conversationContext?: ConversationContextSnapshot
  userProfile?: UserProfileSnapshot
  availableCapabilities?: CapabilityManifest[]
}
```

## 5. 输出

```ts
type RequestUnderstandingOutput = {
  requirement: UserRequirementContract
  trace: IntentDecisionTrace
  clarification?: ClarificationRequest
}
```

## 6. 原则

```txt
1. 先解析用户需求，再选择能力。
2. intent 不能替代 subject、view、metrics、dimensions、dateRange、granularity。
3. 同一句话可产生多个候选 intent，但必须输出 selectedIntent 与 rejectedIntents。
4. 低置信度或关键槽位缺失时，应触发 clarification，而不是错误调用工具。
5. 多轮追问必须通过 ConversationContext 解析省略项。
```
