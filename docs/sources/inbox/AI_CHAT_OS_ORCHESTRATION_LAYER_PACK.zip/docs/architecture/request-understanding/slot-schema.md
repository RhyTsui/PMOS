# Slot Schema

## 1. 定位

Slot 是用户需求中的参数化字段，用于填充 capability input schema 或后续 SemanticResultContract。

## 2. Slot 类型

```ts
type SlotSchema = {
  slotId: string
  slotType:
    | 'metric'
    | 'dimension'
    | 'entity'
    | 'dateRange'
    | 'granularity'
    | 'filter'
    | 'sort'
    | 'limit'
    | 'comparisonTarget'
    | 'outputFormat'

  required: boolean
  aliases: string[]
  valueType: 'string' | 'number' | 'boolean' | 'date' | 'enum' | 'object' | 'array'
  allowedValues?: string[]
  defaultValue?: unknown
  validation?: {
    min?: number
    max?: number
    regex?: string
  }
}
```

## 3. 广告场景推荐 Slots

```txt
metric: cost / roi / ctr / cvr / impression / click / conversion / revenue
dimension: date / account / campaign / adgroup / material / creative / product / media
entity: project / campaignName / materialName / app / team
dateRange: today / yesterday / last_7_days / last_30_days / custom
granularity: hour / day / week / month
filter: media / terminal / appType / campaignStatus / materialType
sort: metric + direction
limit: topN
```

## 4. 槽位缺失策略

```txt
1. 可安全默认的槽位：dateRange 可默认 last_7_days，limit 可默认 20。
2. 不可安全默认的槽位：project、account、核心业务主体、审批对象。
3. 趋势查询缺 granularity 时，dateRange <= 60 天默认 day。
4. 对比查询缺 comparisonTarget 时必须澄清。
5. 导出或执行型动作缺关键参数时必须二次确认。
```
