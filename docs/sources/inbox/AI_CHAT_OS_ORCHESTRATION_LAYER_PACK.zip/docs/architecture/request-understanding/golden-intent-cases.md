# Golden Intent Cases

本文件定义请求理解层的回归用例。

## 1. 素材趋势

输入：

```txt
看下近30天素材消耗和ROI趋势
```

期望：

```json
{
  "intent": "trend_query",
  "requestedSubject": "material",
  "requestedView": "trend",
  "metrics": ["cost", "roi"],
  "granularity": "day",
  "requiredDatasetAuthority": ["material-performance"]
}
```

## 2. 大盘日报

输入：

```txt
今天大盘日报怎么样
```

期望：

```json
{
  "intent": "report_query",
  "requestedSubject": "account",
  "requestedView": "summary",
  "requiredDatasetAuthority": ["account-daily-performance"]
}
```

## 3. 素材内容分析

输入：

```txt
帮我分析一下这个视频素材的问题
```

期望：

```json
{
  "intent": "material_analysis",
  "requestedSubject": "material",
  "requestedView": "analysis",
  "businessDomain": "creative-quality"
}
```

## 4. 素材表现诊断

输入：

```txt
为什么这批素材 ROI 掉了
```

期望：

```json
{
  "intent": "diagnosis",
  "requestedSubject": "material",
  "requestedView": "diagnosis",
  "metrics": ["roi"],
  "requiredDatasetAuthority": ["material-performance"]
}
```
