# 02 Orchestration Layer Index

本索引用于补齐 Enterprise AI Chat OS 的“请求理解与能力编排”层。该层回答：

```txt
用户说了什么？
用户真正需要什么业务能力？
系统应该调用哪个能力？
MCP tool 如何被治理？
能力选择是否可解释、可回放、可测试？
工具结果如何进入 SemanticResultContract？
```

## 一、定位

Orchestration Layer 不属于 Unified Semantic Contract，也不属于 Data Visualization UX。它位于用户输入之后、Runtime 执行之前：

```txt
User Message
  ↓
Request Understanding System
  ↓
Capability Orchestration System
  ↓
Runtime / Tool Invocation
  ↓
Result Assembly
  ↓
Unified Semantic Contract
  ↓
Component Registry
  ↓
Frontend Rendering
```

## 二、目录

### 1. Request Understanding System

- `request-understanding/request-understanding-system.md`
- `request-understanding/intent-governance.md`
- `request-understanding/user-requirement-contract.md`
- `request-understanding/slot-schema.md`
- `request-understanding/dictionary-resolution.md`
- `request-understanding/ambiguity-clarification-policy.md`
- `request-understanding/golden-intent-cases.md`

### 2. Capability Orchestration System

- `capability-orchestration/capability-orchestration-system.md`
- `capability-orchestration/capability-manifest.md`
- `capability-orchestration/mcp-tool-normalization.md`
- `capability-orchestration/capability-selection-policy.md`
- `capability-orchestration/fallback-policy.md`
- `capability-orchestration/permission-cost-freshness-policy.md`
- `capability-orchestration/routing-trace.md`

### 3. Business Semantic Layer

- `business-semantics/business-semantic-layer.md`
- `business-semantics/metric-catalog.md`
- `business-semantics/dimension-catalog.md`
- `business-semantics/entity-catalog.md`
- `business-semantics/dataset-authority.md`
- `business-semantics/date-granularity-rules.md`
- `business-semantics/advertising-domain-semantics.md`

### 4. Context & Memory System

- `context-memory/conversation-context-system.md`
- `context-memory/follow-up-resolution.md`
- `context-memory/context-carryover-policy.md`
- `context-memory/context-expiry-policy.md`

### 5. MCP Governance

- `mcp-governance/mcp-tool-governance.md`
- `mcp-governance/tool-onboarding-checklist.md`
- `mcp-governance/tool-capability-normalization.md`
- `mcp-governance/tool-output-adapter-policy.md`
- `mcp-governance/tool-versioning.md`
- `mcp-governance/tool-deprecation-policy.md`

### 6. Result Assembly System

- `result-assembly/result-assembly-system.md`
- `result-assembly/tool-result-to-semantic-result.md`
- `result-assembly/partial-result-policy.md`
- `result-assembly/insufficient-data-policy.md`
- `result-assembly/multi-tool-result-merge.md`
- `result-assembly/result-quality-policy.md`

### 7. Observability & Evaluation

- `observability/routing-trace.md`
- `observability/intent-evaluation.md`
- `observability/capability-selection-evaluation.md`
- `observability/regression-replay.md`

### 8. Prompt Governance

- `prompting/prompt-governance.md`
- `prompting/request-understanding-prompt-contract.md`
- `prompting/capability-selection-prompt-policy.md`
- `prompting/forbidden-prompt-patterns.md`

## 三、执行顺序

```txt
Phase 1: UserRequirementContract + Intent Governance
Phase 2: CapabilityManifest + MCP Tool Normalization
Phase 3: CapabilitySelectionPolicy + FallbackPolicy
Phase 4: RoutingTrace + Golden Routing Tests
Phase 5: ResultAssembly -> SemanticResultContract
Phase 6: Guardrails + Telemetry + Regression Replay
```

## 四、核心原则

```txt
1. Intent 是 Request Understanding System 的一部分，不是总纲之外的新体系。
2. MCP tool 不得直接进入最终选择，必须先归一化为 CapabilityManifest。
3. LLM 可以辅助理解用户需求，但不得自由选择最终 tool。
4. Capability Selection 必须受 subject、authority、coverage、permission、freshness、fallback policy 约束。
5. 结果展示必须进入 SemanticResultContract。
6. 执行过程必须进入 RuntimeDisplayProtocol。
7. 路由必须有 RoutingTrace，可回放、可验收、可调试。
```
