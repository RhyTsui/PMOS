# Tool Versioning

## 1. 版本字段

```txt
tool version
capability manifest version
input schema version
output schema version
adapter version
contract version
```

## 2. 兼容规则

```txt
1. output schema breaking change 必须升级 adapter。
2. deprecated tool 必须声明 replacement。
3. version mismatch 必须写入 telemetry。
4. 历史 trace 应保留调用时版本。
```
