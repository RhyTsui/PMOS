# Tool Deprecation Policy

## 1. 生命周期

```txt
experimental -> active -> deprecated -> disabled
```

## 2. deprecated 规则

```txt
1. deprecated 工具不得作为 primary 自动选择。
2. 如果必须兼容历史流程，应通过 compatibility adapter。
3. 必须声明 deprecatedBy。
4. golden tests 不得依赖 deprecated 工具作为期望主路径。
```
