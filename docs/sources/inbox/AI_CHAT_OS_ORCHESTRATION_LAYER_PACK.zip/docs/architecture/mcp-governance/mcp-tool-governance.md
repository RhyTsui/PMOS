# MCP Tool Governance

## 1. 目标

MCP 工具接入必须产品化治理，不能只依赖 tool name 和 description。

## 2. 接入流程

```txt
1. Discover MCP tool
2. Validate tool schema
3. Normalize to CapabilityManifest
4. Declare permission / cost / freshness / authority
5. Register output adapter
6. Add golden routing cases
7. Add telemetry and audit
8. Mark lifecycle status
```

## 3. 工具状态

```txt
experimental
active
deprecated
disabled
```

## 4. 禁止事项

```txt
1. 未声明 authority 的 MCP tool 不得 primary 参与业务问数。
2. 未声明 output adapter 的 MCP tool 不得进入 SemanticResultContract。
3. deprecated 工具不得被自动选择。
4. disabled 工具只能用于历史回放，不得调用。
```
