# Tool Capability Normalization

## 1. Tool Name 不是能力

工具名只是实现标识。能力必须通过 CapabilityManifest 表达。

```txt
get_zt_ad_mat_report
  -> capabilityId = ad.material.performance.report
  -> subject = material
  -> authoritativeFor = material-performance
```

## 2. Override 机制

对于描述不足的工具，可通过配置补充：

```txt
capability-overrides.json
```

但 override 只允许补工具元数据，不允许写路由规则。

允许：

```txt
get_zt_ad_mat_report.authority.authoritativeFor = material-performance
```

禁止：

```txt
if query contains 素材 then choose get_zt_ad_mat_report
```
