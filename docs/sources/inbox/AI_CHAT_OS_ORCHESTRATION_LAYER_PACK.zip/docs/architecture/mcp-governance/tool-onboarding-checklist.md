# Tool Onboarding Checklist

每个新 MCP tool 接入前必须完成：

```txt
[ ] tool name
[ ] description
[ ] input schema
[ ] output schema
[ ] businessDomain
[ ] subject
[ ] capabilityType
[ ] supportedIntents
[ ] supportedViews
[ ] supportedMetrics
[ ] supportedDimensions
[ ] supportedGranularity
[ ] authority.sourceDataset
[ ] authority.authoritativeFor
[ ] permissions
[ ] freshnessSla
[ ] output adapter
[ ] error mapping
[ ] fallback eligibility
[ ] golden routing tests
[ ] telemetry event mapping
[ ] lifecycle status
```
