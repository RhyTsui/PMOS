# Tool Output Adapter Policy

## 1. 目标

工具输出不能直接渲染，必须通过 adapter 进入 Result Assembly，再生成 SemanticResultContract。

```txt
MCP Tool Result
  ↓
Tool Output Adapter
  ↓
NormalizedToolResult
  ↓
Result Assembly
  ↓
SemanticResultContract
```

## 2. Adapter 要求

```txt
1. 校验工具输出 schema。
2. 标准化字段名、指标、维度、时间。
3. 生成 dataCoverage。
4. 生成 sourceRefs。
5. 生成 evidenceRefs。
6. 标记 partial / insufficient / fallback。
7. 不直接返回 React component 或私有 UI schema。
```
