# Capability Selection Evaluation

## 1. 指标

```txt
primary_selection_accuracy
fallback_correctness
authority_match_rate
subject_match_rate
permission_block_rate
candidate_rejection_explainability
```

## 2. 关键验收

```txt
1. material-performance 请求不得 primary 选择 account-daily-performance。
2. fallback 必须有 disclosure。
3. 选择 trace 必须包含所有候选分数和拒绝原因。
4. 旧私有 schema 不得作为最终结果。
```
