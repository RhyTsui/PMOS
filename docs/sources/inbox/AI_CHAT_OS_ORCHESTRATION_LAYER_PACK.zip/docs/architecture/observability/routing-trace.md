# Routing Trace Observability

## 1. 事件

```txt
request_understanding_started
request_understanding_completed
intent_selected
slot_resolved
capability_candidates_generated
capability_selected
fallback_used
clarification_requested
tool_invocation_planned
```

## 2. 必须关联 ID

```txt
requestId
traceId
conversationId
runtimeTraceId
semanticResultId
selectedCapabilityId
```

## 3. 素材误路由排查必须能回答

```txt
1. 用户需求是否解析出 requestedSubject = material？
2. requiredDatasetAuthority 是否是 material-performance？
3. material capability 是否在候选里？
4. 如果被拒绝，原因是什么？
5. 如果日报被选中，它是 primary 还是 fallback？
6. fallback disclosure 是否展示给用户？
```
