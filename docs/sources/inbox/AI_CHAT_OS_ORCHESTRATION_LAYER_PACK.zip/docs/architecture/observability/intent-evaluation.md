# Intent Evaluation

## 1. 指标

```txt
intent_accuracy
subject_accuracy
slot_accuracy
clarification_rate
false_fallback_rate
material_to_daily_misroute_rate
```

## 2. Golden Set

必须覆盖：

```txt
素材数据
素材趋势
素材内容分析
素材表现诊断
大盘日报
ROI 趋势
计划表现
多轮追问
权限不足
能力不可用 fallback
```
