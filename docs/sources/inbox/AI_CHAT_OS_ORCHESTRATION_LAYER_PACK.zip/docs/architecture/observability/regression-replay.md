# Regression Replay

## 1. 目标

将历史错误路由、用户反馈、线上失败转化为可回放测试。

## 2. Replay 输入

```ts
type RoutingReplayCase = {
  caseId: string
  userMessage: string
  context?: ConversationContextSnapshot
  availableCapabilities: CapabilityManifest[]
  expectedRequirement?: Partial<UserRequirementContract>
  expectedCapabilityId?: string
  expectedFallback?: boolean
}
```

## 3. 必须回放的案例

```txt
素材数据被日报抢走
趋势单点被画折线
ROI 指标被当成 intent
日报词覆盖 material subject
多轮“那 ROI 呢”丢失上下文
```
