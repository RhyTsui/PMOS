# ENTERPRISE_AI_CHAT_OS_SPEC Orchestration Patch

本文是对 `ENTERPRISE_AI_CHAT_OS_SPEC.md` 的增量补丁建议，用于把 Request Understanding 与 Capability Orchestration 纳入总纲。

## 建议新增章节

```md
## Request Understanding & Capability Orchestration System

Enterprise AI Chat OS 不仅需要定义结果如何渲染，也必须定义用户请求如何被理解、能力如何被选择、MCP 工具如何被治理、路由如何被解释、工具结果如何进入统一语义契约。

该系统由以下子系统组成：

1. Request Understanding System  
   负责 intent、slot、entity、dictionary、ambiguity、clarification 和 UserRequirementContract。

2. Capability Orchestration System  
   负责 CapabilityManifest、MCP tool normalization、CapabilitySelectionPolicy、ToolInvocationPlan、FallbackPolicy 和 RoutingTrace。

3. Business Semantic Layer  
   负责 metric、dimension、business entity、dataset authority、date range、granularity、advertising domain semantics 的统一解释。

4. Context & Memory System  
   负责多轮对话中的主体、指标、时间范围、上一次能力、上一次结果和 follow-up 指代解析。

5. Result Assembly System  
   负责将 tool result、multi-tool result、partial result、insufficient data result 组装为 SemanticResultContract。

6. Observability & Evaluation System  
   负责 intent trace、capability routing trace、tool call trace、contract validation trace、golden tests 和 regression replay。

### 关键边界

- Intent 属于 Request Understanding System，不属于 Unified Semantic Contract。
- Capability Selection 属于 Capability Orchestration System，不属于 Data Visualization UX 或 Component Registry。
- MCP tool 必须先归一化为 CapabilityManifest，再进入能力选择。
- LLM 不得直接自由选择最终 tool。LLM 可以参与需求解析、候选解释和计划生成，但最终选择必须受 CapabilityManifest、SelectionPolicy、PermissionPolicy、FallbackPolicy 和 Runtime Validation 约束。
- 所有最终业务结果必须进入 SemanticResultContract。
- 所有执行过程必须进入 RuntimeDisplayProtocol。
- 所有路由决策必须产生 RoutingTrace，支持回放、调试和 golden tests。

### 禁止模式

- 禁止通过关键词硬编码绑定 toolName，例如 `if query includes 素材 then get_zt_ad_mat_report`。
- 禁止在 prompt 中硬写某类问题必须调用某个固定 toolName。
- 禁止让泛化日报能力与素材专用能力只凭 LLM 描述平级竞争。
- 禁止 fallback 后不披露降级原因、数据来源和证据。
- 禁止旧私有 schema 继续作为最终渲染协议。
```

## 和既有总纲关系

```txt
Unified Semantic Contract
  负责最终业务结果如何被前端自主渲染。

Runtime Display Protocol
  负责 AI / Agent / Tool / Workflow 执行过程如何展示。

Request Understanding System
  负责用户请求如何被结构化为 UserRequirementContract。

Capability Orchestration System
  负责能力如何被选择、工具如何被调用、fallback 如何披露。

Result Assembly System
  负责将工具输出转为 SemanticResultContract。
```
