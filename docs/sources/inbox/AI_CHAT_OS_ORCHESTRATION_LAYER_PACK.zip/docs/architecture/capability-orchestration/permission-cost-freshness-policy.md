# Permission / Cost / Freshness Policy

## 1. Permission Policy

能力选择必须先检查权限。

```txt
permission denied 的 capability 不得 primary 选中。
如果有可用 fallback，必须披露权限原因。
如果没有 fallback，返回权限申请 ActionContract。
```

## 2. Cost Policy

高成本 capability 不应默认调用，除非：

```txt
1. 用户明确要求深度分析。
2. 普通报表能力无法回答。
3. 需要多模态素材分析。
4. 已获得用户确认。
```

## 3. Freshness Policy

能力必须声明数据新鲜度：

```ts
freshnessSla: 'real_time' | 'hourly' | 'daily' | 'manual'
```

最终结果必须在 sourceRefs 或 dataCoverage 中展示数据时间。

## 4. 选择优先级

```txt
permission > authority > subject specificity > coverage > freshness > cost
```

权限不足时，不得为了得分选择无权限能力；应触发权限申请或 fallback。
