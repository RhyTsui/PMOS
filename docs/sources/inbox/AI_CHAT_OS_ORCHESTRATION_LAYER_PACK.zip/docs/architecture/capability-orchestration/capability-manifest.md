# Capability Manifest

## 1. 定位

CapabilityManifest 是 MCP tool、内部 API、Agent workflow、前端本地能力进入系统的统一能力声明。

所有工具必须先声明为 CapabilityManifest，才能参与能力选择。

## 2. TypeScript 结构

```ts
type CapabilityManifest = {
  capabilityId: string
  displayName: string
  description: string
  provider: 'mcp' | 'internal' | 'agent' | 'frontend'
  toolName?: string
  version: string

  capabilityType:
    | 'report.query'
    | 'report.trend'
    | 'material.analysis'
    | 'diagnosis'
    | 'attribution'
    | 'workflow.execution'
    | 'export'

  businessDomain: string
  subject: BusinessSubject

  supportedIntents: string[]
  supportedViews: string[]
  supportedMetrics: string[]
  supportedDimensions: string[]
  supportedGranularity: string[]

  authority: {
    sourceDataset: string
    authoritativeFor: string[]
    freshnessSla?: string
  }

  inputSchemaRef?: string
  outputSchemaRef?: string

  permissions?: {
    required: string[]
    optional?: string[]
  }

  fallback?: {
    isFallbackCapability: boolean
    fallbackFor?: string[]
    disclosureRequired: boolean
  }

  runtime?: {
    averageLatencyMs?: number
    costLevel?: 'low' | 'medium' | 'high'
    supportsStreaming?: boolean
  }

  lifecycle: {
    status: 'active' | 'deprecated' | 'experimental' | 'disabled'
    deprecatedBy?: string
  }
}
```

## 3. 素材报表能力示例

```json
{
  "capabilityId": "ad.material.performance.report",
  "displayName": "素材表现报表",
  "provider": "mcp",
  "toolName": "get_zt_ad_mat_report",
  "version": "1.0",
  "capabilityType": "report.query",
  "businessDomain": "advertising",
  "subject": "material",
  "supportedIntents": ["report_query", "trend_query", "performance_analysis"],
  "supportedViews": ["summary", "trend", "table", "chart", "ranking"],
  "supportedMetrics": ["cost", "roi", "ctr", "cvr", "impression", "click", "conversion"],
  "supportedDimensions": ["date", "material", "creative", "campaign"],
  "supportedGranularity": ["day", "week", "month"],
  "authority": {
    "sourceDataset": "zt_ad_mat_report",
    "authoritativeFor": ["material-performance"]
  },
  "fallback": {
    "isFallbackCapability": false,
    "disclosureRequired": false
  },
  "lifecycle": { "status": "active" }
}
```

## 4. 日报能力示例

```json
{
  "capabilityId": "ad.account.daily.report",
  "displayName": "账户大盘日报",
  "provider": "mcp",
  "toolName": "get_zt_ad_day_report",
  "version": "1.0",
  "capabilityType": "report.query",
  "businessDomain": "advertising",
  "subject": "account",
  "supportedIntents": ["report_query", "trend_query"],
  "supportedViews": ["summary", "trend", "table", "chart"],
  "supportedMetrics": ["cost", "roi", "ctr", "cvr", "impression", "click", "conversion"],
  "supportedDimensions": ["date", "account", "campaign"],
  "supportedGranularity": ["day", "week", "month"],
  "authority": {
    "sourceDataset": "zt_ad_day_report",
    "authoritativeFor": ["account-daily-performance"]
  },
  "fallback": {
    "isFallbackCapability": true,
    "fallbackFor": ["material-performance"],
    "disclosureRequired": true
  },
  "lifecycle": { "status": "active" }
}
```
