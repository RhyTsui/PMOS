# Capability Orchestration System

## 1. 目标

Capability Orchestration System 负责把 `UserRequirementContract` 转换为可执行的 `ToolInvocationPlan`。

它不依赖 LLM 自由选择工具，也不依赖关键词硬编码工具名，而是基于 CapabilityManifest 和 SelectionPolicy 进行能力选择。

## 2. 主链路

```txt
UserRequirementContract
  ↓
Candidate Capability Retrieval
  ↓
Hard Constraint Filtering
  ↓
Capability Scoring
  ↓
Fallback / Clarification Policy
  ↓
ToolInvocationPlan
  ↓
RuntimeDisplayProtocol
```

## 3. 核心对象

```txt
CapabilityManifest       能力声明
CapabilityCandidate      候选能力
CapabilityScore          能力评分
CapabilitySelectionTrace 选择过程
ToolInvocationPlan       工具调用计划
FallbackDecision         兜底决策
```

## 4. 硬约束

以下不满足时不得作为 primary capability：

```txt
subject coverage
metric coverage
dimension coverage
granularity coverage
permission coverage
dataset authority compatibility
input schema compatibility
runtime availability
```

## 5. 评分因素

```txt
specificity          主体特异性
sourceAuthority      数据源权威性
metricCoverage       指标覆盖
dimensionCoverage    维度覆盖
granularityCoverage  粒度覆盖
freshness            数据新鲜度
cost                 调用成本
latency              预估耗时
fallbackPenalty      兜底惩罚
riskPenalty          风险惩罚
```

## 6. 关键原则

```txt
1. 泛化能力不得在 primary 阶段击败更特异、更权威的能力。
2. fallback 只能在 primary 不可用、无权限、无数据、指标不支持时发生。
3. fallback 必须产生 disclosure，并写入 sourceRefs / evidenceRefs / warnings。
4. 每次选择必须生成 RoutingTrace。
5. 选择结果必须可测试、可回放、可解释。
```
