# Fallback Policy

## 1. 允许 fallback 的场景

```txt
1. primary capability 不存在。
2. primary capability 暂不可用。
3. 用户无权限使用 primary capability。
4. primary capability 不支持请求指标、维度或粒度。
5. primary capability 查询结果为空，但 fallback 可提供近似参考。
6. primary capability runtime error 且 fallback 被声明为安全替代。
```

## 2. 禁止 fallback 的场景

```txt
1. fallback 会改变业务主体但不披露。
2. fallback 会改变数据源权威性但不披露。
3. fallback 会导致结论误导。
4. 用户要求精确数据，fallback 只能近似。
5. 风险决策、预算调整、审批等高风险动作。
```

## 3. FallbackDisclosure

```ts
type FallbackDisclosure = {
  used: boolean
  originalRequiredAuthority: string[]
  fallbackCapabilityId: string
  reason:
    | 'primary_unavailable'
    | 'permission_denied'
    | 'metric_not_supported'
    | 'dimension_not_supported'
    | 'empty_result'
    | 'runtime_error'
  userMessage: string
  severity: 'info' | 'warning' | 'critical'
}
```

## 4. UI 披露要求

fallback 必须进入 SemanticResultContract：

```txt
warnings[]
sourceRefs[]
evidenceRefs[]
regions[].data.disclosure
```

示例用户文案：

```txt
当前未获取到素材专用数据，以下结果基于账户日报数据聚合，仅供趋势参考。
```

## 5. 素材 fallback 规则

```txt
material-performance -> account-daily-performance
只允许作为降级参考，不允许作为 primary。
必须披露“非素材专用数据源”。
```
