# Routing Trace

## 1. 目标

RoutingTrace 用于记录请求理解和能力选择全过程，让系统可解释、可回放、可调试、可验收。

## 2. 结构

```ts
type RoutingTrace = {
  traceId: string
  requestId: string
  rawUserMessage: string
  createdAt: string

  requirement: UserRequirementContract

  intentDecision: {
    selectedIntent: string
    confidence: number
    rejectedIntents: Array<{
      intent: string
      confidence: number
      reason: string
    }>
  }

  slotResolution: Array<{
    slotId: string
    value: unknown
    source: 'message' | 'context' | 'default' | 'dictionary' | 'user_confirmation'
    confidence: number
  }>

  capabilityDecision: {
    selectedCapabilityId?: string
    selectedAs: 'primary' | 'fallback' | 'none'
    candidates: Array<{
      capabilityId: string
      score: number
      accepted: boolean
      rejectedByHardConstraint?: string[]
      reasons: string[]
    }>
  }

  fallback?: FallbackDisclosure
  clarification?: ClarificationRequest

  finalDecision:
    | 'invoke_tool'
    | 'ask_clarification'
    | 'permission_request'
    | 'return_no_capability'
}
```

## 3. 必填要求

```txt
1. 每一次工具调用前必须有 RoutingTrace。
2. 每一次 fallback 必须记录 fallback.reason。
3. 每一个被拒绝的候选 capability 必须记录 reasons。
4. 每一个低置信度 slot 必须记录 source 和 confidence。
5. RoutingTrace 必须能关联 RuntimeDisplayProtocol 与 SemanticResultContract。
```

## 4. 素材问题 trace 期望

输入：

```txt
近30天素材消耗和ROI趋势
```

期望：

```txt
selectedIntent = trend_query
requestedSubject = material
selectedCapabilityId = ad.material.performance.report
rejected account daily report reason = subject_mismatch / authority_mismatch / fallback_only
```
