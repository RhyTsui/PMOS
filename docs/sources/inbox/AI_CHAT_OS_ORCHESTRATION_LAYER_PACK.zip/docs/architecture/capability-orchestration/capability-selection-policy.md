# Capability Selection Policy

## 1. 目标

选择最合适的 capability，而不是让 LLM 自由选 tool，也不是通过关键词绑定 tool。

## 2. Selection Pipeline

```txt
1. Retrieve candidates by businessDomain + intent + requestedSubject
2. Apply hard constraints
3. Score candidates
4. Detect ambiguity
5. Decide primary / fallback / clarification
6. Produce ToolInvocationPlan
7. Produce RoutingTrace
```

## 3. 硬约束

```txt
subjectCoverage >= required
metricCoverage >= required
viewCoverage >= required
granularityCoverage >= required
permissionAvailable = true
lifecycle.status = active
inputSchemaCompatible = true
```

## 4. 评分公式建议

```txt
score =
  specificity * 0.25 +
  authority * 0.25 +
  metricCoverage * 0.15 +
  dimensionCoverage * 0.10 +
  granularityCoverage * 0.10 +
  freshness * 0.05 +
  reliability * 0.05 -
  fallbackPenalty * 0.20 -
  riskPenalty * 0.10
```

## 5. 特异性规则

```txt
material > creative > ad > adgroup > campaign > account
```

当 requestedSubject = material 时，subject = account 的 capability 不得作为 primary，除非没有任何 material / creative / ad 级能力可用。

## 6. 数据权威性规则

当 `requiredDatasetAuthority` 包含某个领域时：

```txt
authoritativeFor 包含该领域的 capability 优先。
不包含该领域但可近似回答的 capability 只能作为 fallback。
```

## 7. 素材数据标准规则

```txt
当 UserRequirement.requestedSubject = material
且 requestedView 属于 summary / trend / table / chart / ranking / performance_analysis
且 requiredDatasetAuthority 包含 material-performance
系统必须优先选择：
  subject = material
  authority.authoritativeFor 包含 material-performance
  支持所需 metrics / dimensions / granularity
的 capability。

account / day-report / roi-summary 类泛化能力不得 primary 胜出。
```

## 8. Ambiguity Policy

当最高分与第二名差距低于阈值，且两个 capability 会产生不同业务含义时，应触发 clarification。

```txt
scoreGap < 0.08 -> clarify or ask user
```
