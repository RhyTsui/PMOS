# MCP Tool Normalization

## 1. 目标

MCP 工具不能直接参与最终能力选择。所有 MCP tool 必须先被归一化为 CapabilityManifest。

```txt
MCP Tool Description
  ↓
Tool Capability Normalizer
  ↓
CapabilityManifest
  ↓
Capability Selection
```

## 2. 归一化输入

```ts
type McpToolDescriptor = {
  name: string
  description?: string
  inputSchema?: unknown
  outputSchema?: unknown
  annotations?: Record<string, unknown>
}
```

## 3. 归一化输出

```ts
type NormalizedMcpCapability = {
  manifest: CapabilityManifest
  normalizationTrace: {
    inferredSubject: string
    inferredMetrics: string[]
    inferredDimensions: string[]
    confidence: number
    warnings: string[]
  }
}
```

## 4. 归一化规则

```txt
1. tool name 只能作为弱信号，不能作为唯一判断依据。
2. tool description、input schema、output schema、已知数据源映射都必须参与归一化。
3. subject、authority、supportedMetrics、supportedDimensions 必须显式化。
4. 无法确定 authority 的工具只能作为 low-confidence capability，不得 primary 自动胜出。
5. fallback eligibility 必须显式声明。
```

## 5. 低质量描述处理

如果 MCP tool 描述过短或不明确，应进入人工补齐或配置覆盖：

```txt
capability-overrides.json
```

示例：

```json
{
  "get_zt_ad_mat_report": {
    "subject": "material",
    "authority": {
      "sourceDataset": "zt_ad_mat_report",
      "authoritativeFor": ["material-performance"]
    },
    "supportedDimensions": ["date", "material", "creative", "campaign"]
  }
}
```

这不是硬编码路由，而是工具元数据治理。
