# Prompt Governance

## 1. 定位

Prompt 可以辅助请求理解、候选解释和结果总结，但不得绕过系统化契约。

## 2. Prompt 可做

```txt
1. 从用户文本抽取 intent / slots / entities。
2. 生成 UserRequirementContract 草案。
3. 解释候选能力差异。
4. 生成最终自然语言 summary。
5. 基于 evidenceRefs 写可信洞察。
```

## 3. Prompt 不可做

```txt
1. 直接指定最终 toolName。
2. 绕过 CapabilitySelectionPolicy。
3. 绕过 PermissionPolicy。
4. 伪造 evidence/source。
5. 生成未通过 validation 的 SemanticResultContract。
```
