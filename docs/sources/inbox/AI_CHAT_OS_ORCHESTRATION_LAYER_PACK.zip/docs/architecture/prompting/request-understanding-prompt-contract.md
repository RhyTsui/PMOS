# Request Understanding Prompt Contract

## 1. 输出要求

请求理解 prompt 必须输出结构化字段：

```txt
intent
requestedSubject
requestedView
metrics
dimensions
dateRange
granularity
filters
confidence
ambiguity
clarificationQuestion
```

## 2. 禁止输出

```txt
toolName
React component
private schema
raw SQL
最终 UI 结构
```

## 3. 校验

Prompt 输出必须通过 `validateUserRequirementContract()`，否则进入 clarification 或 safe fallback。
