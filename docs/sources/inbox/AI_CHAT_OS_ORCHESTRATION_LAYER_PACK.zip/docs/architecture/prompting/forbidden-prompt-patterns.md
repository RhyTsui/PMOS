# Forbidden Prompt Patterns

禁止：

```txt
只要用户问素材，就调用 get_zt_ad_mat_report。
```

改为：

```txt
当 UserRequirement.requestedSubject = material 且 requiredDatasetAuthority 包含 material-performance 时，能力选择阶段应优先选择 subject=material 且 authoritativeFor 包含 material-performance 的 capability。
```

禁止：

```txt
让模型在所有 MCP tools 中自由选择最合适工具。
```

改为：

```txt
模型只输出 UserRequirementContract 草案，最终 tool selection 由 Capability Orchestration System 完成。
```
