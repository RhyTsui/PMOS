# Capability Selection Prompt Policy

## 1. LLM 的角色

LLM 可以辅助解释候选能力，但最终选择由系统评分策略决定。

允许：

```txt
解释 candidate A 为什么更匹配 material-performance。
解释 candidate B 为什么只是 fallback。
```

禁止：

```txt
直接输出 selectedToolName 并绕过评分。
```

## 2. 最终选择必须基于

```txt
CapabilityManifest
CapabilitySelectionPolicy
PermissionPolicy
FallbackPolicy
Runtime availability
```
