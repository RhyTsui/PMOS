# Business Semantic Layer

## 1. 目标

Business Semantic Layer 统一业务词、指标、维度、实体、数据源权威性和时间粒度规则，防止不同模块对同一概念各自解释。

它是 Request Understanding、Capability Selection、Result Assembly 的共同基础。

## 2. 子模块

```txt
Metric Catalog
Dimension Catalog
Business Entity Catalog
Dataset Authority
Date / Granularity Rules
Advertising Domain Semantics
```

## 3. 核心原则

```txt
1. 业务术语必须映射到 canonical id。
2. 指标与维度必须有统一口径。
3. 数据源必须声明 authoritativeFor。
4. 业务主体必须明确层级关系。
5. 时间范围和粒度必须可校验。
6. 输出结论必须引用 sourceRefs / evidenceRefs。
```
