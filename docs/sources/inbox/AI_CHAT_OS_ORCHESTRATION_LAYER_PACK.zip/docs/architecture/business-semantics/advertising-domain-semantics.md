# Advertising Domain Semantics

## 1. 广告域核心语义

```txt
大盘 = account-level summary
日报 = daily performance report，不等于 account subject 的绝对覆盖
素材 = material / creative asset
创意 = creative idea / content quality / material metadata
趋势 = time-series view
归因 = diagnosis / attribution
下钻 = drill_down action
```

## 2. 素材相关问题分类

```txt
素材数据 / 素材表现 / 素材消耗 / 素材 ROI
  -> material-performance

素材视频 / 图片画面 / 卖点 / 创意方向
  -> creative-quality

素材为什么下降 / 哪些素材拖累
  -> material-performance-diagnosis

素材导出
  -> export_result + material-performance
```

## 3. 日报相关问题分类

```txt
今天大盘怎么样 / 账户日报 / 整体投放表现
  -> account-daily-performance

近7天 ROI 趋势，未指定主体
  -> account-daily-performance，除非上下文 subject 已承接为 material/campaign
```

## 4. 上下文承接

如果上一轮用户已在看素材，下一轮说：

```txt
那 ROI 呢？
```

应继承：

```txt
requestedSubject = material
requestedView = trend 或 summary
metric = roi
```
