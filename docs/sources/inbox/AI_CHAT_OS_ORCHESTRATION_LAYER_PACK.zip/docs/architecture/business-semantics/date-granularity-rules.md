# Date & Granularity Rules

## 1. DateRangeSpec

```ts
type DateRangeSpec =
  | { type: 'relative'; value: 'today' | 'yesterday' | 'last_7_days' | 'last_30_days' | 'last_90_days' }
  | { type: 'absolute'; start: string; end: string }
```

## 2. Granularity

```txt
hour
day
week
month
quarter
```

## 3. 默认规则

```txt
1. 未指定时间范围：数据查询默认 last_7_days，诊断默认 last_30_days。
2. 趋势查询必须有 dateRange。
3. dateRange <= 2 天且工具支持 hour 时可用 hour。
4. dateRange <= 90 天默认 day。
5. dateRange > 90 天可建议 week。
6. 趋势图至少需要 2 个日期点。
```

## 4. 不足数据规则

若 trend 数据点少于 2：

```txt
1. 不渲染折线趋势图。
2. 返回 insufficient-data region。
3. 可提供表格或单点指标卡。
4. 必须展示 dataCoverage。
```
