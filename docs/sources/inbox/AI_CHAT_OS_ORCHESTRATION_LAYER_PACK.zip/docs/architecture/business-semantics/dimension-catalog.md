# Dimension Catalog

## 1. 结构

```ts
type DimensionDefinition = {
  dimensionId: string
  label: string
  aliases: string[]
  level: 'time' | 'account' | 'campaign' | 'adgroup' | 'ad' | 'material' | 'creative' | 'product' | 'audience'
  compatibleMetrics: string[]
  compatibleSubjects: string[]
}
```

## 2. 推荐维度

```txt
date
hour
account
project
campaign
adgroup
ad
material
creative
media
terminal
app
product
audience
region
```

## 3. 规则

```txt
1. material 类请求应优先包含 material 或 creative 维度。
2. trend 请求必须包含 date 或 hour 维度。
3. ranking 请求必须包含排序维度和排序指标。
4. campaign/account 泛化维度不得替代 material 维度作为 primary 回答。
```
