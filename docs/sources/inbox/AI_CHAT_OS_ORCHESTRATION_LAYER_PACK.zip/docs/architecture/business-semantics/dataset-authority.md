# Dataset Authority

## 1. 目标

定义哪个数据源对哪个业务问题具有权威性。

## 2. 结构

```ts
type DatasetAuthority = {
  authorityId: string
  datasetName: string
  authoritativeFor: string[]
  subjects: string[]
  metrics: string[]
  dimensions: string[]
  freshnessSla: string
  owner?: string
}
```

## 3. 推荐权威域

```txt
account-daily-performance       账户大盘日报
campaign-performance            计划表现
adgroup-performance             广告组表现
material-performance            素材表现
creative-quality                素材内容质量
roi-summary                     ROI 汇总
conversion-performance          转化表现
workflow-runtime                工作流执行状态
```

## 4. 规则

```txt
1. CapabilityManifest.authority.authoritativeFor 必须引用本表。
2. UserRequirement.requiredDatasetAuthority 必须引用本表。
3. 选择阶段以 authority 匹配作为高权重评分项。
4. fallback 到非权威数据源时必须披露。
```
