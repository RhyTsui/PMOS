# Metric Catalog

## 1. 结构

```ts
type MetricDefinition = {
  metricId: string
  label: string
  aliases: string[]
  description?: string
  valueType: 'number' | 'currency' | 'percentage' | 'ratio' | 'integer'
  unit?: string
  formula?: string
  higherIsBetter?: boolean
  compatibleSubjects: string[]
  compatibleDimensions: string[]
  requiredSourceAuthority?: string[]
}
```

## 2. 推荐指标

```txt
cost        消耗 / 花费 / spend
roi         ROI / 投产 / 投入产出
revenue     收入 / GMV
impression  展示
click       点击
ctr         点击率
conversion  转化
cvr         转化率
cpa         转化成本
ecpv        有效播放成本
material_count 素材数
```

## 3. 规则

```txt
1. 指标名必须 canonical 化。
2. 趋势类指标必须支持时间维度。
3. 计算指标必须记录 formula 和 source metrics。
4. 结论中使用派生指标时必须有 evidenceRefs。
```
