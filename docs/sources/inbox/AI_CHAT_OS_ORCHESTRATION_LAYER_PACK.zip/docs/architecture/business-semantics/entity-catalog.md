# Entity Catalog

## 1. 业务实体层级

```txt
account
  └─ campaign
      └─ adgroup
          └─ ad
              └─ material / creative
```

## 2. BusinessSubject

```txt
account       大盘 / 账户整体
campaign      计划 / 活动
adgroup       广告组
ad            广告
material      素材 / 创意素材 / 图片素材 / 视频素材
creative      创意 / 创意方向 / 卖点
product       商品
audience      人群
```

## 3. 规则

```txt
1. 上层实体可以做聚合，但不能替代下层实体的明细能力。
2. 用户明确请求 material 时，不得自动改写为 account。
3. 用户说“大盘”时，默认 subject = account。
4. 用户说“素材内容/画面/视频/图片”时，优先 creative-quality，而不是 material-performance。
```
