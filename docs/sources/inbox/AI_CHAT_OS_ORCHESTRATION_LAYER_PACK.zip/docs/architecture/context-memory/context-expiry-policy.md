# Context Expiry Policy

## 1. 默认过期

```txt
activeRequirement: 30 minutes
selectedRows: 15 minutes
runtimeTrace: 24 hours
exportContext: 10 minutes
approvalContext: immediate confirmation required
```

## 2. 过期后处理

```txt
1. 不再自动承接。
2. 可以提示用户重新确认。
3. 不可基于过期上下文执行动作。
4. 可以保留 summary 作为解释背景，但不能作为工具输入真源。
```
