# Conversation Context System

## 1. 目标

多轮对话中，用户经常省略主体、时间、指标和对象。Context System 负责保存并安全承接这些信息。

## 2. Context Snapshot

```ts
type ConversationContextSnapshot = {
  conversationId: string
  lastRequirement?: UserRequirementContract
  lastSemanticResultId?: string
  lastRuntimeTraceId?: string
  activeSubject?: string
  activeMetrics?: string[]
  activeDimensions?: string[]
  activeDateRange?: DateRangeSpec
  activeGranularity?: string
  activeCapabilityId?: string
  activeDatasetAuthority?: string[]
  expiresAt?: string
}
```

## 3. 可承接字段

```txt
requestedSubject
metrics
dimensions
dateRange
granularity
filters
selected rows / selected materials
last capability
last dataset authority
```

## 4. 禁止承接字段

```txt
权限确认
高风险操作确认
过期数据源
已失效工具调用结果
敏感脱敏前数据
```
