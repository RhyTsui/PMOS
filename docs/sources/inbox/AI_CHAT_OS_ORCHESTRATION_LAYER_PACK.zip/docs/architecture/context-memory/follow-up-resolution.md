# Follow-up Resolution

## 1. 目标

解析“继续看”“那 ROI 呢”“换成近30天”“导出这个”等多轮省略表达。

## 2. 规则

```txt
1. 指标追问继承 subject / dateRange / filters。
2. 时间修改保留 subject / metrics / dimensions。
3. 展示方式修改只改变 requestedView / outputPreference。
4. 导出动作必须引用 lastSemanticResultId 或用户明确选择对象。
5. 如果上下文存在多个候选对象，必须澄清。
```

## 3. 示例

上一轮：

```txt
看下近7天素材表现
```

下一轮：

```txt
那 ROI 呢？
```

解析：

```json
{
  "intent": "report_query",
  "requestedSubject": "material",
  "metrics": ["roi"],
  "dateRange": { "type": "relative", "value": "last_7_days" },
  "contextRefs": [{ "type": "lastRequirement" }]
}
```
