# Context Carryover Policy

## 1. 承接优先级

```txt
explicit user message > selected UI context > last active context > safe default
```

## 2. 冲突处理

如果用户当前消息和上下文冲突，以当前消息为准，并记录 trace。

示例：

```txt
上一轮 subject = material
本轮用户说“看大盘”
```

结果：

```txt
requestedSubject = account
contextCarryover = false
```

## 3. 安全规则

```txt
1. 高风险动作不可仅靠上下文承接执行。
2. 跨项目/账户上下文不可静默承接。
3. 时间范围超过过期策略时必须重新确认或默认。
4. 权限变化后上下文能力必须重新校验。
```
