# AI Chat OS Orchestration Layer Pack

Version: 1.0  
Date: 2026-05-28  
Target project: Enterprise AI Chat OS

本包用于补齐 `ENTERPRISE_AI_CHAT_OS_SPEC.md` 在“用户请求如何被理解、能力如何被选择、MCP 工具如何被治理、结果如何被组装、路由如何被观测”方面的系统化架构缺口。

本包不是新的平行总纲，也不替代 Unified Semantic Contract / Runtime Display Protocol / Execution Layer。它是 Enterprise AI Chat OS 下的 **Request Understanding & Capability Orchestration** 补充层。

## 建议放置路径

```txt
docs/architecture/
├─ 02_ORCHESTRATION_LAYER_INDEX.md
├─ ENTERPRISE_AI_CHAT_OS_SPEC_ORCHESTRATION_PATCH.md
├─ request-understanding/
├─ capability-orchestration/
├─ business-semantics/
├─ context-memory/
├─ mcp-governance/
├─ result-assembly/
├─ observability/
└─ prompting/

frontend/src/src/contracts/
├─ request-understanding/
├─ capability/
├─ business-semantics/
├─ context-memory/
├─ mcp/
├─ result-assembly/
└─ __tests__/

scripts/guardrails/
└─ check-routing-governance.ts
```

## 第一轮实施目标

```txt
1. 将 MCP tool 归一为 CapabilityManifest。
2. 将用户问题解析为 UserRequirementContract，而不是只解析 intent。
3. 用 CapabilitySelectionPolicy 选择能力，禁止 LLM 直接自由选择最终 tool。
4. 将素材数据 / 素材趋势 / 素材表现类问题优先匹配 material-performance 权威能力。
5. 泛化日报能力只能作为 fallback，并必须产生 disclosure。
6. 所有路由决策必须输出 RoutingTrace。
7. 工具执行结果必须通过 Result Assembly 进入 SemanticResultContract。
8. 增加 golden routing tests 防止素材问题再次被日报抢走。
```

## 和已有三层规范的关系

```txt
ENTERPRISE_AI_CHAT_OS_SPEC.md
  = 顶层总纲，定义系统边界和原则

00_SPEC_INDEX.md
  = 二级规范索引，定义各子系统入口

01_EXECUTION_LAYER_INDEX.md
  = 执行层，定义 validator / adapter / registry / golden / guardrail / observability

02_ORCHESTRATION_LAYER_INDEX.md
  = 请求理解与能力编排层，定义 intent / slots / capability / MCP / routing / result assembly
```

## 禁止事项

```txt
1. 禁止通过 query.includes("素材") 直接绑定 get_zt_ad_mat_report。
2. 禁止在 prompt 中硬写“素材问题必须调用某个 toolName”。
3. 禁止让日报、素材、ROI 等工具只凭 LLM 自由竞争。
4. 禁止让旧 ResponseContract / ReportQueryViewModel / MetricExplainerUISchema 继续作为最终渲染协议。
5. 禁止 MCP tool 未经过 CapabilityManifest 归一化就进入选择。
6. 禁止 fallback 后不向用户披露数据来源和能力降级。
```
