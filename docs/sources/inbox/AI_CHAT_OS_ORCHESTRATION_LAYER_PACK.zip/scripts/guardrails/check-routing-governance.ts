import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const forbiddenPatterns = [
  /query\.includes\(['"]素材['"]\).*get_zt_ad_mat_report/s,
  /get_zt_ad_mat_report.*query\.includes\(['"]素材['"]\)/s,
  /只要.*素材.*get_zt_ad_mat_report/s,
  /chartActions|tableButtons|cardCta/s,
];

function walk(dir: string, files: string[] = []): string[] {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name === '.git' || entry.name === 'dist') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, files);
    else if (/\.(ts|tsx|js|jsx|md|json)$/.test(entry.name)) files.push(full);
  }
  return files;
}

const files = walk(ROOT);
const violations: Array<{ file: string; pattern: string }> = [];

for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  for (const pattern of forbiddenPatterns) {
    if (pattern.test(content)) violations.push({ file, pattern: String(pattern) });
  }
}

if (violations.length > 0) {
  console.error('Routing governance violations found:');
  for (const violation of violations) {
    console.error(`- ${violation.file}: ${violation.pattern}`);
  }
  process.exit(1);
}

console.log('Routing governance check passed.');
