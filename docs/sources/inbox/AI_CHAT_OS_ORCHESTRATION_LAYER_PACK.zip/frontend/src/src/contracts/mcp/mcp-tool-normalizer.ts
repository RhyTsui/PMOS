import type { CapabilityManifest } from '../capability/capability-manifest';

export type McpToolDescriptor = {
  name: string;
  description?: string;
  inputSchema?: unknown;
  outputSchema?: unknown;
  annotations?: Record<string, unknown>;
};

export type CapabilityOverride = Partial<CapabilityManifest> & {
  capabilityId: string;
};

export type NormalizedMcpCapability = {
  manifest: CapabilityManifest;
  normalizationTrace: {
    inferredSubject: string;
    inferredMetrics: string[];
    inferredDimensions: string[];
    confidence: number;
    warnings: string[];
  };
};

export function normalizeMcpToolToCapability(tool: McpToolDescriptor, override?: CapabilityOverride): NormalizedMcpCapability {
  const base: CapabilityManifest = {
    capabilityId: override?.capabilityId ?? `mcp.${tool.name}`,
    displayName: override?.displayName ?? tool.name,
    description: override?.description ?? tool.description ?? '',
    provider: 'mcp',
    toolName: tool.name,
    version: override?.version ?? '1.0',
    capabilityType: override?.capabilityType ?? 'report.query',
    businessDomain: override?.businessDomain ?? 'advertising',
    subject: override?.subject ?? 'account',
    supportedIntents: override?.supportedIntents ?? ['report_query'],
    supportedViews: override?.supportedViews ?? ['summary', 'table'],
    supportedMetrics: override?.supportedMetrics ?? [],
    supportedDimensions: override?.supportedDimensions ?? [],
    supportedGranularity: override?.supportedGranularity ?? ['day'],
    authority: override?.authority ?? { sourceDataset: tool.name, authoritativeFor: [] },
    permissions: override?.permissions,
    fallback: override?.fallback ?? { isFallbackCapability: false, disclosureRequired: false },
    runtime: override?.runtime,
    lifecycle: override?.lifecycle ?? { status: 'experimental' },
  };

  return {
    manifest: base,
    normalizationTrace: {
      inferredSubject: base.subject,
      inferredMetrics: base.supportedMetrics,
      inferredDimensions: base.supportedDimensions,
      confidence: override ? 0.9 : 0.45,
      warnings: override ? [] : ['No capability override provided; normalized with low confidence.'],
    },
  };
}
