import materialRequirement from '../examples/golden-routing/material-trend.requirement.json';
import accountRequirement from '../examples/golden-routing/account-daily.requirement.json';
import materialCapability from '../examples/capabilities/material-report.capability.json';
import accountDailyCapability from '../examples/capabilities/account-daily.capability.json';
import { selectCapability } from '../capability/capability-selection-policy';

describe('Capability selection', () => {
  it('selects material performance capability for material trend request', () => {
    const result = selectCapability(materialRequirement as any, [materialCapability as any, accountDailyCapability as any]);
    expect(result.selectedCapability?.capabilityId).toBe('ad.material.performance.report');
    expect(result.selectedAs).toBe('primary');
  });

  it('selects account daily report for account daily request', () => {
    const result = selectCapability(accountRequirement as any, [materialCapability as any, accountDailyCapability as any]);
    expect(result.selectedCapability?.capabilityId).toBe('ad.account.daily.report');
    expect(result.selectedAs).toBe('primary');
  });

  it('only uses account daily report as fallback for material request when material capability is unavailable', () => {
    const result = selectCapability(materialRequirement as any, [accountDailyCapability as any]);
    expect(result.selectedCapability?.capabilityId).toBe('ad.account.daily.report');
    expect(result.selectedAs).toBe('fallback');
  });
});
