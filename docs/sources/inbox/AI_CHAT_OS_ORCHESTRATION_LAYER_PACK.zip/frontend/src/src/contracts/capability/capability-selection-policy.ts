import type { CapabilityManifest } from './capability-manifest';
import { scoreCapability, type CapabilityScore } from './capability-score';
import type { UserRequirementContract } from '../request-understanding/user-requirement-contract';

export type CapabilitySelectionResult = {
  selectedCapability?: CapabilityManifest;
  selectedAs: 'primary' | 'fallback' | 'none';
  scores: CapabilityScore[];
  reason: string;
};

export function selectCapability(requirement: UserRequirementContract, capabilities: CapabilityManifest[]): CapabilitySelectionResult {
  const scores = capabilities.map((capability) => scoreCapability(requirement, capability));
  const byId = new Map(capabilities.map((capability) => [capability.capabilityId, capability]));

  const primaryCandidates = scores
    .filter((score) => score.hardConstraintFailures.length === 0)
    .map((score) => ({ score, capability: byId.get(score.capabilityId)! }))
    .filter(({ capability }) => !capability.fallback?.isFallbackCapability)
    .sort((a, b) => b.score.total - a.score.total);

  if (primaryCandidates.length > 0) {
    return { selectedCapability: primaryCandidates[0].capability, selectedAs: 'primary', scores, reason: 'selected_highest_scoring_primary_capability' };
  }

  const fallbackCandidates = scores
    .map((score) => ({ score, capability: byId.get(score.capabilityId)! }))
    .filter(({ capability }) => capability.fallback?.isFallbackCapability)
    .filter(({ capability }) => {
      const requiredAuthority = requirement.requiredDatasetAuthority ?? [];
      return requiredAuthority.some((authority) => capability.fallback?.fallbackFor?.includes(authority));
    })
    .sort((a, b) => b.score.total - a.score.total);

  if (fallbackCandidates.length > 0) {
    return { selectedCapability: fallbackCandidates[0].capability, selectedAs: 'fallback', scores, reason: 'selected_fallback_capability_because_no_primary_available' };
  }

  return { selectedAs: 'none', scores, reason: 'no_capability_satisfies_requirement' };
}
