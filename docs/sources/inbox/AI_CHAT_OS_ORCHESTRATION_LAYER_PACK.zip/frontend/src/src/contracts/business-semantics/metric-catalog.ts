export type MetricDefinition = {
  metricId: string;
  label: string;
  aliases: string[];
  description?: string;
  valueType: 'number' | 'currency' | 'percentage' | 'ratio' | 'integer';
  unit?: string;
  formula?: string;
  higherIsBetter?: boolean;
  compatibleSubjects: string[];
  compatibleDimensions: string[];
  requiredSourceAuthority?: string[];
};

export const DEFAULT_METRIC_CATALOG: MetricDefinition[] = [
  { metricId: 'cost', label: '消耗', aliases: ['花费', 'spend', 'cost'], valueType: 'currency', unit: 'CNY', higherIsBetter: false, compatibleSubjects: ['account', 'campaign', 'adgroup', 'ad', 'material'], compatibleDimensions: ['date', 'campaign', 'material'] },
  { metricId: 'roi', label: 'ROI', aliases: ['投产', '投入产出'], valueType: 'ratio', higherIsBetter: true, compatibleSubjects: ['account', 'campaign', 'adgroup', 'ad', 'material'], compatibleDimensions: ['date', 'campaign', 'material'] },
  { metricId: 'ctr', label: '点击率', aliases: ['CTR'], valueType: 'percentage', higherIsBetter: true, compatibleSubjects: ['account', 'campaign', 'adgroup', 'ad', 'material'], compatibleDimensions: ['date', 'campaign', 'material'] },
];
