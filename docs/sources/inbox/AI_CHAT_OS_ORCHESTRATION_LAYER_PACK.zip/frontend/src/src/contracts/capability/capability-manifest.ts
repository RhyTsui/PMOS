import type { BusinessSubject, Granularity, IntentId, RequestedView } from '../request-understanding/user-requirement-contract';

export type CapabilityManifest = {
  capabilityId: string;
  displayName: string;
  description: string;
  provider: 'mcp' | 'internal' | 'agent' | 'frontend';
  toolName?: string;
  version: string;
  capabilityType:
    | 'report.query'
    | 'report.trend'
    | 'material.analysis'
    | 'diagnosis'
    | 'attribution'
    | 'workflow.execution'
    | 'export';
  businessDomain: string;
  subject: BusinessSubject;
  supportedIntents: IntentId[];
  supportedViews: RequestedView[];
  supportedMetrics: string[];
  supportedDimensions: string[];
  supportedGranularity: Granularity[];
  authority: {
    sourceDataset: string;
    authoritativeFor: string[];
    freshnessSla?: 'real_time' | 'hourly' | 'daily' | 'manual';
  };
  inputSchemaRef?: string;
  outputSchemaRef?: string;
  permissions?: {
    required: string[];
    optional?: string[];
  };
  fallback?: {
    isFallbackCapability: boolean;
    fallbackFor?: string[];
    disclosureRequired: boolean;
  };
  runtime?: {
    averageLatencyMs?: number;
    costLevel?: 'low' | 'medium' | 'high';
    supportsStreaming?: boolean;
  };
  lifecycle: {
    status: 'active' | 'deprecated' | 'experimental' | 'disabled';
    deprecatedBy?: string;
  };
};

export function isCapabilityActive(capability: CapabilityManifest): boolean {
  return capability.lifecycle.status === 'active';
}
