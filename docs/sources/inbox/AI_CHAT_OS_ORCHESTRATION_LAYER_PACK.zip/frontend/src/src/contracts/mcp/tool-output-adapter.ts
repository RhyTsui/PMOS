export type NormalizedToolResult = {
  toolName: string;
  capabilityId: string;
  rows?: Array<Record<string, unknown>>;
  summary?: string;
  metrics?: string[];
  dimensions?: string[];
  dataCoverage?: {
    start?: string;
    end?: string;
    granularity?: string;
    rowCount?: number;
  };
  sourceRefs: Array<{
    sourceId: string;
    sourceType: string;
    datasetName: string;
    freshness?: string;
  }>;
  warnings?: string[];
};

export function adaptMcpResultToNormalizedToolResult(input: {
  toolName: string;
  capabilityId: string;
  rawResult: unknown;
  datasetName: string;
}): NormalizedToolResult {
  const rows = Array.isArray(input.rawResult) ? input.rawResult as Array<Record<string, unknown>> : undefined;
  return {
    toolName: input.toolName,
    capabilityId: input.capabilityId,
    rows,
    dataCoverage: { rowCount: rows?.length ?? 0 },
    sourceRefs: [{ sourceId: `${input.datasetName}:latest`, sourceType: 'dataset', datasetName: input.datasetName }],
  };
}
