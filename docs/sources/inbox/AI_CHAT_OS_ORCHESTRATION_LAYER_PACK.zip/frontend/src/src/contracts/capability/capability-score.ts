import type { CapabilityManifest } from './capability-manifest';
import type { UserRequirementContract } from '../request-understanding/user-requirement-contract';

export type CapabilityScoreBreakdown = {
  specificity: number;
  authority: number;
  metricCoverage: number;
  dimensionCoverage: number;
  granularityCoverage: number;
  freshness: number;
  reliability: number;
  fallbackPenalty: number;
  riskPenalty: number;
};

export type CapabilityScore = {
  capabilityId: string;
  total: number;
  breakdown: CapabilityScoreBreakdown;
  hardConstraintFailures: string[];
  reasons: string[];
};

const SUBJECT_SPECIFICITY: Record<string, number> = {
  account: 0.2,
  campaign: 0.45,
  adgroup: 0.6,
  ad: 0.72,
  creative: 0.85,
  material: 0.9,
  product: 0.7,
  audience: 0.65,
  keyword: 0.65,
  landing_page: 0.65,
};

export function scoreCapability(requirement: UserRequirementContract, capability: CapabilityManifest): CapabilityScore {
  const failures: string[] = [];
  const reasons: string[] = [];

  if (capability.lifecycle.status !== 'active') failures.push(`lifecycle_${capability.lifecycle.status}`);
  if (requirement.requestedSubject && capability.subject !== requirement.requestedSubject) {
    if (!capability.fallback?.isFallbackCapability) failures.push('subject_mismatch');
    else reasons.push('subject_mismatch_but_fallback_capability');
  }

  const requiredMetrics = requirement.metrics?.map((m) => m.metricId) ?? [];
  const metricHits = requiredMetrics.filter((m) => capability.supportedMetrics.includes(m)).length;
  const metricCoverage = requiredMetrics.length === 0 ? 1 : metricHits / requiredMetrics.length;
  if (metricCoverage < 1) failures.push('metric_not_fully_supported');

  const requiredDimensions = requirement.dimensions?.map((d) => d.dimensionId) ?? [];
  const dimensionHits = requiredDimensions.filter((d) => capability.supportedDimensions.includes(d)).length;
  const dimensionCoverage = requiredDimensions.length === 0 ? 1 : dimensionHits / requiredDimensions.length;

  const granularityCoverage = !requirement.granularity || capability.supportedGranularity.includes(requirement.granularity) ? 1 : 0;
  if (granularityCoverage === 0) failures.push('granularity_not_supported');

  const authorityRequired = requirement.requiredDatasetAuthority ?? [];
  const authorityHits = authorityRequired.filter((a) => capability.authority.authoritativeFor.includes(a)).length;
  const authority = authorityRequired.length === 0 ? 0.6 : authorityHits / authorityRequired.length;

  if (authorityRequired.length > 0 && authority === 0 && !capability.fallback?.isFallbackCapability) {
    failures.push('authority_mismatch');
  }

  const specificity = requirement.requestedSubject === capability.subject ? 1 : SUBJECT_SPECIFICITY[capability.subject] ?? 0.4;
  const fallbackPenalty = capability.fallback?.isFallbackCapability ? 1 : 0;

  const breakdown: CapabilityScoreBreakdown = {
    specificity,
    authority,
    metricCoverage,
    dimensionCoverage,
    granularityCoverage,
    freshness: 0.8,
    reliability: 0.8,
    fallbackPenalty,
    riskPenalty: 0,
  };

  const total =
    breakdown.specificity * 0.25 +
    breakdown.authority * 0.25 +
    breakdown.metricCoverage * 0.15 +
    breakdown.dimensionCoverage * 0.1 +
    breakdown.granularityCoverage * 0.1 +
    breakdown.freshness * 0.05 +
    breakdown.reliability * 0.05 -
    breakdown.fallbackPenalty * 0.2 -
    breakdown.riskPenalty * 0.1;

  if (requirement.requestedSubject === 'material' && capability.subject === 'account') {
    reasons.push('account_capability_cannot_primary_for_material_request');
  }

  return { capabilityId: capability.capabilityId, total, breakdown, hardConstraintFailures: failures, reasons };
}
