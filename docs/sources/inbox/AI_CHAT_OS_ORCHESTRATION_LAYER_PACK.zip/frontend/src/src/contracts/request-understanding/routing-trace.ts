import type { ClarificationRequest, UserRequirementContract } from './user-requirement-contract';
import type { FallbackDisclosure } from '../capability/fallback-policy';

export type RoutingTrace = {
  traceId: string;
  requestId: string;
  rawUserMessage: string;
  createdAt: string;
  requirement: UserRequirementContract;
  intentDecision: {
    selectedIntent: string;
    confidence: number;
    rejectedIntents: Array<{
      intent: string;
      confidence: number;
      reason: string;
    }>;
  };
  slotResolution: Array<{
    slotId: string;
    value: unknown;
    source: 'message' | 'context' | 'default' | 'dictionary' | 'user_confirmation';
    confidence: number;
  }>;
  capabilityDecision: {
    selectedCapabilityId?: string;
    selectedAs: 'primary' | 'fallback' | 'none';
    candidates: Array<{
      capabilityId: string;
      score: number;
      accepted: boolean;
      rejectedByHardConstraint?: string[];
      reasons: string[];
    }>;
  };
  fallback?: FallbackDisclosure;
  clarification?: ClarificationRequest;
  finalDecision: 'invoke_tool' | 'ask_clarification' | 'permission_request' | 'return_no_capability';
};
