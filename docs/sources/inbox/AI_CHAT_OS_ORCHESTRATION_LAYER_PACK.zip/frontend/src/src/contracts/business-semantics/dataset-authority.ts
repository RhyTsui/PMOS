export type DatasetAuthority = {
  authorityId: string;
  datasetName: string;
  authoritativeFor: string[];
  subjects: string[];
  metrics: string[];
  dimensions: string[];
  freshnessSla: 'real_time' | 'hourly' | 'daily' | 'manual';
  owner?: string;
};

export const DEFAULT_DATASET_AUTHORITIES: DatasetAuthority[] = [
  {
    authorityId: 'account-daily-performance',
    datasetName: 'zt_ad_day_report',
    authoritativeFor: ['account-daily-performance'],
    subjects: ['account', 'campaign'],
    metrics: ['cost', 'roi', 'ctr', 'cvr', 'impression', 'click', 'conversion'],
    dimensions: ['date', 'account', 'campaign'],
    freshnessSla: 'daily',
  },
  {
    authorityId: 'material-performance',
    datasetName: 'zt_ad_mat_report',
    authoritativeFor: ['material-performance'],
    subjects: ['material', 'creative'],
    metrics: ['cost', 'roi', 'ctr', 'cvr', 'impression', 'click', 'conversion'],
    dimensions: ['date', 'material', 'creative', 'campaign'],
    freshnessSla: 'daily',
  },
];
