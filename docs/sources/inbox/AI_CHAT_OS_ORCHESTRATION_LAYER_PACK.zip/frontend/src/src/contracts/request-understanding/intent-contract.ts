import type { BusinessSubject, IntentId, RequestedView } from './user-requirement-contract';

export type IntentDefinition = {
  intentId: IntentId;
  label: string;
  description: string;
  businessOwner?: string;
  category: 'report' | 'analysis' | 'diagnosis' | 'workflow' | 'creative' | 'configuration' | 'support';
  aliases: string[];
  negativeExamples: string[];
  requiredSlots: string[];
  optionalSlots: string[];
  defaultRequestedView?: RequestedView;
  allowedRequestedSubjects?: BusinessSubject[];
  outputMapping: {
    defaultScreenType: string;
    preferredRegionTypes: string[];
    preferredComponentBindings: string[];
  };
  capabilityHints?: {
    capabilityTypes: string[];
    forbiddenCapabilityTypes?: string[];
  };
  confidencePolicy: {
    minAccept: number;
    askClarificationBelow: number;
  };
};

export const DEFAULT_INTENT_DEFINITIONS: IntentDefinition[] = [
  {
    intentId: 'trend_query',
    label: '趋势查询',
    description: '查询指标随时间变化趋势。',
    category: 'report',
    aliases: ['趋势', '走势', '变化', '近几天', '近30天'],
    negativeExamples: [],
    requiredSlots: ['dateRange', 'metric'],
    optionalSlots: ['subject', 'dimension', 'granularity'],
    defaultRequestedView: 'trend',
    outputMapping: {
      defaultScreenType: 'report-analysis',
      preferredRegionTypes: ['summary', 'visualization', 'table'],
      preferredComponentBindings: ['markdown-result', 'data-visualization', 'data-table'],
    },
    capabilityHints: { capabilityTypes: ['report.query', 'report.trend'] },
    confidencePolicy: { minAccept: 0.7, askClarificationBelow: 0.55 },
  },
  {
    intentId: 'material_analysis',
    label: '素材内容分析',
    description: '分析素材内容质量、创意卖点、图片或视频问题。',
    category: 'creative',
    aliases: ['素材分析', '创意分析', '视频素材', '图片素材', '卖点'],
    negativeExamples: ['素材消耗趋势', '素材ROI'],
    requiredSlots: ['material'],
    optionalSlots: ['objective'],
    defaultRequestedView: 'analysis',
    allowedRequestedSubjects: ['material', 'creative'],
    outputMapping: {
      defaultScreenType: 'material-analysis',
      preferredRegionTypes: ['summary', 'asset-reference', 'evidence'],
      preferredComponentBindings: ['markdown-result', 'asset-reference', 'evidence-panel'],
    },
    capabilityHints: { capabilityTypes: ['material.analysis'] },
    confidencePolicy: { minAccept: 0.7, askClarificationBelow: 0.55 },
  },
];
