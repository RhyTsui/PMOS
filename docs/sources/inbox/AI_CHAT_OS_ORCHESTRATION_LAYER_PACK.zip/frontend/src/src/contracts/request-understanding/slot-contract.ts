export type SlotSchema = {
  slotId: string;
  slotType:
    | 'metric'
    | 'dimension'
    | 'entity'
    | 'dateRange'
    | 'granularity'
    | 'filter'
    | 'sort'
    | 'limit'
    | 'comparisonTarget'
    | 'outputFormat';
  required: boolean;
  aliases: string[];
  valueType: 'string' | 'number' | 'boolean' | 'date' | 'enum' | 'object' | 'array';
  allowedValues?: string[];
  defaultValue?: unknown;
  validation?: {
    min?: number;
    max?: number;
    regex?: string;
  };
};

export const DEFAULT_SLOT_SCHEMAS: SlotSchema[] = [
  { slotId: 'metric', slotType: 'metric', required: false, aliases: ['指标', '数据', 'ROI', '消耗'], valueType: 'array' },
  { slotId: 'dateRange', slotType: 'dateRange', required: false, aliases: ['时间', '日期', '近7天', '近30天'], valueType: 'object' },
  { slotId: 'granularity', slotType: 'granularity', required: false, aliases: ['粒度', '按天', '按周'], valueType: 'enum', allowedValues: ['hour', 'day', 'week', 'month'] },
  { slotId: 'subject', slotType: 'entity', required: false, aliases: ['主体', '素材', '大盘', '计划'], valueType: 'string' },
];
