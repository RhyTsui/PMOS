export type FallbackReason =
  | 'primary_unavailable'
  | 'permission_denied'
  | 'metric_not_supported'
  | 'dimension_not_supported'
  | 'empty_result'
  | 'runtime_error'
  | 'authority_unavailable';

export type FallbackDisclosure = {
  used: boolean;
  originalRequiredAuthority: string[];
  fallbackCapabilityId: string;
  reason: FallbackReason;
  userMessage: string;
  severity: 'info' | 'warning' | 'critical';
};

export function createFallbackDisclosure(input: {
  originalRequiredAuthority: string[];
  fallbackCapabilityId: string;
  reason: FallbackReason;
}): FallbackDisclosure {
  return {
    used: true,
    originalRequiredAuthority: input.originalRequiredAuthority,
    fallbackCapabilityId: input.fallbackCapabilityId,
    reason: input.reason,
    severity: 'warning',
    userMessage: '当前未获取到专用数据源，以下结果基于兼容数据源，仅供参考。',
  };
}
