export type EntityDefinition = {
  entityId: string;
  label: string;
  aliases: string[];
  parentEntityId?: string;
  subject: string;
};

export const DEFAULT_ENTITY_CATALOG: EntityDefinition[] = [
  { entityId: 'account', label: '账户', aliases: ['大盘', '整体', '账户整体'], subject: 'account' },
  { entityId: 'campaign', label: '计划', aliases: ['计划', 'campaign'], parentEntityId: 'account', subject: 'campaign' },
  { entityId: 'material', label: '素材', aliases: ['素材', '创意素材', '图片素材', '视频素材'], parentEntityId: 'ad', subject: 'material' },
];
