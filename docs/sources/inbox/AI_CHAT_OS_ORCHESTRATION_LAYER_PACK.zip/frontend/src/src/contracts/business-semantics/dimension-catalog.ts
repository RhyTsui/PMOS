export type DimensionDefinition = {
  dimensionId: string;
  label: string;
  aliases: string[];
  level: 'time' | 'account' | 'campaign' | 'adgroup' | 'ad' | 'material' | 'creative' | 'product' | 'audience';
  compatibleMetrics: string[];
  compatibleSubjects: string[];
};

export const DEFAULT_DIMENSION_CATALOG: DimensionDefinition[] = [
  { dimensionId: 'date', label: '日期', aliases: ['天', '日期', '时间'], level: 'time', compatibleMetrics: ['cost', 'roi', 'ctr', 'cvr'], compatibleSubjects: ['account', 'campaign', 'material'] },
  { dimensionId: 'material', label: '素材', aliases: ['素材', '创意素材', '图片素材', '视频素材'], level: 'material', compatibleMetrics: ['cost', 'roi', 'ctr', 'cvr'], compatibleSubjects: ['material'] },
  { dimensionId: 'campaign', label: '计划', aliases: ['计划', 'campaign'], level: 'campaign', compatibleMetrics: ['cost', 'roi', 'ctr', 'cvr'], compatibleSubjects: ['campaign', 'account'] },
];
