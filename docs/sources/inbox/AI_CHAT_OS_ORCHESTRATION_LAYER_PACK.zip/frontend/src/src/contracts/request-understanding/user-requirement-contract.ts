export type IntentId =
  | 'report_query'
  | 'trend_query'
  | 'performance_analysis'
  | 'diagnosis'
  | 'comparison'
  | 'drill_down'
  | 'material_analysis'
  | 'workflow_execution'
  | 'task_schedule'
  | 'export_result'
  | 'permission_request'
  | 'help';

export type BusinessSubject =
  | 'account'
  | 'campaign'
  | 'adgroup'
  | 'ad'
  | 'material'
  | 'creative'
  | 'product'
  | 'audience'
  | 'keyword'
  | 'landing_page';

export type RequestedView =
  | 'summary'
  | 'trend'
  | 'table'
  | 'chart'
  | 'comparison'
  | 'diagnosis'
  | 'attribution'
  | 'ranking'
  | 'breakdown'
  | 'export'
  | 'analysis';

export type Granularity = 'hour' | 'day' | 'week' | 'month' | 'quarter';

export type MetricRef = {
  metricId: string;
  label?: string;
};

export type DimensionRef = {
  dimensionId: string;
  label?: string;
};

export type FilterSpec = {
  field: string;
  operator: 'eq' | 'neq' | 'in' | 'not_in' | 'gt' | 'gte' | 'lt' | 'lte' | 'contains';
  value: unknown;
};

export type DateRangeSpec =
  | { type: 'relative'; value: 'today' | 'yesterday' | 'last_7_days' | 'last_30_days' | 'last_90_days' }
  | { type: 'absolute'; start: string; end: string };

export type OutputPreference = {
  preferredRegions?: string[];
  preferredComponentBindings?: string[];
  chartTypeHint?: 'line' | 'bar' | 'pie' | 'area' | 'sankey' | 'table';
};

export type SlotValue = {
  slotId: string;
  value: unknown;
  source: 'message' | 'context' | 'default' | 'dictionary' | 'user_confirmation';
  confidence: number;
};

export type AmbiguityState = {
  hasAmbiguity: boolean;
  candidates?: Array<{ value: string; confidence: number; reason?: string }>;
};

export type ClarificationRequest = {
  reason: string;
  question: string;
  options?: Array<{
    label: string;
    value: string;
    resultingRequirementPatch?: Partial<UserRequirementContract>;
  }>;
  blocking: boolean;
};

export type ContextRef = {
  type: 'lastRequirement' | 'lastSemanticResult' | 'selectedRegion' | 'selectedRows' | 'userPinnedContext';
  id?: string;
};

export type UserRequirementContract = {
  contractVersion: string;
  requestId: string;
  rawUserMessage: string;
  intent: IntentId;
  taskType:
    | 'report_query'
    | 'trend_query'
    | 'analysis'
    | 'diagnosis'
    | 'comparison'
    | 'workflow_execution'
    | 'export'
    | 'configuration';
  businessDomain?: string;
  requestedSubject?: BusinessSubject;
  requestedView?: RequestedView;
  metrics?: MetricRef[];
  dimensions?: DimensionRef[];
  filters?: FilterSpec[];
  dateRange?: DateRangeSpec;
  granularity?: Granularity;
  outputPreference?: OutputPreference;
  requiredDatasetAuthority?: string[];
  requiredCapabilities?: string[];
  slots: SlotValue[];
  confidence: number;
  ambiguity?: AmbiguityState;
  clarification?: ClarificationRequest;
  contextRefs?: ContextRef[];
  locale?: string;
};

export type ValidationIssue = {
  path: string;
  code: string;
  message: string;
  severity: 'error' | 'warning';
};

export type ValidationResult = {
  valid: boolean;
  issues: ValidationIssue[];
};

export function validateUserRequirementContract(input: unknown): ValidationResult {
  const issues: ValidationIssue[] = [];
  const value = input as Partial<UserRequirementContract>;

  if (!value || typeof value !== 'object') {
    return { valid: false, issues: [{ path: '$', code: 'invalid_type', message: 'UserRequirementContract must be an object.', severity: 'error' }] };
  }

  if (!value.contractVersion) issues.push({ path: 'contractVersion', code: 'required', message: 'contractVersion is required.', severity: 'error' });
  if (!value.requestId) issues.push({ path: 'requestId', code: 'required', message: 'requestId is required.', severity: 'error' });
  if (!value.rawUserMessage) issues.push({ path: 'rawUserMessage', code: 'required', message: 'rawUserMessage is required.', severity: 'error' });
  if (!value.intent) issues.push({ path: 'intent', code: 'required', message: 'intent is required.', severity: 'error' });
  if (typeof value.confidence !== 'number') issues.push({ path: 'confidence', code: 'required', message: 'confidence must be a number.', severity: 'error' });

  if (value.requestedView === 'trend') {
    if (!value.dateRange) issues.push({ path: 'dateRange', code: 'required_for_trend', message: 'dateRange is required for trend requests.', severity: 'error' });
    if (!value.granularity) issues.push({ path: 'granularity', code: 'required_for_trend', message: 'granularity is required for trend requests.', severity: 'error' });
  }

  if (value.requestedSubject === 'material' && ['report_query', 'trend_query', 'analysis', 'diagnosis'].includes(String(value.taskType))) {
    if (!value.requiredDatasetAuthority?.includes('material-performance')) {
      issues.push({ path: 'requiredDatasetAuthority', code: 'material_authority_missing', message: 'material requests should require material-performance authority.', severity: 'warning' });
    }
  }

  return { valid: issues.every((issue) => issue.severity !== 'error'), issues };
}
