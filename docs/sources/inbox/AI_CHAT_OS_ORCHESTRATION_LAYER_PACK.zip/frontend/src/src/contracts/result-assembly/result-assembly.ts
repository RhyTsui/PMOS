import type { RoutingTrace } from '../request-understanding/routing-trace';
import type { UserRequirementContract } from '../request-understanding/user-requirement-contract';
import type { NormalizedToolResult } from '../mcp/tool-output-adapter';

export type SemanticResultContractLike = {
  contractVersion: string;
  resultId: string;
  screenType: string;
  regions: Array<{
    regionId: string;
    regionType: string;
    componentBinding: string;
    data: unknown;
    evidenceRefs?: string[];
    sourceRefs?: string[];
  }>;
  sourceRefs?: Array<Record<string, unknown>>;
  evidenceRefs?: Array<Record<string, unknown>>;
  actions?: Array<Record<string, unknown>>;
  warnings?: string[];
};

export type ResultAssemblyInput = {
  requirement: UserRequirementContract;
  routingTrace: RoutingTrace;
  runtimeTraceId?: string;
  toolResults: NormalizedToolResult[];
};

export function assembleSemanticResult(input: ResultAssemblyInput): SemanticResultContractLike {
  const first = input.toolResults[0];
  const rows = first?.rows ?? [];
  const resultId = `semantic_${input.requirement.requestId}`;
  const regions: SemanticResultContractLike['regions'] = [];

  regions.push({
    regionId: 'summary',
    regionType: 'summary',
    componentBinding: 'markdown-result',
    data: { markdown: first?.summary ?? '已根据你的请求生成结果。' },
    sourceRefs: first?.sourceRefs?.map((s) => s.sourceId),
  });

  if (input.requirement.requestedView === 'trend' && rows.length >= 2) {
    regions.push({
      regionId: 'trend-chart',
      regionType: 'visualization',
      componentBinding: 'data-visualization',
      data: {
        chartType: input.requirement.outputPreference?.chartTypeHint ?? 'line',
        dataset: rows,
        metrics: input.requirement.metrics?.map((m) => m.metricId) ?? [],
        dimensions: input.requirement.dimensions?.map((d) => d.dimensionId) ?? [],
      },
      sourceRefs: first?.sourceRefs?.map((s) => s.sourceId),
    });
  } else if (input.requirement.requestedView === 'trend' && rows.length < 2) {
    regions.push({
      regionId: 'insufficient-data',
      regionType: 'warning',
      componentBinding: 'markdown-result',
      data: { markdown: '当前数据点不足，无法生成趋势图。请扩大时间范围或查看明细表。' },
      sourceRefs: first?.sourceRefs?.map((s) => s.sourceId),
    });
  }

  if (rows.length > 0) {
    regions.push({
      regionId: 'data-table',
      regionType: 'table',
      componentBinding: 'data-table',
      data: { rows },
      sourceRefs: first?.sourceRefs?.map((s) => s.sourceId),
    });
  }

  return {
    contractVersion: '1.0',
    resultId,
    screenType: 'report-analysis',
    regions,
    sourceRefs: input.toolResults.flatMap((r) => r.sourceRefs),
    warnings: input.toolResults.flatMap((r) => r.warnings ?? []),
  };
}
