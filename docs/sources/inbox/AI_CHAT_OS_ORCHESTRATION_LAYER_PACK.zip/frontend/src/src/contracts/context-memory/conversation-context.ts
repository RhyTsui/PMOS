import type { DateRangeSpec, UserRequirementContract } from '../request-understanding/user-requirement-contract';

export type ConversationContextSnapshot = {
  conversationId: string;
  lastRequirement?: UserRequirementContract;
  lastSemanticResultId?: string;
  lastRuntimeTraceId?: string;
  activeSubject?: string;
  activeMetrics?: string[];
  activeDimensions?: string[];
  activeDateRange?: DateRangeSpec;
  activeGranularity?: string;
  activeCapabilityId?: string;
  activeDatasetAuthority?: string[];
  expiresAt?: string;
};

export function isContextExpired(context: ConversationContextSnapshot, now = new Date()): boolean {
  return Boolean(context.expiresAt && new Date(context.expiresAt).getTime() < now.getTime());
}
