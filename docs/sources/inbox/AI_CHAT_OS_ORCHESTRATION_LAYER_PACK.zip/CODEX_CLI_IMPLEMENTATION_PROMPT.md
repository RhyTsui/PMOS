# Codex CLI Implementation Prompt

请按照 `docs/architecture/02_ORCHESTRATION_LAYER_INDEX.md` 实施 Request Understanding & Capability Orchestration。

## 第一阶段：只做架构补齐，不改视觉

1. 将本包的 docs 和 frontend/src/src/contracts 文件合入项目。
2. 更新 `ENTERPRISE_AI_CHAT_OS_SPEC.md`，增加 `ENTERPRISE_AI_CHAT_OS_SPEC_ORCHESTRATION_PATCH.md` 中的总纲补丁。
3. 新增或对齐 `UserRequirementContract`、`CapabilityManifest`、`RoutingTrace` 类型真源。
4. 将 MCP tools 通过 `normalizeMcpToolToCapability()` 归一成 CapabilityManifest。
5. 将现有 `intent-router.ts` 输出升级为 `UserRequirementContract`，不要只输出 intent string。
6. 将 `report-query-orchestrator.ts` 中的工具选择改为 `selectCapability(requirement, capabilities)`。
7. 禁止在 router、orchestrator、prompt 中写死 `素材 -> get_zt_ad_mat_report`。
8. 当 `requestedSubject = material` 且 `requiredDatasetAuthority = material-performance` 时，素材能力应作为 primary；日报能力只能作为 fallback。
9. fallback 必须写入 RoutingTrace，并在 SemanticResultContract 的 warnings/sourceRefs/evidenceRefs 中披露。
10. 将工具输出通过 Result Assembly 进入 SemanticResultContract，不得直接渲染旧私有 schema。
11. 增加 golden tests：
    - “看下素材数据”不得 primary 调用 account daily report。
    - “近30天素材消耗和ROI趋势”必须选择 material-performance capability。
    - “今天大盘日报”必须选择 account daily report capability。
    - 素材能力不可用时允许 fallback，但必须 disclosure。
12. 接入 `scripts/guardrails/check-routing-governance.ts`。

## 禁止实现方式

```txt
if (query.includes("素材")) return "get_zt_ad_mat_report"
```

正确实现方式：

```txt
用户请求 -> UserRequirementContract -> CapabilityManifest -> SelectionPolicy -> RoutingTrace -> ToolInvocationPlan
```
