# Skill Manifest

## 目标

定义该 Skill 的身份、触发条件、适用域、依赖能力、默认配置和输出契约。

## Manifest 示例

```json
{
  "skillId": "android-attribution-callback-diagnosis",
  "version": "0.1.0",
  "name": "Android 归因与回推问题排查",
  "category": "diagnosis",
  "domain": "ad-attribution-diagnosis",
  "description": "用于 Android 媒体归因、SDK/API 回推、PAY 未回传、联调失败等链路排查。",
  "enabled": true,
  "routing": {
    "topIntent": "diagnosis",
    "candidateRoutes": [
      "ad_attribution_diagnosis",
      "integration_debugging",
      "data_quality_review"
    ],
    "triggerTerms": [
      "安卓归因",
      "Android回推",
      "媒体没收到",
      "PAY没回传",
      "SDK回推",
      "API回推",
      "804",
      "feedback-res",
      "联调失败",
      "回传失败",
      "归因失败"
    ],
    "excludeRoutes": [
      "plain_report_query",
      "creative_analysis",
      "budget_recommendation"
    ]
  },
  "defaults": {
    "app_package_type": "ANDROID",
    "event_type": "PAY",
    "media_id": "10002"
  },
  "slotSchemaRef": "android-attribution-callback-diagnosis.slot-schema",
  "capabilityRequirementsRef": "android-attribution-callback-diagnosis.capabilities",
  "workflowRef": "android-attribution-callback-diagnosis.workflow",
  "promptFragmentRefs": [
    "diagnosis-role",
    "evidence-first-policy",
    "slot-clarification-policy",
    "branch-judgement-policy",
    "result-assembly-policy",
    "forbidden-patterns"
  ],
  "resultScreenType": "diagnosis-attribution-callback",
  "visibility": {
    "user": "enabled",
    "admin": "debuggable"
  }
}
```

## 注意

`triggerTerms` 只是候选召回，不等于硬路由。最终是否进入 Skill 需要结合：

```txt
RouteDecision
+ Slot Resolution
+ CapabilityPreflight
+ Policy
```
