# Evidence Policy

## 目标

根因判断必须来自工具返回的 evidence，而不是模型猜测。

## 四类基础证据

最终诊断结论应尽量覆盖：

1. 基础事件证据
   - PAY 是否入仓
   - 身份字段是否完整
   - 订单和金额是否完整

2. 归因链路证据
   - attr-require 是否存在
   - attr-res 是否存在
   - 归因媒体是否匹配目标媒体

3. 回推配置证据
   - callbackMode
   - callbackModeDetail
   - PAY 规则
   - OPEN 规则数

4. 分支闭环证据
   - SDK：SDK income / 804
   - API：feedback-res
   - NOTHING：配置不回推证据

## EvidenceRef

```ts
type SkillEvidenceRef = {
  evidenceId: string
  evidenceType:
    | 'base_event'
    | 'attribution_preprocess'
    | 'callback_rule'
    | 'sdk_delivery'
    | 'api_feedback'
    | 'config_sample'
    | 'tool_catalog'
  toolCapability: string
  toolName?: string
  sampleCount?: number
  summary: string
  rawRef?: string
  confidence: 'high' | 'medium' | 'low'
}
```

## 禁止

1. 不允许单个异常样本直接成为最终根因。
2. 不允许没有 evidenceRefs 的根因判断。
3. 不允许 SDK 分支要求 feedback-res。
4. 不允许 API 分支使用 SDK income / 804 作为主证据。
5. 不允许 callbackMode = NOTHING 时继续判定回推失败。
