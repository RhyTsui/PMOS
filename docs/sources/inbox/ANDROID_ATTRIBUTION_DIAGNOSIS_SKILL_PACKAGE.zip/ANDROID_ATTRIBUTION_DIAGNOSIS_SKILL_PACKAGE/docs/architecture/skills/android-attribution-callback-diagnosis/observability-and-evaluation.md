# Observability and Evaluation

## Trace 对象

每次执行应记录：

```txt
skillRunId
userMessage
RouteDecision
SlotResolution
CapabilityPreflight
WorkflowRuntime
ToolCalls
EvidenceRefs
BranchDecision
SemanticResultContract validation
Renderer errors
```

## Telemetry 事件

```txt
skill_candidate_selected
skill_preflight_failed
skill_slot_clarification_requested
skill_workflow_step_started
skill_workflow_step_completed
skill_workflow_step_failed
skill_branch_decided
skill_evidence_missing
skill_result_assembled
skill_semantic_contract_invalid
```

## 指标

```txt
调用量
成功率
澄清率
MCP 未挂载率
工具失败率
平均耗时
证据不足率
SDK/API/NOTHING/config_anomaly 分支分布
Golden Case 通过率
```
