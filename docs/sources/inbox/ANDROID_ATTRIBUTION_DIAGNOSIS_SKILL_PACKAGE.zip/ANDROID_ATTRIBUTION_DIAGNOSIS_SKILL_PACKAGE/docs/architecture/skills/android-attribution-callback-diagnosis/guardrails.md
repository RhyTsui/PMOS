# Guardrails

## 架构 Guardrails

1. 不允许把原始 prompt 作为全局 system prompt。
2. 不允许 Skill 直接调用 toolName，必须通过 capability binding。
3. 不允许 workflow 外部绕过 slot validation 调业务工具。
4. 不允许最终结果只输出 Markdown。
5. 不允许根因判断没有 evidenceRefs。

## 业务 Guardrails

1. 不要跳过基础事件和归因链路，直接判定回推失败。
2. 不要把 SDK 分支要求 feedback-res。
3. 不要在 callbackMode = NOTHING 时继续判回推失败。
4. 不要把 API 分支当 SDK 分支处理。
5. 不要把 SDK income / 804 当 API 主证据。
6. PAY 场景默认跳过 `query_attr_clue_event_detail`。
7. 工具失败或证据不完整时不得硬判根因。

## 静态检查建议

检查代码中是否出现：

```txt
直接调用 check_* toolName
没有 capability binding
没有 slot validation
没有 evidenceRefs 的 rootCause
SemanticResultContract 缺少 evidence-panel
```
