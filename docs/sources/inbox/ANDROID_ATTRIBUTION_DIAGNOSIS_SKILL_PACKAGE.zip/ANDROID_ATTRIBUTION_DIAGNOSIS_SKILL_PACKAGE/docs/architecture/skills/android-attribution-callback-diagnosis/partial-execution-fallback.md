# Partial Execution and Fallback Policy

## 能力缺失分类

### 1. Skill 不可执行

缺少核心能力：

```txt
tool.catalog.list
app_context.resolve
base_event_ingestion.check
attr_preprocess_result.check
callback_rule_match.check
```

行为：

```txt
停止执行，说明能力不可用，不输出证据级根因。
```

### 2. 分支能力缺失

例如 API 分支缺少 retry/log 工具，但主分支可执行。

行为：

```txt
继续完成主链路，最终结果披露证据缺口。
```

### 3. Slot 缺失

缺少 `date_start` / `date_end`。

行为：

```txt
先澄清，不执行业务工具。
```

### 4. 工具失败

工具返回错误或 evidence_items 不完整。

行为：

```txt
不硬判根因；尝试原子工具复核或披露证据不足。
```

## Disclosure 文案

```txt
当前缺少 {{missingCapability}} 能力，无法完成 {{branch}} 分支的证据闭环；以下结论仅基于已获取证据，不能作为最终根因。
```
