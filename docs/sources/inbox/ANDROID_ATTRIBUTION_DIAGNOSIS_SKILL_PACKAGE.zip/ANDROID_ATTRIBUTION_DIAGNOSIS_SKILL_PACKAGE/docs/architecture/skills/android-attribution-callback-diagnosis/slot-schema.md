# Slot Schema

## 目标

把原提示词中的默认值、必填项、可选定位字段变成可校验的 slot schema。

## Slot 定义

```json
{
  "schemaId": "android-attribution-callback-diagnosis.slot-schema",
  "required": [
    "app_query_or_app_id",
    "date_start",
    "date_end"
  ],
  "defaults": {
    "app_package_type": "ANDROID",
    "event_type": "PAY",
    "media_id": "10002"
  },
  "slots": {
    "app_query_or_app_id": {
      "type": "string",
      "description": "游戏名、应用描述或 app_id。若是纯数字 app_id，作为 app_query 精确查询。"
    },
    "date_start": {
      "type": "date",
      "required": true,
      "clarification": "请补充排查开始日期，例如 2026-05-01。"
    },
    "date_end": {
      "type": "date",
      "required": true,
      "clarification": "请补充排查结束日期，例如 2026-05-03。"
    },
    "media_id": {
      "type": "string",
      "default": "10002"
    },
    "media_query": {
      "type": "string",
      "description": "媒体名称、简称或模糊描述，例如 taptap、腾讯、巨量。"
    },
    "event_type": {
      "type": "string",
      "default": "PAY"
    },
    "app_package_type": {
      "type": "enum",
      "values": ["ANDROID", "IOS", "HARMONY"],
      "default": "ANDROID"
    },
    "device_id": { "type": "string" },
    "user_id": { "type": "string" },
    "order_id": { "type": "string" },
    "app_version": { "type": "string" },
    "callback_mode": { "type": "string" },
    "problem_desc": {
      "type": "string",
      "description": "仅用于服务端日志追踪，不是工具字段匹配主条件。"
    }
  }
}
```

## 澄清规则

1. 缺少 `date_start` 或 `date_end`：必须追问，不得执行业务工具。
2. 应用候选多：必须让用户选择 app_id/app_name。
3. 媒体候选多：必须让用户选择 media_id/media_name。
4. `media_id` 是数字且用户明确提供时，不再额外查媒体。
5. 未提供 `media_id` 或 `media_query` 时，默认 `media_id = 10002`。
