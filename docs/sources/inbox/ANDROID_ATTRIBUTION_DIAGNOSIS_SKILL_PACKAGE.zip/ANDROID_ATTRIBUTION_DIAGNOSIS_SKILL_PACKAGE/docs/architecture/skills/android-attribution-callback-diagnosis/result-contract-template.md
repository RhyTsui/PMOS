# Result Contract Template

## 目标

Skill 最终输出必须进入 `SemanticResultContract`，不能只返回 Markdown。

## screenType

```txt
diagnosis-attribution-callback
```

## regions

```json
[
  {
    "regionType": "summary",
    "componentBinding": "markdown-result"
  },
  {
    "regionType": "diagnosis-status",
    "componentBinding": "decision-card"
  },
  {
    "regionType": "workflow-trace",
    "componentBinding": "workflow-trace"
  },
  {
    "regionType": "evidence",
    "componentBinding": "evidence-panel"
  },
  {
    "regionType": "source",
    "componentBinding": "source-list"
  },
  {
    "regionType": "next-actions",
    "componentBinding": "action-list"
  }
]
```

## 示例

```json
{
  "screenType": "diagnosis-attribution-callback",
  "regions": [
    {
      "regionType": "summary",
      "componentBinding": "markdown-result",
      "data": {
        "markdown": "本次排查显示：PAY 基础事件已入仓，attr-res 已产出，配置为 SDK 策略回推，但 SDK income 存在后未观察到 804 闭环。"
      }
    },
    {
      "regionType": "diagnosis-status",
      "componentBinding": "decision-card",
      "data": {
        "status": "needs_engineering_review",
        "branch": "SDK_POLICY",
        "rootCause": "SDK 闭环状态缺失",
        "confidence": "medium"
      },
      "evidenceRefs": ["ev_base_event", "ev_attr_res", "ev_callback_rule", "ev_sdk_delivery"]
    },
    {
      "regionType": "workflow-trace",
      "componentBinding": "workflow-trace",
      "runtimeRefs": ["run_android_attr_diag_xxx"]
    },
    {
      "regionType": "evidence",
      "componentBinding": "evidence-panel",
      "data": {
        "groups": ["base_event", "attribution_preprocess", "callback_rule", "sdk_delivery"]
      }
    },
    {
      "regionType": "next-actions",
      "componentBinding": "action-list",
      "data": {
        "actions": [
          {
            "actionType": "follow_up",
            "label": "补充 app_version 复核版本门槛"
          },
          {
            "actionType": "retry_step",
            "label": "继续检查 SDK 804 明细"
          },
          {
            "actionType": "handoff",
            "label": "提交研发排查"
          }
        ]
      }
    }
  ],
  "sourceRefs": [
    {
      "sourceType": "mcp-tool-result",
      "label": "广告归因排查 MCP"
    }
  ]
}
```
