# Capability Requirements

## 目标

Skill 不直接依赖具体 MCP toolName，而是依赖抽象 capability。

## Capability 列表

```json
{
  "capabilitySetId": "android-attribution-callback-diagnosis.capabilities",
  "requiredCapabilities": [
    "tool.catalog.list",
    "app_context.resolve",
    "base_event_ingestion.check",
    "attr_preprocess_result.check",
    "callback_rule_match.check"
  ],
  "optionalCapabilities": [
    "media_context.resolve",
    "callback_rule_config.query"
  ],
  "branchCapabilities": {
    "sdk": [
      "sdk_integration.check",
      "callback_delivery_trace.check"
    ],
    "api": [
      "api_callback_result.check",
      "api_callback_retry_detail.check",
      "api_callback_log_detail.query"
    ],
    "config_anomaly": [
      "callback_rule_config.query"
    ],
    "pay_event_skip": [
      "attr_clue_event_detail.query"
    ]
  }
}
```

## 当前 MCP 工具名映射示例

| Capability | 当前工具名示例 | 说明 |
|---|---|---|
| `tool.catalog.list` | `list_exposed_tool_catalog` | 获取 exposed/published 工具与 schema |
| `app_context.resolve` | `fetch_app_context` | 解析应用上下文 |
| `media_context.resolve` | `fetch_media_context` | 解析媒体上下文 |
| `base_event_ingestion.check` | `check_base_event_ingestion` | 检查基础事件入仓 |
| `attr_preprocess_result.check` | `check_attr_preprocess_result` | 检查 attr-require / attr-res |
| `callback_rule_match.check` | `check_callback_rule_match` | 检查回推规则匹配 |
| `callback_rule_config.query` | `query_callback_rule_config` | 复核原始配置 |
| `sdk_integration.check` | `check_app_sdk_integration` | 检查 GSSDK 接入与版本门槛 |
| `callback_delivery_trace.check` | `check_callback_delivery_trace` | 检查 SDK income / 804 |
| `api_callback_result.check` | `check_api_callback_result` | 检查 feedback-res |
| `api_callback_retry_detail.check` | `check_api_callback_retry_detail` | API 失败重试明细 |
| `api_callback_log_detail.query` | `query_api_callback_log_detail` | API 请求日志明细 |
| `attr_clue_event_detail.query` | `query_attr_clue_event_detail` | PAY 场景默认跳过 |

## Preflight 规则

1. 每次执行前先获取 tool catalog。
2. 校验当前 capability 是否存在对应 exposed/published tool。
3. 校验 tool `required_fields` 是否齐全。
4. 缺少必填参数时返回 clarification，不得继续调用。
5. 某个 branch capability 缺失时，允许部分执行，但必须在最终结果披露证据缺口。
6. MCP 未挂载时，Skill 可以返回“能力不可用”的解释，但不能输出证据级根因。
