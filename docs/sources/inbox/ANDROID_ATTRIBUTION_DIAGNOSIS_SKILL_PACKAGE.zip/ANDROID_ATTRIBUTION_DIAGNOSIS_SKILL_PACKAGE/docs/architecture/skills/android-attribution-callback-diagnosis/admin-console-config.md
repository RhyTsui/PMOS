# Admin Console Configuration

## 管理中心对象

需要新增或关联：

```txt
Skill Registry
MCP Registry
Capability Binding
Workflow Registry
Prompt Fragment Registry
Slot Schema Registry
Golden Case Registry
Observability Dashboard
```

## 页面建议

### Skill 详情页

展示：

```txt
Skill ID
版本
启用状态
触发规则
Slot Schema
依赖能力
绑定 Workflow
绑定 Prompt Fragments
Golden Cases
运行数据
```

### Capability Binding 页

展示：

```txt
Capability -> MCP toolName
tool exposed 状态
tool published 状态
required_fields
optional_fields
last health check
权限
```

### Workflow 页

展示：

```txt
DAG 图
Step 状态
分支规则
重试策略
超时策略
```

### Observability 页

展示：

```txt
Skill 调用次数
成功率
澄清率
fallback 率
证据不足率
MCP tool 失败率
平均耗时
branch 分布
```
