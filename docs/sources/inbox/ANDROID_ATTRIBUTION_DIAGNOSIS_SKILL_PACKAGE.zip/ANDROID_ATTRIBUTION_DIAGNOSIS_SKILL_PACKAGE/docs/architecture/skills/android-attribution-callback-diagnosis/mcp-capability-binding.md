# MCP Capability Binding

## 目标

把管理中心配置的 MCP tools 映射为 Skill 可使用的 capabilities。

## 绑定原则

```txt
MCP Server
  -> Tools
  -> Tool Schema
  -> CapabilityManifest
  -> Skill Capability Requirements
```

Skill 不应直接知道 MCP server URL，也不应把工具名写进总纲或全局路由。

## 绑定示例

```json
{
  "bindingId": "android-attribution-diagnosis-mcp.binding",
  "mcpServerId": "ad-attribution-diagnosis-mcp",
  "skillId": "android-attribution-callback-diagnosis",
  "toolBindings": {
    "tool.catalog.list": {
      "toolName": "list_exposed_tool_catalog"
    },
    "app_context.resolve": {
      "toolName": "fetch_app_context"
    },
    "media_context.resolve": {
      "toolName": "fetch_media_context"
    },
    "base_event_ingestion.check": {
      "toolName": "check_base_event_ingestion"
    },
    "attr_preprocess_result.check": {
      "toolName": "check_attr_preprocess_result"
    },
    "callback_rule_match.check": {
      "toolName": "check_callback_rule_match"
    },
    "callback_rule_config.query": {
      "toolName": "query_callback_rule_config"
    },
    "sdk_integration.check": {
      "toolName": "check_app_sdk_integration"
    },
    "callback_delivery_trace.check": {
      "toolName": "check_callback_delivery_trace"
    },
    "api_callback_result.check": {
      "toolName": "check_api_callback_result"
    },
    "api_callback_retry_detail.check": {
      "toolName": "check_api_callback_retry_detail"
    },
    "api_callback_log_detail.query": {
      "toolName": "query_api_callback_log_detail"
    },
    "attr_clue_event_detail.query": {
      "toolName": "query_attr_clue_event_detail",
      "skipWhen": {
        "event_type": "PAY"
      }
    }
  }
}
```

## 如果 MCP 未挂载

返回：

```json
{
  "executable": false,
  "reason": "missing_capability_provider",
  "missingCapabilities": [
    "tool.catalog.list",
    "app_context.resolve",
    "base_event_ingestion.check"
  ],
  "userMessage": "当前未接入广告归因排查 MCP，无法完成证据级链路排查。"
}
```
