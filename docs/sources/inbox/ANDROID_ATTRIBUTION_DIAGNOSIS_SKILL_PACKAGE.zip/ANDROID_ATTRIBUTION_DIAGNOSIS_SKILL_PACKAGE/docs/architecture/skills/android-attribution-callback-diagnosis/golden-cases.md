# Golden Cases

## 目标

覆盖 happy path、缺字段、候选选择、能力缺失、分支判断和证据不足。

## 必备 Case

1. 缺少 date_start/date_end，必须澄清。
2. 游戏名返回多个 app 候选，必须让用户选择。
3. 媒体名称模糊，必须让用户选择或使用默认媒体。
4. 基础事件不存在，停止并结论为事件未上报/未入仓。
5. 基础事件存在但 attr-require 缺失，停止为未进入归因预处理。
6. attr-require 存在但 attr-res 缺失，结论为未归因成功或归因结果缺失。
7. attr-res 的媒体不是目标媒体，不判目标媒体回推失败。
8. callbackMode = NOTHING，停止下游回推排查。
9. SDK 策略回推，income 存在但 804 缺失。
10. API 回推，attr-res 存在但 feedback-res 缺失。
11. MCP 未挂载，返回能力不可用，不输出证据级根因。
12. 部分 branch capability 缺失，返回部分结论并披露证据缺口。

## 输出验收

每个 golden case 需要断言：

```txt
RouteDecision
SlotResolution
CapabilityPreflight
Workflow steps
Branch decision
EvidenceRefs
SemanticResultContract regions
User-facing disclosure
```
