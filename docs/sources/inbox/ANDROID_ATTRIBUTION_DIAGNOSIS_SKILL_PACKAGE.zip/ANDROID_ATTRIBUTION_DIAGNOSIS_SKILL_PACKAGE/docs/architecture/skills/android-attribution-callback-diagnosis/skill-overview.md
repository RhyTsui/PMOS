# Skill Overview：Android 归因与回推问题排查

Skill ID：`android-attribution-callback-diagnosis`

## 背景

原始 `安卓归因问题排查prompt.md` 已经包含角色、默认场景、工具调用原则、主排查链路、SDK/API/不回推分支、最终输出要求和禁止事项。它不是普通文案提示词，而是一个诊断 playbook。

## 总纲落点

```txt
Enterprise AI Chat OS
└─ Skill System
   └─ Diagnosis Skill
      └─ android-attribution-callback-diagnosis
```

该 Skill 横跨：

```txt
Request Understanding
Capability Orchestration
MCP Governance
Workflow Runtime
AI Trust UX
Unified Semantic Contract
Observability & Evaluation
```

## Skill 边界

该 Skill 适用于：

- Android 归因异常
- 媒体回推失败
- SDK 回推链路排查
- API 回推链路排查
- PAY 事件未回推
- 804 闭环异常
- feedback-res 缺失
- 联调失败排查
- 媒体侧未收到数据
- 数据准确性复核中的归因/回推链路校验

不适用于：

- 普通报表问数
- 纯趋势查询
- 素材表现分析
- 广告预算建议
- 不涉及归因/回推链路的数据看板

## 三种调用模式

### 1. 主 Skill 模式

用户明确询问归因、回推、SDK/API、PAY 未回传、联调失败等问题时，直接进入本 Skill。

### 2. 子流程复核模式

用户在更大的数据准确性复核或联调排查中，需要验证归因/回推链路时，本 Skill 作为子 workflow 被调用。

### 3. 原子 capability 模式

如果用户只想检查一个环节，例如“PAY 是否入仓”，可以只调用 `base_event_ingestion.check` capability，不必跑完整 workflow。

## 设计原则

1. Skill 依赖 capability，不直接绑定具体 toolName。
2. MCP 是 capability provider，不是 Skill 本身。
3. Workflow 管步骤，Prompt 管表达，Evidence 管可信。
4. 缺少必填字段时必须澄清。
5. MCP 不存在或能力缺失时不得输出证据级根因。
6. 最终输出必须挂证据、来源和下一步动作。
