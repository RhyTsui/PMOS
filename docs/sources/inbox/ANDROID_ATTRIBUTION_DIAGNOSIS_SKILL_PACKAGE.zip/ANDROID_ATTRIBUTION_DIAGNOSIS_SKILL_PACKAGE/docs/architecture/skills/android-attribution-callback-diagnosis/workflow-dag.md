# Workflow DAG

## 目标

把原提示词里的主排查链路变成可执行、可观测、可回放的 workflow。

## DAG

```txt
list_tool_catalog
-> resolve_app_context
-> resolve_media_context? 
-> check_base_event_ingestion
-> check_attr_preprocess_result
-> check_callback_rule_match
-> branch_by_callback_mode
   ├─ SDK -> check_app_sdk_integration -> check_callback_delivery_trace
   ├─ API -> check_api_callback_result -> optional retry/log detail
   ├─ NOTHING -> stop
   └─ CONFIG_ANOMALY -> query_callback_rule_config
```

## 分支规则

### SDK 策略回推

条件：

```txt
callbackModeDetail = SDK
callbackMode = ALL_RULE
PAY 事件规则存在且 OPEN
```

后续：

```txt
check_app_sdk_integration
-> check_callback_delivery_trace
```

### SDK 全量回推

条件：

```txt
callbackModeDetail = SDK
callbackMode = NO_RULE
```

后续：

```txt
check_app_sdk_integration
-> check_callback_delivery_trace
```

### API 回推

条件：

```txt
callbackModeDetail = API
```

后续：

```txt
check_api_callback_result
```

可选深挖：

```txt
check_api_callback_retry_detail
query_api_callback_log_detail
```

### 不回推

条件：

```txt
callbackMode = NOTHING
```

后续：

```txt
停止 SDK income / 804 / feedback-res 排查
```

### 配置异常

条件：

```txt
callbackMode 缺失
callbackModeDetail 缺失
组合不符合 SDK/API/NOTHING
事件规则缺失但配置声称规则回推
```

后续：

```txt
query_callback_rule_config
```

## Runtime 展示

普通用户只展示：

```txt
正在解析应用
正在检查基础事件
正在检查归因链路
正在检查回推配置
当前分支：SDK/API/不回推/配置异常
已完成排查
```

管理员可展开：

```txt
Tool calls
Tool inputs
Tool outputs summary
Latency
Errors
Evidence ids
```
