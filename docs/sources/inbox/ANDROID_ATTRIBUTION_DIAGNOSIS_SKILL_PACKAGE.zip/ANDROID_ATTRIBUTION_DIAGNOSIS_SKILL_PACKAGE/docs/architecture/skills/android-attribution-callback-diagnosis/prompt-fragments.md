# Prompt Fragments

## 目标

原始长提示词拆成可治理、可版本化的 prompt fragments。

## Fragment 列表

```txt
diagnosis-role.md
evidence-first-policy.md
slot-clarification-policy.md
branch-judgement-policy.md
result-assembly-policy.md
forbidden-patterns.md
runtime-narration-policy.md
```

## 放置原则

- 角色、表达风格、证据合成放 Prompt。
- 工具顺序、分支、必填字段校验放 Workflow / Slot / Preflight。
- toolName 映射放 Capability Binding。
- 禁止事项同时进入 Prompt、Guardrail 和 Golden Cases。

## 版本治理

每个 fragment 应有：

```txt
promptId
version
owner
status
lastUpdated
changeLog
goldenCases
rollbackVersion
```
