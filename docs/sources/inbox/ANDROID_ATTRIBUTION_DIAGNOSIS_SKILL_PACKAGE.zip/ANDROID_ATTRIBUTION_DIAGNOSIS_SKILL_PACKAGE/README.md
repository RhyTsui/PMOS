# Android Attribution Callback Diagnosis Skill Package

版本：`0.1.0`  
Skill ID：`android-attribution-callback-diagnosis`

本包将 `安卓归因问题排查prompt.md` 从“单一长提示词”升级为 Enterprise AI Chat OS 下的 **诊断型 Skill 工程包**。

## 定位

该 Skill 用于 Android 媒体归因、回推、联调失败、数据准确性复核等问题排查。它不是一个全局 Prompt，也不是一个 MCP 的简单别名，而是由以下对象组成：

```txt
Skill Manifest
+ Slot Schema
+ Capability Requirements
+ MCP Capability Binding
+ Workflow DAG
+ Prompt Fragments
+ Evidence Policy
+ SemanticResultContract Template
+ Runtime Display Rules
+ Golden Cases
+ Guardrails
```

## 架构关系

```txt
Enterprise AI Chat OS
├─ Request Understanding System
│  └─ Skill Routing
│     └─ android-attribution-callback-diagnosis
├─ Capability Orchestration System
│  └─ MCP tools -> CapabilityManifest -> Skill Requirements
├─ Runtime & Agent Orchestration System
│  └─ Workflow DAG + RuntimeDisplayProtocol
├─ Unified Semantic Contract
│  └─ diagnosis result -> regions/evidence/source/actions
└─ Prompt Governance
   └─ prompt fragments, not one monolithic prompt
```

## 使用方式

建议先读：

```txt
CODEX_CLI_IMPLEMENTATION_PROMPT.md
```

然后导入：

```txt
docs/architecture/skills/android-attribution-callback-diagnosis/*
frontend/src/src/contracts/skills/android-attribution-callback-diagnosis/*
management-center/import/*
```

## 关键原则

1. 不把 MCP 等同于 Skill。
2. 不把 24 个 tool 写死进全局 prompt。
3. 不把原始 prompt 直接塞进 system prompt。
4. Tool 先归一化为 capability，再由 Skill/Workflow 使用。
5. Workflow 控制步骤和分支，Prompt 负责证据合成与用户表达。
6. 最终结果必须进入 `SemanticResultContract`。
7. 执行过程必须进入 `RuntimeDisplayProtocol`。
8. 证据级结论必须挂 `evidenceRefs` 和 `sourceRefs`。

## 目录

```txt
docs/architecture/skills/android-attribution-callback-diagnosis/
frontend/src/src/contracts/skills/android-attribution-callback-diagnosis/
management-center/import/
prompts/skills/android-attribution-callback-diagnosis/
source/
```
