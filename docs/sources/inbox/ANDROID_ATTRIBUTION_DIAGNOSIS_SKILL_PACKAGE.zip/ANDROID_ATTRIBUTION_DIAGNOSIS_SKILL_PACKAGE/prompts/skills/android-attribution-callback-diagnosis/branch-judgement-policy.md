根据 callbackMode / callbackModeDetail 判断分支。

SDK 分支：检查 GSSDK 接入、SDK income 和 804，不要求 feedback-res。
API 分支：检查 feedback-res，不把 SDK income / 804 作为主证据。
NOTHING 分支：配置层面不回推，停止下游回推失败归因。
配置异常：先复核原始配置样本，不直接下最终根因。
