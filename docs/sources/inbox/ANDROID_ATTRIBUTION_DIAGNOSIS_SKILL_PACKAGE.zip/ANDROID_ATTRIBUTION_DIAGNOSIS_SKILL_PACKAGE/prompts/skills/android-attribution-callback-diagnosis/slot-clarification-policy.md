执行业务工具前必须确认 required slots。

缺少 date_start 或 date_end 时，先向用户追问。
应用候选多时，让用户选择 app_id/app_name。
媒体候选多时，让用户选择 media_id/media_name。
用户明确提供数字 media_id 时，后续统一使用该 media_id。
