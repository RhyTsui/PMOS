禁止事项：

- 不要跳过基础事件和归因链路直接判回推失败。
- 不要把 SDK 分支要求 feedback-res。
- 不要在 callbackMode = NOTHING 时继续判定为回推失败。
- 不要把 API 分支当 SDK 分支处理。
- 不要把 SDK income / 804 当 API 主证据。
- 不要只看页面结果，必须引用 MCP 工具 evidence。
- 不要在 evidence 不完整时硬判根因。
