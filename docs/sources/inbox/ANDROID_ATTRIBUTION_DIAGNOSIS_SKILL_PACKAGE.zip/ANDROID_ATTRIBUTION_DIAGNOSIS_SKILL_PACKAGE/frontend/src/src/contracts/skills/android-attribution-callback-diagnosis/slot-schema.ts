import type { AndroidAttributionSlotValues } from './types';

export const androidAttributionSlotSchema = {
  schemaId: 'android-attribution-callback-diagnosis.slot-schema',
  required: ['app_query_or_app_id', 'date_start', 'date_end'],
  defaults: {
    app_package_type: 'ANDROID',
    event_type: 'PAY',
    media_id: '10002',
  },
  slots: {
    app_query_or_app_id: { type: 'string' },
    date_start: { type: 'date', required: true },
    date_end: { type: 'date', required: true },
    media_id: { type: 'string', default: '10002' },
    media_query: { type: 'string' },
    event_type: { type: 'string', default: 'PAY' },
    app_package_type: { type: 'enum', values: ['ANDROID', 'IOS', 'HARMONY'], default: 'ANDROID' },
    device_id: { type: 'string' },
    user_id: { type: 'string' },
    order_id: { type: 'string' },
    app_version: { type: 'string' },
    callback_mode: { type: 'string' },
    problem_desc: { type: 'string' },
  },
} as const;

export function applyAndroidAttributionSlotDefaults(
  slots: AndroidAttributionSlotValues,
): AndroidAttributionSlotValues {
  return {
    app_package_type: 'ANDROID',
    event_type: 'PAY',
    media_id: '10002',
    ...slots,
  };
}

export function validateAndroidAttributionSlots(slots: AndroidAttributionSlotValues): {
  valid: boolean;
  missingSlots: string[];
  clarificationMessage?: string;
} {
  const normalized = applyAndroidAttributionSlotDefaults(slots);
  const missingSlots: string[] = [];

  if (!normalized.app_query_or_app_id && !normalized.app_id) missingSlots.push('app_query_or_app_id');
  if (!normalized.date_start) missingSlots.push('date_start');
  if (!normalized.date_end) missingSlots.push('date_end');

  if (missingSlots.length === 0) return { valid: true, missingSlots: [] };

  const missingText = missingSlots
    .map((slot) => {
      if (slot === 'date_start') return '开始日期 date_start';
      if (slot === 'date_end') return '结束日期 date_end';
      if (slot === 'app_query_or_app_id') return '游戏名或 app_id';
      return slot;
    })
    .join('、');

  return {
    valid: false,
    missingSlots,
    clarificationMessage: `需要先补充 ${missingText}，才能进行 Android 归因与回推链路排查。`,
  };
}
