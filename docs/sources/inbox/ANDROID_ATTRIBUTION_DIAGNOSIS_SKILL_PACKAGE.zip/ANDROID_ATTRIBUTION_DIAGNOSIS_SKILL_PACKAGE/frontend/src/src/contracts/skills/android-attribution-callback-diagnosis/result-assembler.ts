import type { AndroidAttributionDiagnosis, SkillEvidenceRef, WorkflowStepResult } from './types';

export type SemanticResultContractLike = {
  screenType: string;
  regions: Array<{
    regionType: string;
    componentBinding: string;
    data?: unknown;
    evidenceRefs?: string[];
    runtimeRefs?: string[];
  }>;
  evidenceRefs?: SkillEvidenceRef[];
  sourceRefs?: Array<Record<string, unknown>>;
};

export function assembleAndroidAttributionSemanticResult(params: {
  diagnosis: AndroidAttributionDiagnosis;
  evidenceRefs: SkillEvidenceRef[];
  workflowSteps: WorkflowStepResult[];
  runtimeRef?: string;
  sourceLabel?: string;
}): SemanticResultContractLike {
  const { diagnosis, evidenceRefs, workflowSteps, runtimeRef, sourceLabel } = params;

  return {
    screenType: 'diagnosis-attribution-callback',
    regions: [
      {
        regionType: 'summary',
        componentBinding: 'markdown-result',
        data: {
          markdown: diagnosis.summary,
        },
        evidenceRefs: diagnosis.evidenceRefs,
      },
      {
        regionType: 'diagnosis-status',
        componentBinding: 'decision-card',
        data: {
          branch: diagnosis.branch,
          rootCause: diagnosis.rootCause,
          confidence: diagnosis.confidence,
          missingEvidence: diagnosis.missingEvidence || [],
        },
        evidenceRefs: diagnosis.evidenceRefs,
      },
      {
        regionType: 'workflow-trace',
        componentBinding: 'workflow-trace',
        runtimeRefs: runtimeRef ? [runtimeRef] : [],
        data: { steps: workflowSteps },
      },
      {
        regionType: 'evidence',
        componentBinding: 'evidence-panel',
        data: { evidenceRefs },
      },
      {
        regionType: 'source',
        componentBinding: 'source-list',
        data: {
          sources: [
            {
              sourceType: 'mcp-tool-result',
              label: sourceLabel || '广告归因排查 MCP',
            },
          ],
        },
      },
      {
        regionType: 'next-actions',
        componentBinding: 'action-list',
        data: { actions: diagnosis.nextActions },
      },
    ],
    evidenceRefs,
    sourceRefs: [
      {
        sourceType: 'mcp-tool-result',
        label: sourceLabel || '广告归因排查 MCP',
      },
    ],
  };
}
