import type { AndroidAttributionSlotValues, CapabilityBinding, CapabilityPreflightResult, SkillCapabilityId } from './types';
import { androidAttributionCapabilityRequirements } from './capability-requirements';
import { validateAndroidAttributionSlots } from './slot-schema';

type PreflightInput = {
  slots: AndroidAttributionSlotValues;
  availableBindings: CapabilityBinding[];
};

export function preflightAndroidAttributionSkill(input: PreflightInput): CapabilityPreflightResult {
  const slotValidation = validateAndroidAttributionSlots(input.slots);
  const bindingMap = new Map<SkillCapabilityId, CapabilityBinding>();

  for (const binding of input.availableBindings) {
    bindingMap.set(binding.capabilityId, binding);
  }

  const requiredCapabilities = androidAttributionCapabilityRequirements.requiredCapabilities as readonly SkillCapabilityId[];
  const missingCapabilities = requiredCapabilities.filter((id) => !bindingMap.has(id));
  const unavailableCapabilities = requiredCapabilities.filter((id) => {
    const binding = bindingMap.get(id);
    return Boolean(binding && (binding.exposed === false || binding.published === false));
  });

  const executable =
    slotValidation.valid && missingCapabilities.length === 0 && unavailableCapabilities.length === 0;

  return {
    executable,
    missingSlots: slotValidation.missingSlots,
    missingCapabilities,
    unavailableCapabilities,
    disclosureRequired: !executable,
    userMessage: executable
      ? undefined
      : slotValidation.clarificationMessage ||
        buildCapabilityMissingMessage(missingCapabilities, unavailableCapabilities),
  };
}

function buildCapabilityMissingMessage(
  missingCapabilities: readonly SkillCapabilityId[],
  unavailableCapabilities: readonly SkillCapabilityId[],
): string {
  if (missingCapabilities.length > 0) {
    return `当前未接入完整的广告归因排查能力，缺少：${missingCapabilities.join('、')}。无法给出证据级根因判断。`;
  }
  if (unavailableCapabilities.length > 0) {
    return `当前部分广告归因排查能力不可用：${unavailableCapabilities.join('、')}。无法完成完整链路排查。`;
  }
  return '当前无法完成 Android 归因与回推链路排查。';
}
