import type { SkillCapabilityId } from './types';

export const androidAttributionCapabilityRequirements = {
  capabilitySetId: 'android-attribution-callback-diagnosis.capabilities',
  requiredCapabilities: [
    'tool.catalog.list',
    'app_context.resolve',
    'base_event_ingestion.check',
    'attr_preprocess_result.check',
    'callback_rule_match.check',
  ] satisfies SkillCapabilityId[],
  optionalCapabilities: ['media_context.resolve', 'callback_rule_config.query'] satisfies SkillCapabilityId[],
  branchCapabilities: {
    sdk: ['sdk_integration.check', 'callback_delivery_trace.check'] satisfies SkillCapabilityId[],
    api: [
      'api_callback_result.check',
      'api_callback_retry_detail.check',
      'api_callback_log_detail.query',
    ] satisfies SkillCapabilityId[],
    config_anomaly: ['callback_rule_config.query'] satisfies SkillCapabilityId[],
  },
} as const;

export const currentMcpCapabilityBindingExample: Record<SkillCapabilityId, { toolName: string; skipWhen?: Record<string, string> }> = {
  'tool.catalog.list': { toolName: 'list_exposed_tool_catalog' },
  'app_context.resolve': { toolName: 'fetch_app_context' },
  'media_context.resolve': { toolName: 'fetch_media_context' },
  'base_event_ingestion.check': { toolName: 'check_base_event_ingestion' },
  'attr_preprocess_result.check': { toolName: 'check_attr_preprocess_result' },
  'callback_rule_match.check': { toolName: 'check_callback_rule_match' },
  'callback_rule_config.query': { toolName: 'query_callback_rule_config' },
  'sdk_integration.check': { toolName: 'check_app_sdk_integration' },
  'callback_delivery_trace.check': { toolName: 'check_callback_delivery_trace' },
  'api_callback_result.check': { toolName: 'check_api_callback_result' },
  'api_callback_retry_detail.check': { toolName: 'check_api_callback_retry_detail' },
  'api_callback_log_detail.query': { toolName: 'query_api_callback_log_detail' },
  'attr_clue_event_detail.query': { toolName: 'query_attr_clue_event_detail', skipWhen: { event_type: 'PAY' } },
};
