import type { AndroidAttributionBranch, SkillCapabilityId } from './types';

export type SkillWorkflowStep = {
  id: string;
  capability?: SkillCapabilityId;
  type?: 'preflight' | 'tool' | 'branch' | 'stop';
  requires?: string[];
  optional?: boolean;
  branchOnly?: AndroidAttributionBranch[];
};

export const androidAttributionWorkflowDag: SkillWorkflowStep[] = [
  { id: 'list_tool_catalog', capability: 'tool.catalog.list', type: 'preflight' },
  { id: 'resolve_app_context', capability: 'app_context.resolve', type: 'tool', requires: ['app_query_or_app_id'] },
  { id: 'resolve_media_context', capability: 'media_context.resolve', type: 'tool', optional: true },
  {
    id: 'check_base_event_ingestion',
    capability: 'base_event_ingestion.check',
    type: 'tool',
    requires: ['app_id', 'date_start', 'date_end', 'event_type'],
  },
  {
    id: 'check_attr_preprocess_result',
    capability: 'attr_preprocess_result.check',
    type: 'tool',
    requires: ['app_id', 'date_start', 'date_end', 'event_type'],
  },
  {
    id: 'check_callback_rule_match',
    capability: 'callback_rule_match.check',
    type: 'tool',
    requires: ['app_id', 'media_id', 'app_package_type', 'event_type'],
  },
  { id: 'branch_by_callback_mode', type: 'branch' },
  { id: 'check_app_sdk_integration', capability: 'sdk_integration.check', type: 'tool', branchOnly: ['SDK_POLICY', 'SDK_ALL'] },
  { id: 'check_callback_delivery_trace', capability: 'callback_delivery_trace.check', type: 'tool', branchOnly: ['SDK_POLICY', 'SDK_ALL'] },
  { id: 'check_api_callback_result', capability: 'api_callback_result.check', type: 'tool', branchOnly: ['API'] },
  { id: 'query_callback_rule_config', capability: 'callback_rule_config.query', type: 'tool', branchOnly: ['CONFIG_ANOMALY'] },
  { id: 'stop_no_callback', type: 'stop', branchOnly: ['NOTHING'] },
];

export function decideCallbackBranch(ruleEvidence: {
  callbackMode?: string;
  callbackModeDetail?: string;
  eventRuleOpen?: boolean;
}): AndroidAttributionBranch {
  const mode = ruleEvidence.callbackMode;
  const detail = ruleEvidence.callbackModeDetail;

  if (mode === 'NOTHING') return 'NOTHING';
  if (detail === 'API') return 'API';
  if (detail === 'SDK' && mode === 'NO_RULE') return 'SDK_ALL';
  if (detail === 'SDK' && mode === 'ALL_RULE' && ruleEvidence.eventRuleOpen) return 'SDK_POLICY';
  if (!mode || !detail) return 'CONFIG_ANOMALY';
  return 'CONFIG_ANOMALY';
}
