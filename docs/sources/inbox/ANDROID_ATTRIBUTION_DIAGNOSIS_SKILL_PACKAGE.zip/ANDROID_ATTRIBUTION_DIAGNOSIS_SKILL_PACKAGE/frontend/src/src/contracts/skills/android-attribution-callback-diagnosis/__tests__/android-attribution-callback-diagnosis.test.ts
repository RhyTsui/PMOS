import { describe, expect, it } from 'vitest';
import { preflightAndroidAttributionSkill } from '../preflight';
import { decideCallbackBranch } from '../workflow-dag';

describe('android attribution callback diagnosis skill', () => {
  it('requires date_start/date_end before execution', () => {
    const result = preflightAndroidAttributionSkill({
      slots: { app_query_or_app_id: '某游戏' },
      availableBindings: [],
    });

    expect(result.executable).toBe(false);
    expect(result.missingSlots).toContain('date_start');
    expect(result.missingSlots).toContain('date_end');
  });

  it('detects NOTHING branch and prevents downstream callback failure judgement', () => {
    expect(decideCallbackBranch({ callbackMode: 'NOTHING', callbackModeDetail: 'NOTHING' })).toBe('NOTHING');
  });

  it('detects SDK policy branch', () => {
    expect(
      decideCallbackBranch({ callbackMode: 'ALL_RULE', callbackModeDetail: 'SDK', eventRuleOpen: true }),
    ).toBe('SDK_POLICY');
  });

  it('detects API branch', () => {
    expect(decideCallbackBranch({ callbackMode: 'ALL_RULE', callbackModeDetail: 'API' })).toBe('API');
  });
});
