import type { SkillCapabilityId } from './types';

export const ANDROID_ATTRIBUTION_CALLBACK_DIAGNOSIS_SKILL_ID =
  'android-attribution-callback-diagnosis' as const;

export const androidAttributionCallbackDiagnosisSkillManifest = {
  skillId: ANDROID_ATTRIBUTION_CALLBACK_DIAGNOSIS_SKILL_ID,
  version: '0.1.0',
  name: 'Android 归因与回推问题排查',
  category: 'diagnosis',
  domain: 'ad-attribution-diagnosis',
  enabled: true,
  routing: {
    topIntent: 'diagnosis',
    candidateRoutes: ['ad_attribution_diagnosis', 'integration_debugging', 'data_quality_review'],
    triggerTerms: [
      '安卓归因',
      'Android回推',
      '媒体没收到',
      'PAY没回传',
      'SDK回推',
      'API回推',
      '804',
      'feedback-res',
      '联调失败',
      '回传失败',
      '归因失败',
    ],
    excludeRoutes: ['plain_report_query', 'creative_analysis', 'budget_recommendation'],
  },
  defaults: {
    app_package_type: 'ANDROID',
    event_type: 'PAY',
    media_id: '10002',
  },
  requiredCapabilities: [
    'tool.catalog.list',
    'app_context.resolve',
    'base_event_ingestion.check',
    'attr_preprocess_result.check',
    'callback_rule_match.check',
  ] satisfies SkillCapabilityId[],
  resultScreenType: 'diagnosis-attribution-callback',
} as const;
