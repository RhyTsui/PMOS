import type { SkillCapabilityId, SkillEvidenceRef } from './types';

type RawToolEvidenceItem = {
  id?: string;
  type?: string;
  summary?: string;
  sample_count?: number;
  raw_ref?: string;
};

export function mapToolEvidenceItemsToEvidenceRefs(params: {
  capabilityId: SkillCapabilityId;
  toolName?: string;
  evidenceItems?: RawToolEvidenceItem[];
  fallbackSummary?: string;
}): SkillEvidenceRef[] {
  const items = params.evidenceItems || [];

  if (items.length === 0) {
    return [
      {
        evidenceId: `${params.capabilityId}:missing-evidence`,
        evidenceType: inferEvidenceType(params.capabilityId),
        toolCapability: params.capabilityId,
        toolName: params.toolName,
        summary: params.fallbackSummary || '工具未返回 evidence_items，不能作为强根因证据。',
        confidence: 'low',
      },
    ];
  }

  return items.map((item, index) => ({
    evidenceId: item.id || `${params.capabilityId}:${index}`,
    evidenceType: inferEvidenceType(params.capabilityId),
    toolCapability: params.capabilityId,
    toolName: params.toolName,
    summary: item.summary || params.fallbackSummary || '工具证据',
    sampleCount: item.sample_count,
    rawRef: item.raw_ref,
    confidence: 'medium',
  }));
}

function inferEvidenceType(capabilityId: SkillCapabilityId): SkillEvidenceRef['evidenceType'] {
  if (capabilityId === 'tool.catalog.list') return 'tool_catalog';
  if (capabilityId === 'app_context.resolve') return 'app_context';
  if (capabilityId === 'media_context.resolve') return 'media_context';
  if (capabilityId === 'base_event_ingestion.check') return 'base_event';
  if (capabilityId === 'attr_preprocess_result.check') return 'attribution_preprocess';
  if (capabilityId === 'callback_rule_match.check') return 'callback_rule';
  if (capabilityId === 'callback_rule_config.query') return 'callback_config';
  if (capabilityId === 'sdk_integration.check') return 'sdk_integration';
  if (capabilityId === 'callback_delivery_trace.check') return 'sdk_delivery';
  if (capabilityId === 'api_callback_result.check') return 'api_feedback';
  if (capabilityId === 'api_callback_retry_detail.check') return 'api_retry';
  if (capabilityId === 'api_callback_log_detail.query') return 'api_log';
  return 'tool_catalog';
}
