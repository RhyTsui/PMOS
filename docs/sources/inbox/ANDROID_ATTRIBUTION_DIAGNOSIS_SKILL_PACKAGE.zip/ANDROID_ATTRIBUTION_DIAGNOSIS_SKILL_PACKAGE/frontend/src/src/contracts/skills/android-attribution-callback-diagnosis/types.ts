/**
 * Android Attribution Callback Diagnosis Skill contracts.
 *
 * This package is intentionally capability-based. Skill code should depend on
 * capability IDs, not concrete MCP tool names. Tool names are resolved by the
 * MCP capability binding layer.
 */

export type AndroidAttributionBranch =
  | 'SDK_POLICY'
  | 'SDK_ALL'
  | 'API'
  | 'NOTHING'
  | 'CONFIG_ANOMALY'
  | 'UNKNOWN';

export type AndroidAttributionRootCause =
  | 'base_event_missing'
  | 'base_event_fields_incomplete'
  | 'attr_require_missing'
  | 'attr_res_missing'
  | 'media_mismatch'
  | 'callback_disabled'
  | 'callback_config_anomaly'
  | 'sdk_delivery_missing'
  | 'sdk_804_missing'
  | 'api_feedback_missing'
  | 'evidence_insufficient'
  | 'no_issue_detected';

export type AndroidAttributionSlotValues = {
  app_query_or_app_id?: string;
  app_id?: string;
  app_name?: string;
  date_start?: string;
  date_end?: string;
  media_id?: string;
  media_query?: string;
  event_type?: string;
  app_package_type?: 'ANDROID' | 'IOS' | 'HARMONY';
  device_id?: string;
  user_id?: string;
  order_id?: string;
  app_version?: string;
  callback_mode?: string;
  problem_desc?: string;
};

export type SkillCapabilityId =
  | 'tool.catalog.list'
  | 'app_context.resolve'
  | 'media_context.resolve'
  | 'base_event_ingestion.check'
  | 'attr_preprocess_result.check'
  | 'callback_rule_match.check'
  | 'callback_rule_config.query'
  | 'sdk_integration.check'
  | 'callback_delivery_trace.check'
  | 'api_callback_result.check'
  | 'api_callback_retry_detail.check'
  | 'api_callback_log_detail.query'
  | 'attr_clue_event_detail.query';

export type CapabilityBinding = {
  capabilityId: SkillCapabilityId;
  toolName: string;
  exposed?: boolean;
  published?: boolean;
  requiredFields?: string[];
  optionalFields?: string[];
  parameterSchema?: unknown;
  skipWhen?: Partial<AndroidAttributionSlotValues>;
};

export type CapabilityPreflightResult = {
  executable: boolean;
  missingSlots: string[];
  missingCapabilities: SkillCapabilityId[];
  unavailableCapabilities: SkillCapabilityId[];
  disclosureRequired: boolean;
  userMessage?: string;
};

export type WorkflowStepStatus = 'pending' | 'running' | 'completed' | 'failed' | 'skipped';

export type WorkflowStepResult = {
  stepId: string;
  capabilityId?: SkillCapabilityId;
  status: WorkflowStepStatus;
  evidenceIds?: string[];
  error?: string;
  startedAt?: string;
  finishedAt?: string;
};

export type SkillEvidenceRef = {
  evidenceId: string;
  evidenceType:
    | 'tool_catalog'
    | 'app_context'
    | 'media_context'
    | 'base_event'
    | 'attribution_preprocess'
    | 'callback_rule'
    | 'callback_config'
    | 'sdk_integration'
    | 'sdk_delivery'
    | 'api_feedback'
    | 'api_retry'
    | 'api_log';
  toolCapability: SkillCapabilityId;
  toolName?: string;
  summary: string;
  sampleCount?: number;
  confidence: 'high' | 'medium' | 'low';
  rawRef?: string;
};

export type AndroidAttributionDiagnosis = {
  branch: AndroidAttributionBranch;
  rootCause: AndroidAttributionRootCause;
  confidence: 'high' | 'medium' | 'low';
  summary: string;
  evidenceRefs: string[];
  missingEvidence?: string[];
  nextActions: Array<{
    actionType: 'clarify' | 'retry_step' | 'follow_up' | 'handoff' | 'export';
    label: string;
    payload?: Record<string, unknown>;
  }>;
};
