# Codex CLI Implementation Prompt

请基于本工程包，将 `安卓归因问题排查prompt.md` 改造成 Enterprise AI Chat OS 下的诊断型 Skill。

## 总目标

新增 Skill：

```txt
android-attribution-callback-diagnosis
```

它应支持 Android 归因、媒体回推、SDK/API 回推、PAY 未回推、联调失败、数据准确性复核等场景。

## 必须遵守的架构规则

1. 不允许把原始 Markdown 直接塞进一个全局 system prompt。
2. 不允许在全局 router 中硬编码 `工具名 -> 意图`。
3. 不允许把 MCP server 直接等同于 Skill。
4. MCP tools 必须先映射为 capability。
5. Skill 只依赖 capability，不直接依赖具体 toolName。
6. Workflow 控制工具调用顺序和 SDK/API/NOTHING 分支。
7. Prompt fragments 只负责证据合成、结果表达和禁止事项。
8. 缺少必填 slot 时必须先澄清，不得继续执行。
9. 最终诊断结果必须进入 SemanticResultContract。
10. 执行状态必须进入 RuntimeDisplayProtocol。
11. 根因判断必须基于 evidence_items/sourceRefs，不得猜测。

## 建议实施步骤

### 第一阶段：导入 Skill 元数据

导入：

```txt
management-center/import/android-attribution-callback-diagnosis.skill.json
management-center/import/android-attribution-callback-diagnosis.workflow.json
management-center/import/android-attribution-callback-diagnosis.capability-binding.example.json
management-center/import/android-attribution-callback-diagnosis.prompts.json
```

### 第二阶段：接入 Request Understanding

新增路由规则：

```txt
用户问题涉及 Android 归因、媒体回推、SDK/API 回推、PAY 事件、804、feedback-res、联调失败、媒体未收到、归因链路等，进入 Skill candidate。
```

不得让该 Skill 抢所有广告数据查询。普通问数仍走 report_query；只有涉及归因/回推/联调/数据准确性复核时才进入该 Skill 或作为子流程使用。

### 第三阶段：接入 Capability Preflight

执行前检查：

```txt
- requiredSlots 是否齐全
- requiredCapabilities 是否可用
- MCP tool catalog 是否 exposed/published
- 当前用户是否有调用权限
- required_fields 是否满足
```

缺少 `date_start` / `date_end` 时必须澄清。

### 第四阶段：接入 Workflow DAG

执行顺序：

```txt
list_tool_catalog
-> resolve_app_context
-> optional resolve_media_context
-> check_base_event_ingestion
-> check_attr_preprocess_result
-> check_callback_rule_match
-> branch_by_callback_mode
```

分支：

```txt
SDK: check_app_sdk_integration -> check_callback_delivery_trace
API: check_api_callback_result -> optional retry/log detail
NOTHING: stop with no-callback conclusion
CONFIG_ANOMALY: query_callback_rule_config
```

### 第五阶段：接入 SemanticResultContract

最终结果至少包含 regions：

```txt
summary
branch-status
workflow-trace
evidence-panel
source-list
next-actions
```

### 第六阶段：接入 Golden Cases

导入：

```txt
frontend/src/src/contracts/skills/android-attribution-callback-diagnosis/golden-cases/*.json
```

至少覆盖：

```txt
- 缺少 date_start/date_end
- 应用候选需要用户选择
- 媒体候选需要用户选择
- 基础事件不存在
- attr-require 缺失
- attr-res 缺失
- callbackMode = NOTHING
- SDK income 有但 804 缺失
- API feedback-res 缺失
- MCP 未挂载或缺工具
```
