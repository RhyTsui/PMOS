export type ScreenType =
  | "agent-copilot-workbench"
  | "campaign-diagnosis"
  | "attribution-drilldown"
  | "creative-fatigue-analysis"
  | "approval-review"
  | "data-source-health"
  | "workflow-audit";

export type Severity = "normal" | "warning" | "critical";
export type Status = "normal" | "warning" | "critical" | "success" | "unknown";
export type RiskLevel = "low" | "medium" | "high";

export interface BusinessContext {
  projectId?: string;
  projectName?: string;
  gameName?: string;
  channel?: "巨量引擎" | "腾讯广告" | "快手" | "Google" | "Meta" | "mixed";
  accountId?: string;
  campaignId?: string;
  dateRange?: "today" | "yesterday" | "last_7_days" | "custom";
  objective?: "ROAS" | "CPA" | "CPI" | "付费率" | "留存" | "起量" | "素材消耗";
  userRole?: "junior_optimizer" | "senior_optimizer" | "ua_director" | "admin";
}

export interface ScreenLayout {
  desktop: "three-column-command-center" | "two-column-diagnosis" | "single-column-audit";
  mobile: "stacked-decision-flow" | "compact-alert-review";
  density: "high" | "medium";
  stickyActions?: boolean;
}

export interface RecommendedAction {
  id: string;
  actionType:
    | "pause_campaigns"
    | "adjust_budget"
    | "switch_conversion_event"
    | "launch_creative_variant"
    | "request_human_review"
    | "run_deep_diagnosis";
  label: string;
  targetObject?: string;
  riskLevel: RiskLevel;
  requiresApproval: boolean;
  estimatedImpact?: string;
  rollbackPlan?: string;
  auditRequired: boolean;
}

export interface KPICompareStripBlock {
  type: "KPICompareStrip";
  id: string;
  title: string;
  metrics: Array<{
    key: string;
    label: string;
    value: string | number;
    unit?: string;
    delta?: number;
    status: Exclude<Status, "unknown">;
    threshold?: string;
  }>;
}

export interface CampaignRiskQueueBlock {
  type: "CampaignRiskQueue";
  id: string;
  title: string;
  items: Array<{
    id: string;
    severity: Severity;
    title: string;
    ownerAgent: string;
    requiresApproval: boolean;
    affectedObject?: string;
  }>;
}

export interface ConversationPanelBlock {
  type: "ConversationPanel";
  id: string;
  mode: "diagnosis" | "strategy" | "approval" | "general";
  initialQuestion?: string;
  suggestedQuestions?: string[];
}

export interface AgentDiagnosisCardBlock {
  type: "AgentDiagnosisCard";
  id: string;
  agentName: "磐石" | "灵感" | "智囊" | "护盾" | string;
  agentRole?: string;
  severity: Severity;
  summary: string;
  confidence: number;
  causes: string[];
  impact: {
    budgetAtRisk?: number;
    affectedCampaigns?: number;
    affectedCreatives?: number;
    affectedUsers?: number;
    metricDelta?: string;
  };
  recommendedActions: RecommendedAction[];
  evidenceRefs: string[];
}

export interface EvidenceTableBlock {
  type: "EvidenceTable";
  id: string;
  title: string;
  source: string;
  lastUpdatedAt: string;
  columns: string[];
  rows: Record<string, string | number | boolean | null>[];
  emptyState?: string;
}

export interface AttributionTimelineBlock {
  type: "AttributionTimeline";
  id: string;
  title: string;
  events: Array<{
    label: string;
    status: Status;
    timestamp?: string;
    note?: string;
  }>;
  highlight?: string;
}

export interface CreativeFatiguePanelBlock {
  type: "CreativeFatiguePanel";
  id: string;
  title: string;
  creatives: Array<{
    creativeId: string;
    name: string;
    ctr?: number;
    cvr?: number;
    cpa?: number;
    roas?: number;
    fatigueLevel: RiskLevel;
    recommendation: string;
  }>;
}

export interface ApprovalActionPanelBlock {
  type: "ApprovalActionPanel";
  id: string;
  title: string;
  actions: RecommendedAction[];
}

export interface AuditLogPanelBlock {
  type: "AuditLogPanel";
  id: string;
  title: string;
  logs: Array<{
    id: string;
    actor: string;
    action: string;
    timestamp: string;
    result: "pending" | "approved" | "rejected" | "executed" | "failed";
  }>;
}

export interface WorkflowStatusPanelBlock {
  type: "WorkflowStatusPanel";
  id: string;
  title: string;
  status: "idle" | "running" | "waiting_approval" | "completed" | "failed";
  currentStep?: string;
  steps?: string[];
}

export interface DataSourceHealthPanelBlock {
  type: "DataSourceHealthPanel";
  id: string;
  title: string;
  sources: Array<{
    name: string;
    status: Status;
    lastUpdatedAt?: string;
    lag?: string;
  }>;
}

export type UISchemaBlock =
  | KPICompareStripBlock
  | CampaignRiskQueueBlock
  | ConversationPanelBlock
  | AgentDiagnosisCardBlock
  | EvidenceTableBlock
  | AttributionTimelineBlock
  | CreativeFatiguePanelBlock
  | ApprovalActionPanelBlock
  | AuditLogPanelBlock
  | WorkflowStatusPanelBlock
  | DataSourceHealthPanelBlock;

export interface ScreenRegions {
  topBar?: UISchemaBlock[];
  contextRail?: UISchemaBlock[];
  main?: UISchemaBlock[];
  evidencePanel?: UISchemaBlock[];
  approvalDrawer?: UISchemaBlock[];
  auditTrail?: UISchemaBlock[];
}

export interface DataRequirement {
  source: "BI" | "MMP" | "媒体API" | "游戏服务端" | "素材库" | "RAG" | string;
  purpose: string;
  freshness: "realtime" | "hourly" | "daily" | "manual";
}

export interface PermissionRequirement {
  action: string;
  role: string;
  approvalRequired: boolean;
}

export interface ValidationRule {
  id: string;
  description: string;
  severity: "error" | "warning";
}

export interface AdAIScreenSchema {
  schemaVersion: "1.0";
  screenId: string;
  screenType: ScreenType;
  title: string;
  description?: string;
  businessContext: BusinessContext;
  layout: ScreenLayout;
  regions: ScreenRegions;
  dataRequirements?: DataRequirement[];
  permissionRequirements?: PermissionRequirement[];
  validationRules?: ValidationRule[];
}
