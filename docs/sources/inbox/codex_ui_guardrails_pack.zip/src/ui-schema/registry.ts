import type { UISchemaBlock } from "./schema";

export const allowedUIBlocks = {
  KPICompareStrip: {
    purpose: "展示核心投放指标的同比、环比、阈值与异常状态。",
    allowedIn: ["contextRail", "main"],
    forbiddenUse: "不能作为营销卡片或功能展示卡片。",
    requiredProps: ["id", "title", "metrics"],
  },
  CampaignRiskQueue: {
    purpose: "展示待处理投放异常、风险等级、负责 Agent 和是否需要审批。",
    allowedIn: ["contextRail", "main"],
    requiredProps: ["id", "title", "items"],
  },
  ConversationPanel: {
    purpose: "承载投放人员与 Agent 的多轮对话和追问。",
    allowedIn: ["main"],
    requiredProps: ["id", "mode"],
  },
  AgentDiagnosisCard: {
    purpose: "展示 Agent 的诊断结论、原因、置信度、影响范围和下一步建议。",
    allowedIn: ["main"],
    requiredProps: [
      "id",
      "agentName",
      "severity",
      "summary",
      "causes",
      "confidence",
      "impact",
      "recommendedActions",
      "evidenceRefs",
    ],
  },
  EvidenceTable: {
    purpose: "展示支持诊断结论的数据证据。",
    allowedIn: ["evidencePanel", "main"],
    requiredProps: ["id", "title", "columns", "rows", "source", "lastUpdatedAt"],
  },
  AttributionTimeline: {
    purpose: "展示曝光、点击、激活、付费、回传延迟的归因链路。",
    allowedIn: ["evidencePanel", "main"],
    requiredProps: ["id", "title", "events"],
  },
  CreativeFatiguePanel: {
    purpose: "展示素材疲劳度、衰退信号和裂变建议。",
    allowedIn: ["main", "evidencePanel"],
    requiredProps: ["id", "title", "creatives"],
  },
  ApprovalActionPanel: {
    purpose: "展示需要人工批准的预算、暂停、回传切换、素材上线动作。",
    allowedIn: ["approvalDrawer", "main"],
    requiredProps: ["id", "title", "actions"],
  },
  AuditLogPanel: {
    purpose: "展示审批、执行、回滚和系统建议的审计日志。",
    allowedIn: ["auditTrail", "evidencePanel"],
    requiredProps: ["id", "title", "logs"],
  },
  WorkflowStatusPanel: {
    purpose: "展示 Agent workflow 当前执行状态、等待审批状态和失败状态。",
    allowedIn: ["main", "evidencePanel"],
    requiredProps: ["id", "title", "status"],
  },
  DataSourceHealthPanel: {
    purpose: "展示 BI、MMP、媒体 API、游戏服务端等数据源健康度。",
    allowedIn: ["contextRail", "evidencePanel"],
    requiredProps: ["id", "title", "sources"],
  },
} as const;

export type AllowedUIBlockType = keyof typeof allowedUIBlocks;

export const forbiddenUIBlockTypes = [
  "Hero",
  "Poster",
  "FeatureGrid",
  "MarketingCard",
  "PricingCard",
  "LandingSection",
  "Showcase",
  "CTASection",
  "GlassCard",
  "GradientPanel",
] as const;

export function assertAllowedBlock(block: UISchemaBlock): void {
  if (!(block.type in allowedUIBlocks)) {
    throw new Error(`Unsupported UI block type: ${block.type}`);
  }
}

export function assertNoForbiddenBlockType(type: string): void {
  if ((forbiddenUIBlockTypes as readonly string[]).includes(type)) {
    throw new Error(`Forbidden demo UI block type: ${type}`);
  }
}
