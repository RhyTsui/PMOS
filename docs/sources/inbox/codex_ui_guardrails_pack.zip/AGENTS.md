# AGENTS.md

## 项目身份

这是一个面向游戏广告优化师、投放负责人、广告产品团队使用的 AI 广告数据产品。

它不是 landing page，不是通用 SaaS demo，不是海报展示页，不是 Claude 风格卡片墙，也不是只展示功能卖点的 AI 工具首页。

产品前台应该是：

- Web Copilot 工作台
- 手机端轻量预警与审批
- 自然语言多轮对话
- 数据证据面板
- Agent 诊断建议
- 人类审批与审计闭环

产品后台可以接入 Coze Studio / Workflow / Agent 编排系统，但 Coze Studio 不是终端用户主界面。

## 当前核心问题

本地 UI Schema 能力弱，AI 经常生成默认 demo 演示系统：

- 平铺海报
- 功能卡片墙
- Claude 风格大卡片
- 渐变背景
- marketing copy
- 无真实业务密度的 dashboard
- 把 Agent 做成宣传卡片

本项目要从工程上阻止这些产出。

## 总原则

AI 不直接自由设计页面。

AI 必须先生成或修改 UISchema。
UISchema 只能引用 registry 中声明的业务组件。
React 页面只能通过 schema renderer 或已有业务组件渲染。
视觉风格必须由 design token、组件库和布局模式锁定。

## 强制工作流

执行任何 UI 任务时，必须按以下顺序：

1. 阅读本文件。
2. 阅读 `docs/UI_CONTRACT.md`。
3. 阅读 `docs/UI_SCHEMA_SPEC.md`。
4. 阅读 `docs/UI_PATTERNS.md`。
5. 阅读 `src/ui-schema/registry.ts`。
6. 判断目标页面的 screenType。
7. 先输出或修改 UISchema。
8. 仅当 registry 无法表达需求时，才新增组件 contract。
9. 不允许直接自由写页面布局。
10. 修改完成后运行项目已有校验命令；如果没有统一命令，则至少运行 typecheck、lint 和 UI demo pattern 检查。

## 严禁生成的 UI

禁止创建或使用：

- hero section
- poster card
- feature grid
- landing page
- marketing CTA
- pricing card
- showcase section
- glassmorphism
- large gradient background
- purple/blue AI SaaS template
- Claude-style flat card wall
- fake dashboard
- fake marketing copy
- “3 个功能卡片 + 1 个按钮”的首页
- 平铺 Agent 头像卡
- 把每个 Agent 设计成宣传海报
- standalone demo app
- sample app not connected to existing project

## 强制页面模式

桌面端优先采用 command center 结构：

- context rail：项目、渠道、日期、风险队列、关键 KPI
- main：对话、Agent 诊断、建议动作、审批入口
- evidence panel：数据证据、归因链路、表格、日志
- approval drawer：预算、暂停、回传、素材上线等高风险动作审批

手机端优先采用 stacked decision flow：

- 风险摘要
- Agent 结论
- 关键证据
- 建议动作
- 批准 / 驳回 / 追问

## 允许优先使用的业务组件

优先使用：

- CommandCenterShell
- ContextRail
- ConversationPanel
- KPICompareStrip
- CampaignRiskQueue
- AgentDiagnosisCard
- EvidenceTable
- AttributionTimeline
- CreativeFatiguePanel
- ApprovalActionPanel
- AuditLogPanel
- WorkflowStatusPanel
- DataSourceHealthPanel

## 业务内容要求

任何 Agent 诊断结论必须包含：

- summary：一句话结论
- causes：原因列表
- confidence：置信度
- impact：影响范围
- recommendedActions：建议动作
- evidenceRefs：证据引用
- riskLevel：风险等级

任何执行动作必须包含：

- actionType
- label
- targetObject
- riskLevel
- requiresApproval
- rollbackPlan
- auditRequired

涉及预算、暂停计划、切换回传事件、素材上线、修改品牌 KV 的动作，必须 requiresApproval=true。

## 文案规则

文案必须是投放业务语言，不允许泛化 SaaS 营销文案。

不要写：

- Transform your workflow
- AI-powered platform
- Boost your productivity
- Get Started
- Explore Features
- Beautiful dashboard

应该写：

- D1 ROAS 低于阈值
- 首充回传延迟扩大
- 3 条高消耗低回收计划待审批
- 素材疲劳度达到临界值
- 建议切换更深度付费事件回传
- 预计预算风险 42,000 元

## 代码实现规则

- 不要创建新的 demo 项目。
- 不要绕过现有路由和组件体系。
- 不要新增无业务含义的 Card/Grid/Hero 组件。
- 如果需要新增组件，先定义 component contract，再实现。
- 优先使用现有 design tokens、CSS variables、Tailwind tokens 或组件库。
- 不要硬编码大面积渐变、玻璃拟态和海报样式。
- 空状态也必须业务化，例如“暂无异常计划”，而不是“No data”。

## 输出格式要求

每次 UI 任务完成后，回复必须包含：

1. 目标 screenType
2. 修改了哪些 UISchema
3. 使用了哪些 registry 组件
4. 覆盖了哪些业务状态
5. 桌面端布局
6. 手机端布局
7. 执行了哪些校验命令
8. 是否发现无法完成的约束
