# UI_PATTERNS.md

# AI 广告系统 UI Patterns

## Pattern 1: Agent Copilot Workbench

适用：主工作台、多轮对话、跨项目投放问题追问。

桌面布局：three-column-command-center

- contextRail：项目上下文、KPI、风险队列
- main：ConversationPanel + AgentDiagnosisCard
- evidencePanel：EvidenceTable + AttributionTimeline + AuditLogPanel
- approvalDrawer：ApprovalActionPanel

不允许：大标题欢迎页、功能卡片、Agent 海报墙。

## Pattern 2: Campaign Diagnosis

适用：ROAS 下滑、消耗突增、激活异常、付费异常、冷启动不起量。

必须回答：

- 异常指标是什么？
- 与昨日 / 大盘 / 阈值相比差多少？
- 影响哪些计划 / 素材 / 渠道？
- 初步原因是什么？
- 证据是什么？
- 建议动作是什么？
- 动作风险和审批要求是什么？

## Pattern 3: Attribution Drilldown

适用：归因链路、回传延迟、MMP 与媒体差异、事件质量。

必须包含：

- 曝光
- 点击
- 激活
- 注册 / 创角
- 首充 / 深度付费
- 回传
- 延迟与断链提示

## Pattern 4: Creative Fatigue Analysis

适用：素材衰退、爆款复盘、脚本发散、素材生命周期管理。

必须包含：

- 素材 ID / 名称
- CTR / CVR / CPA / ROAS
- 前 3 秒钩子表现
- 衰退曲线
- 可裂变方向
- 上线建议
- 合规风险

## Pattern 5: Approval Review

适用：预算调整、暂停计划、切换回传、素材上线、品牌 KV 修改。

必须包含：

- 建议动作
- 触发原因
- 影响范围
- 风险等级
- 回滚方案
- 审批人
- 审计日志

## 移动端 Pattern

移动端不复制复杂桌面布局，只保留决策流：

1. 风险摘要
2. Agent 结论
3. 关键证据
4. 建议动作
5. 批准 / 驳回 / 追问

## 业务状态

所有核心页面至少覆盖：

- loading
- normal
- warning
- critical
- empty
- no_permission
- data_stale
- approval_required
- execution_failed
- rollback_available
