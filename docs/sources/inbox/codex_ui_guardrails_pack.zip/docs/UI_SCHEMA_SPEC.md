# UI_SCHEMA_SPEC.md

# AI 广告系统 UISchema 规范

## 目标

UISchema 是本项目 UI 生成的唯一合法入口。AI 不允许自由生成页面，只能生成或修改结构化 UISchema，再由 renderer 通过 registry 中的业务组件渲染。

## ScreenType

```ts
export type ScreenType =
  | "agent-copilot-workbench"
  | "campaign-diagnosis"
  | "attribution-drilldown"
  | "creative-fatigue-analysis"
  | "approval-review"
  | "data-source-health"
  | "workflow-audit";
```

## AdAIScreenSchema

```ts
export interface AdAIScreenSchema {
  schemaVersion: "1.0";
  screenId: string;
  screenType: ScreenType;
  title: string;
  description?: string;

  businessContext: BusinessContext;
  layout: ScreenLayout;
  regions: ScreenRegions;
  dataRequirements?: DataRequirement[];
  permissionRequirements?: PermissionRequirement[];
  validationRules?: ValidationRule[];
}
```

## BusinessContext

```ts
export interface BusinessContext {
  projectId?: string;
  projectName?: string;
  gameName?: string;
  channel?: "巨量引擎" | "腾讯广告" | "快手" | "Google" | "Meta" | "mixed";
  accountId?: string;
  campaignId?: string;
  dateRange?: "today" | "yesterday" | "last_7_days" | "custom";
  objective?: "ROAS" | "CPA" | "CPI" | "付费率" | "留存" | "起量" | "素材消耗";
  userRole?: "junior_optimizer" | "senior_optimizer" | "ua_director" | "admin";
}
```

## ScreenLayout

```ts
export interface ScreenLayout {
  desktop:
    | "three-column-command-center"
    | "two-column-diagnosis"
    | "single-column-audit";
  mobile:
    | "stacked-decision-flow"
    | "compact-alert-review";
  density: "high" | "medium";
  stickyActions?: boolean;
}
```

## ScreenRegions

```ts
export interface ScreenRegions {
  topBar?: UISchemaBlock[];
  contextRail?: UISchemaBlock[];
  main?: UISchemaBlock[];
  evidencePanel?: UISchemaBlock[];
  approvalDrawer?: UISchemaBlock[];
  auditTrail?: UISchemaBlock[];
}
```

## UISchemaBlock

```ts
export type UISchemaBlock =
  | KPICompareStripBlock
  | CampaignRiskQueueBlock
  | ConversationPanelBlock
  | AgentDiagnosisCardBlock
  | EvidenceTableBlock
  | AttributionTimelineBlock
  | CreativeFatiguePanelBlock
  | ApprovalActionPanelBlock
  | AuditLogPanelBlock
  | WorkflowStatusPanelBlock
  | DataSourceHealthPanelBlock;
```

## AgentDiagnosisCardBlock

```ts
export interface AgentDiagnosisCardBlock {
  type: "AgentDiagnosisCard";
  id: string;
  agentName: "磐石" | "灵感" | "智囊" | "护盾" | string;
  agentRole?: string;
  severity: "normal" | "warning" | "critical";
  summary: string;
  confidence: number;
  causes: string[];
  impact: {
    budgetAtRisk?: number;
    affectedCampaigns?: number;
    affectedCreatives?: number;
    affectedUsers?: number;
    metricDelta?: string;
  };
  recommendedActions: RecommendedAction[];
  evidenceRefs: string[];
}
```

## RecommendedAction

```ts
export interface RecommendedAction {
  id: string;
  actionType:
    | "pause_campaigns"
    | "adjust_budget"
    | "switch_conversion_event"
    | "launch_creative_variant"
    | "request_human_review"
    | "run_deep_diagnosis";
  label: string;
  targetObject?: string;
  riskLevel: "low" | "medium" | "high";
  requiresApproval: boolean;
  estimatedImpact?: string;
  rollbackPlan?: string;
  auditRequired: boolean;
}
```

## EvidenceTableBlock

```ts
export interface EvidenceTableBlock {
  type: "EvidenceTable";
  id: string;
  title: string;
  source: string;
  lastUpdatedAt: string;
  columns: string[];
  rows: Record<string, string | number | boolean | null>[];
  emptyState?: string;
}
```

## AttributionTimelineBlock

```ts
export interface AttributionTimelineBlock {
  type: "AttributionTimeline";
  id: string;
  title: string;
  events: Array<{
    label: string;
    status: "normal" | "warning" | "critical" | "unknown";
    timestamp?: string;
    note?: string;
  }>;
  highlight?: string;
}
```

## KPICompareStripBlock

```ts
export interface KPICompareStripBlock {
  type: "KPICompareStrip";
  id: string;
  title: string;
  metrics: Array<{
    key: string;
    label: string;
    value: string | number;
    unit?: string;
    delta?: number;
    status: "normal" | "warning" | "critical" | "success";
    threshold?: string;
  }>;
}
```

## 禁止出现的 block type

严禁在 UISchema 中出现：

```ts
"Hero"
"Poster"
"FeatureGrid"
"MarketingCard"
"PricingCard"
"LandingSection"
"Showcase"
"CTASection"
"GlassCard"
"GradientPanel"
```

## 质量要求

- 每个 block 必须有业务目的。
- 每个诊断结论必须有 evidenceRefs。
- 每个执行动作必须声明 riskLevel 和 requiresApproval。
- 每个表格必须声明 source 和 lastUpdatedAt。
- 移动端必须能按 stacked decision flow 降级。
