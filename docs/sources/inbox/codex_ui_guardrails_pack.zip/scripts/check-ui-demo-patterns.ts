import fs from "fs";
import path from "path";

const forbidden = [
  "hero",
  "Hero",
  "poster",
  "Poster",
  "feature grid",
  "FeatureGrid",
  "landing",
  "Landing",
  "glassmorphism",
  "gradient-to",
  "from-purple",
  "to-blue",
  "Get Started",
  "Explore Features",
  "AI-powered platform",
  "beautiful dashboard",
  "pricing",
  "Pricing",
  "showcase",
  "Showcase",
  "marketing CTA",
  "MarketingCard",
];

const targetDirs = ["src/app", "src/pages", "src/components", "src/ui", "app", "pages", "components"];

function walk(dir: string): string[] {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).flatMap((name) => {
    const full = path.join(dir, name);
    const stat = fs.statSync(full);
    if (stat.isDirectory()) return walk(full);
    if (/\.(tsx|ts|jsx|js)$/.test(full)) return [full];
    return [];
  });
}

const files = targetDirs.flatMap(walk);
const violations: string[] = [];

for (const file of files) {
  const content = fs.readFileSync(file, "utf8");
  for (const word of forbidden) {
    if (content.includes(word)) {
      violations.push(`${file}: contains forbidden UI demo pattern "${word}"`);
    }
  }
}

if (violations.length) {
  console.error("Forbidden demo UI patterns found:");
  console.error(violations.join("\n"));
  process.exit(1);
}

console.log("UI demo pattern check passed.");
