---
name: ai-ad-ui
description: Use this skill whenever implementing UI, UISchema, page layout, dashboard, workbench, chat interface, diagnosis screen, evidence panel, mobile approval flow, or Agent recommendation view for the AI advertising data product. Do not use this skill for generic landing pages.
---

# AI Ad UI Skill

## Goal

Implement production UI for an AI advertising data product used by game advertising optimizers.

The UI must help users:

- detect anomalies
- understand causes
- inspect evidence
- ask follow-up questions
- review Agent recommendations
- approve or reject risky actions
- audit decisions

## Non-goals

Never implement:

- landing page
- hero section
- poster card
- feature grid
- marketing homepage
- Claude-style card wall
- fake AI SaaS dashboard
- standalone demo app

## Required reading

Before changing UI, read:

1. `AGENTS.md`
2. `docs/UI_CONTRACT.md`
3. `docs/UI_SCHEMA_SPEC.md`
4. `docs/UI_PATTERNS.md`
5. `src/ui-schema/registry.ts`

## Workflow

1. Inspect the existing repository structure.
2. Identify the current frontend stack.
3. Identify the target screenType.
4. Create or update UISchema first.
5. Use only registry-approved business components.
6. If a component is missing, propose a component contract first.
7. Implement renderer or component changes only after schema is clear.
8. Add or update validation.
9. Run available checks.
10. Report screenType, schema changes, components used, desktop/mobile layout, validation result.

## Required output for Agent diagnosis UI

Every Agent diagnosis must include:

- summary
- causes
- confidence
- impact
- recommendedActions
- evidenceRefs
- riskLevel

Every recommended action must include:

- actionType
- label
- riskLevel
- requiresApproval
- rollbackPlan
- auditRequired

## Desktop layout

Prefer command-center structure:

- context rail
- main conversation / diagnosis
- evidence panel
- approval drawer

## Mobile layout

Prefer stacked decision flow:

- alert summary
- Agent conclusion
- key evidence
- recommended action
- approval buttons

## Validation

Run these commands if they exist:

```bash
pnpm typecheck
pnpm lint
pnpm ui:lint
pnpm validate
```

If package manager is npm or yarn, adapt commands to the repository.
