# Codex Implementation Prompt: PMOS Ant Design X Frontend Skill

Copy this prompt into Codex CLI when implementing the local PMOS frontend framework.

---

You are implementing the PMOS v1.1 frontend default framework.

Do not create a visual design mockup. Implement the framework and components needed to support Ant Design X style Copilot-first PMOS frontend.

Core requirement:

```text
PMOS frontend must be Copilot-first, Agent-routed, Dynamic Surface driven.
It must not be a flat dashboard or generic chat page.
```

Use official Ant Design and Ant Design X principles:

```text
Ant Design = enterprise product UI foundation
Ant Design X = AI conversation and Hybrid UI foundation
XProvider = global config provider
Bubble/Sender/Conversations/Prompts/Welcome/Attachments = Copilot interaction
Think/ThoughtChain = visible agent/runtime process status
Actions/FileCard/Sources/CodeHighlighter/Mermaid/Folder = results and artifacts
X Card / A2UI = optional Dynamic Surface renderer
```

Implementation tasks:

## 1. Inspect current repo

Check:

```text
package.json
src/frontend
src/shared/schemas.ts
src/backend routes
```

Do not install duplicate packages.

## 2. Install or verify dependencies

Required packages:

```text
antd
@ant-design/icons
@ant-design/x
@ant-design/x-sdk
@ant-design/x-markdown
@ant-design/x-card
react-router-dom
@tanstack/react-query
zustand
```

## 3. Add provider layer

Create:

```text
src/frontend/app/AppProviders.tsx
src/frontend/app/theme.ts
src/frontend/app/queryClient.ts
```

Use `XProvider` as top-level provider. Merge Ant Design and Ant Design X Chinese locales if zh_CN is used.

## 4. Add Copilot shell

Create:

```text
src/frontend/features/copilot/PMOSCopilotShell.tsx
src/frontend/features/copilot/CopilotConversation.tsx
src/frontend/features/copilot/CopilotSender.tsx
src/frontend/features/copilot/CopilotWelcome.tsx
src/frontend/features/copilot/CopilotPrompts.tsx
src/frontend/features/copilot/AgentRouteTrace.tsx
```

Required behavior:

```text
- Render Welcome when no messages exist.
- Render Prompts for safe starter actions.
- Render Bubble.List for conversation.
- Render Sender with Attachments.
- On submit, call POST /api/studio/agent-route.
- Append assistant bubble with route reason and next safe step.
- Update active DynamicSurfaceHost.
```

## 5. Add API clients

Create:

```text
src/frontend/shared/api/studioApi.ts
src/frontend/shared/api/builderApi.ts
src/frontend/shared/api/codexApi.ts
```

Do not store server truth in Zustand.

## 6. Add Dynamic Surface Host

Create:

```text
src/frontend/features/dynamic-surface/DynamicSurfaceHost.tsx
src/frontend/features/dynamic-surface/DynamicSurfaceRenderer.tsx
```

Typed surfaces:

```text
PageSpecSurface
CodexJobSurface
VerificationSurface
ProofSurface
RuntimeInspectorSurface
WorkflowOperatorSurface
```

## 7. Add A2UI catalog optional foundation

Create:

```text
src/frontend/features/dynamic-surface/a2ui/pmosCatalog.ts
src/frontend/features/dynamic-surface/a2ui/A2UISurface.tsx
```

Do not render raw HTML. Only use registered components.

## 8. Add route

Make `/workspace` render PMOSCopilotShell.

Keep technical pages optional and not default.

## 9. Runtime boundary

Never implement frontend shell execution.

Any execution action must call Runtime API:

```text
POST /api/codex/jobs/:id/start
POST /api/codex/jobs/:id/run-verification
POST /api/codex/jobs/:id/writeback
```

## 10. Acceptance

Run:

```bash
npm run lint
npm run build
npm run test
npm run verify:frontend-browser
```

If some command does not exist, report that honestly and run the available closest command.

## 11. Required completion report

After implementation, output:

```text
1. Files changed
2. Dependencies added
3. New components
4. New routes
5. New API clients
6. How AgentRoute opens DynamicSurface
7. How frontend avoids direct shell execution
8. How Ant Design X components are used
9. Remaining gaps
10. Verification command results
```
