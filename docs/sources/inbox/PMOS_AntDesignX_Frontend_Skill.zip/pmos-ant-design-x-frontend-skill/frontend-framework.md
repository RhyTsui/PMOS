# PMOS v1.1 Default Frontend Framework

## 1. Target stack

```json
{
  "ui": ["antd", "@ant-design/icons"],
  "ai-ui": ["@ant-design/x"],
  "ai-data-flow": ["@ant-design/x-sdk"],
  "ai-markdown": ["@ant-design/x-markdown"],
  "dynamic-card": ["@ant-design/x-card"],
  "routing": ["react-router-dom"],
  "server-state": ["@tanstack/react-query"],
  "local-ui-state": ["zustand"]
}
```

Before installing, check existing `package.json`.

## 2. Recommended commands

```bash
npm install antd @ant-design/icons @ant-design/x @ant-design/x-sdk @ant-design/x-markdown @ant-design/x-card
npm install react-router-dom @tanstack/react-query zustand
```

If any dependency already exists, keep current compatible version unless package resolution fails.

## 3. Directory structure

```text
src/frontend/
  app/
    App.tsx
    AppProviders.tsx
    routes.tsx
    theme.ts
    queryClient.ts

  features/
    copilot/
      PMOSCopilotShell.tsx
      CopilotConversation.tsx
      CopilotSender.tsx
      CopilotWelcome.tsx
      CopilotPrompts.tsx
      AgentRouteTrace.tsx
      hooks.ts
      types.ts

    dynamic-surface/
      DynamicSurfaceHost.tsx
      DynamicSurfaceRenderer.tsx
      types.ts
      surfaces/
        PageSpecSurface.tsx
        CodexJobSurface.tsx
        VerificationSurface.tsx
        ProofSurface.tsx
        RuntimeInspectorSurface.tsx
        WorkflowOperatorSurface.tsx
      a2ui/
        pmosCatalog.ts
        a2uiTypes.ts
        A2UISurface.tsx

    studio-session/
      StudioSessionProvider.tsx
      useStudioSession.ts
      studioSessionStore.ts

  shared/
    api/
      studioApi.ts
      builderApi.ts
      codexApi.ts
      proofApi.ts
      runtimeApi.ts
    components/
      StatusTag.tsx
      EntityFileCard.tsx
      NextSafeStep.tsx
    formatters/
    status/
```

## 4. Provider implementation

Create `src/frontend/app/theme.ts`:

```ts
import type { ThemeConfig } from 'antd';

export const pmosTheme: ThemeConfig = {
  token: {
    colorPrimary: '#1677ff',
    borderRadius: 12,
    fontSize: 14,
  },
  components: {
    Button: {
      borderRadius: 10,
    },
    Card: {
      borderRadiusLG: 16,
    },
  },
};
```

Create `src/frontend/app/AppProviders.tsx`:

```tsx
import type { PropsWithChildren } from 'react';
import { App as AntdApp } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import zhCNX from '@ant-design/x/locale/zh_CN';
import { XProvider } from '@ant-design/x';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from './queryClient';
import { pmosTheme } from './theme';

export function AppProviders({ children }: PropsWithChildren) {
  return (
    <XProvider theme={pmosTheme} locale={{ ...zhCNX, ...zhCN }}>
      <AntdApp>
        <QueryClientProvider client={queryClient}>
          {children}
        </QueryClientProvider>
      </AntdApp>
    </XProvider>
  );
}
```

## 5. Route policy

Default route:

```text
/workspace → PMOSCopilotShell
```

Do not make `/workspace` a flat dashboard.

Optional technical routes:

```text
/workspace/runtime
/workspace/dev
```

These are not default user entry.

## 6. API client policy

Use React Query for runtime state.

Example:

```ts
export async function routeAgent(input: AgentRouteRequest): Promise<AgentRouteResponse> {
  const response = await fetch('/api/studio/agent-route', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data?.error ?? 'agent_route_failed');
  }
  return data;
}
```

## 7. Copilot shell required behavior

`PMOSCopilotShell` must:

```text
1. maintain current StudioSession
2. show conversations/session context
3. render user and assistant bubbles
4. provide Sender with Attachments
5. show Prompts for safe starter actions
6. call /api/studio/agent-route on submit
7. append route result as assistant message
8. update active Dynamic Surface
9. show ThoughtChain/trace for agent routing
10. display Next Safe Step
```

## 8. Dynamic Surface required behavior

`DynamicSurfaceHost` must:

```text
1. read active DynamicSurfaceDescriptor
2. select typed React surface by descriptor.type
3. pass entity id and mode
4. expose actions back to Runtime
5. never execute shell
```

## 9. Local UI state

Only store these in Zustand:

```text
activeConversationKey
activeSurfaceId
drawer open/closed
selected local display mode
temporary unsaved input draft
```

Do not store Runtime truth in Zustand.

## 10. Testing expectations

At minimum, add tests or build checks for:

```text
Agent route API parsing
Dynamic surface type switching
CodexJob status rendering
No frontend shell execution path
Provider renders without error
```
