# PMOS Dynamic Surface and A2UI Skill

## 1. Why Dynamic Surface

PMOS v1.1 should not expose all features as a flat layout. Instead:

```text
User intent
→ Agent Router
→ Dynamic Surface
→ Runtime action
```

Dynamic Surface lets the UI adapt to the current task without forcing users to manually select modules.

## 2. Two implementation levels

### Level 1: typed React Surface

Required for v1.1.

```text
PageSpecSurface
CodexJobSurface
VerificationSurface
ProofSurface
RuntimeInspectorSurface
WorkflowOperatorSurface
```

Each surface is a normal React component using Ant Design / Ant Design X.

### Level 2: A2UI / X Card Surface

Use when Agent generates UI as structured JSON.

```text
Agent → A2UI commands → XCard renderer → registered PMOS catalog → native UI
```

## 3. A2UI safety rule

Allowed:

```text
structured JSON commands
registered catalog components
data binding
action events
```

Forbidden:

```text
raw HTML
raw JavaScript
inline script
arbitrary CSS
iframe
dangerouslySetInnerHTML
unregistered components
```

## 4. A2UI v0.9 commands

PMOS should prefer v0.9 style:

```ts
type CreateSurfaceCommand = {
  version: 'v0.9';
  createSurface: {
    surfaceId: string;
    catalogId: string;
  };
};

type UpdateComponentsCommand = {
  version: 'v0.9';
  updateComponents: {
    surfaceId: string;
    components: Array<{
      id: string;
      component: string;
      children?: string[];
      child?: string;
      [key: string]: unknown;
    }>;
  };
};

type UpdateDataModelCommand = {
  version: 'v0.9';
  updateDataModel: {
    surfaceId: string;
    path: string;
    value: unknown;
  };
};

type DeleteSurfaceCommand = {
  version: 'v0.9';
  deleteSurface: {
    surfaceId: string;
  };
};
```

## 5. PMOS catalog

Start catalog:

```text
Text
Title
Paragraph
Card
Section
Form
TextField
TextArea
Select
Checkbox
Button
ActionGroup
Steps
StatusTag
Alert
Descriptions
Table
FileList
CodeBlock
DiffSummary
Progress
```

## 6. PMOS action event contract

Every A2UI action must produce a structured action event:

```ts
type PMOSSurfaceAction = {
  version: 'v0.9';
  action: {
    name:
      | 'confirm_page_spec'
      | 'create_codex_job'
      | 'approve_codex_job'
      | 'request_rework'
      | 'cancel_job'
      | 'run_verification'
      | 'writeback_proof';
    surfaceId: string;
    sourceComponentId: string;
    timestamp: string;
    context: Record<string, unknown>;
  };
};
```

Frontend sends this to:

```text
POST /api/studio/surfaces/:surfaceId/actions/:actionId
```

## 7. Example: PageSpec Surface

```json
[
  {
    "version": "v0.9",
    "createSurface": {
      "surfaceId": "page-spec-123",
      "catalogId": "pmos-v1"
    }
  },
  {
    "version": "v0.9",
    "updateDataModel": {
      "surfaceId": "page-spec-123",
      "path": "/pageSpec",
      "value": {
        "title": "PMOS Builder",
        "userGoal": "Create PageSpec and CodexJob from product intent",
        "status": "draft"
      }
    }
  },
  {
    "version": "v0.9",
    "updateComponents": {
      "surfaceId": "page-spec-123",
      "components": [
        {
          "id": "root",
          "component": "Card",
          "children": ["title", "goal", "confirm"]
        },
        {
          "id": "title",
          "component": "Title",
          "text": { "path": "/pageSpec/title" }
        },
        {
          "id": "goal",
          "component": "TextArea",
          "label": "User Goal",
          "value": { "path": "/pageSpec/userGoal" }
        },
        {
          "id": "confirm",
          "component": "Button",
          "variant": "primary",
          "text": "Confirm PageSpec",
          "action": {
            "event": {
              "name": "confirm_page_spec",
              "context": {
                "pageSpec": { "path": "/pageSpec" }
              }
            }
          }
        }
      ]
    }
  }
]
```

## 8. Implementation requirement

In v1.1, implement typed surfaces first. Add A2UI as progressive enhancement.

Reason:

```text
typed surfaces guarantee stability
A2UI unlocks agent-generated interfaces later
```

## 9. Acceptance

A Dynamic Surface implementation passes if:

```text
1. Surface is opened by AgentRouteResponse.
2. Surface binds to a PMOS entity.
3. User actions are structured.
4. Runtime handles the action.
5. No raw HTML is rendered.
6. Surface can be closed/replaced by Agent Router.
7. Surface can show next safe step.
```
