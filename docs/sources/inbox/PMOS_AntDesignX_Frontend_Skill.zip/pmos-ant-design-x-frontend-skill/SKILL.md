# PMOS Ant Design X Frontend Skill

## When to use

Use this skill whenever you implement, refactor, or review PMOS frontend work related to:

- PMOS v1.1 Studio
- PMOS Copilot
- Ant Design / Ant Design X adoption
- Agent dynamic routing frontend
- Dynamic Work Surface
- PageSpec / CodexJob / Proof frontend flows
- Frontend component library selection
- Local PMOS desktop-ready Web Studio

## Core identity

PMOS frontend must be:

```text
Copilot-first
Agent-routed
Dynamic-surface driven
Runtime-state governed
Codex-execution guarded
Proof-oriented
```

PMOS frontend must not be:

```text
a generic dashboard
a Coze clone
a flat admin panel
a pure chat page
a direct shell launcher
a visual-only redesign
```

## Mandatory product boundary

Always preserve this boundary:

```text
PMOS Studio / Copilot = user entry and interaction
Agent Router = intent routing and surface selection
Dynamic Surface = structured task UI
PMOS Runtime = state, workflow, proof, verification, API
Codex CLI = controlled executor only
Proof-of-Work = delivery evidence
```

The frontend must never directly execute shell commands or directly invoke Codex CLI.

## Required default stack

Use this default stack unless the repository already has a conflicting stable stack:

```text
React
TypeScript
Ant Design
Ant Design X
Ant Design X SDK
Ant Design X Markdown
Ant Design X Card, when Dynamic Surface is needed
React Router
TanStack Query
Zustand, only for local UI state
Zod or existing shared schemas for typed contracts
```

Package names:

```text
antd
@ant-design/icons
@ant-design/x
@ant-design/x-sdk
@ant-design/x-markdown
@ant-design/x-card
react-router-dom
@tanstack/react-query
zustand
```

Before installing anything, inspect `package.json` and avoid duplicate or incompatible package choices.

## Design doctrine

Apply Ant Design values to PMOS:

- Natural: users express product goals naturally and stay in flow.
- Certain: every action has explicit state, next step, and confirmation.
- Meaningful: each interaction advances PMOS delivery chain.
- Growing: the system supports future desktop, Coze plugin, Gemini CLI, workflow canvas.

Apply Ant Design X RICH paradigm to PMOS:

- Role: active agent and user role are visible.
- Intention: user intent is routed, not manually menu-selected.
- Conversation: Copilot conversation remains the primary flow.
- Hybrid UI: structured dynamic surfaces appear only when useful.

## PMOS frontend main flow

Every frontend feature must serve this chain:

```text
Original Demand
→ AgentRoute
→ DynamicSurface
→ Requirement
→ PageSpec
→ CodexJob
→ Diff
→ Preview
→ BrowserVerification
→ ReviewGate
→ ProofOfWork
→ VersionWriteback
```

If a feature does not serve this chain, do not implement it in v1.1.

## Component rules

Use Ant Design X components for AI interaction:

```text
Conversations: session list and active conversation
Welcome: initial wake-up and capability framing
Prompts: intention starters and safe next steps
Sender: user input
Attachments: uploaded docs/screenshots/context
Bubble / Bubble.List: conversation rendering
Think: model/agent thinking status, not private chain-of-thought
ThoughtChain: visible execution trace and tool/runtime progress
Actions: approve, rework, cancel, writeback
FileCard: PageSpec, CodexJob, Proof, Diff, Verification artifacts
Sources: truth source / grounding citations
CodeHighlighter: code snippets and command outputs
Mermaid: workflow/DAG text rendering when needed
Folder: changed file tree / artifact tree
Notification: runtime/system notices
XProvider: global config, locale, theme
```

Use Ant Design components for enterprise/product UI:

```text
App, ConfigProvider, Layout, Card, Flex, Splitter, Drawer, Modal,
Form, Input, Select, Button, Steps, Timeline, Alert, Tag,
Table, Descriptions, Tabs, Result, Empty, Skeleton, Spin, Progress,
Badge, Tooltip, Typography, Space, Divider, Menu
```

Do not create custom components when an Ant Design or Ant Design X component is appropriate.

## Recommended file structure

Create or converge to:

```text
src/frontend/
  app/
    App.tsx
    AppProviders.tsx
    routes.tsx
    theme.ts
    queryClient.ts
  features/
    copilot/
      PMOSCopilotShell.tsx
      CopilotConversation.tsx
      CopilotSender.tsx
      AgentRouteTrace.tsx
      hooks.ts
      types.ts
    dynamic-surface/
      DynamicSurfaceHost.tsx
      DynamicSurfaceRenderer.tsx
      surfaces/
        PageSpecSurface.tsx
        CodexJobSurface.tsx
        ProofSurface.tsx
        RuntimeInspectorSurface.tsx
      a2ui/
        pmosCatalog.ts
        a2uiTypes.ts
    studio-session/
      StudioSessionProvider.tsx
      useStudioSession.ts
    shared/
      api/
        studioApi.ts
        builderApi.ts
        codexApi.ts
      components/
      status/
      formatters/
```

## Provider rule

Use `XProvider` at the top level. It extends Ant Design `ConfigProvider`.

Minimum provider stack:

```tsx
<XProvider theme={pmosTheme} locale={mergedLocale}>
  <App>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  </App>
</XProvider>
```

If the codebase already has providers, integrate rather than duplicate.

## Agent routing frontend contract

The frontend sends user input to:

```text
POST /api/studio/agent-route
```

Expected response:

```ts
type AgentRouteResponse = {
  routeId: string;
  selectedAgentId: string;
  confidence: number;
  reason: string;
  targetEntityType: string;
  targetEntityId: string | null;
  dynamicSurface: DynamicSurfaceDescriptor;
  nextSafeStep: string;
  blockedReason: string | null;
};
```

The frontend must render:

- assistant bubble with route reason
- visible route trace / ThoughtChain
- Dynamic Surface matching `dynamicSurface.type`
- next safe step action

## Dynamic Surface rule

For PMOS v1.1, Dynamic Surface can be implemented in two levels:

### Level 1: typed React surfaces

Use explicit React components:

```text
PageSpecSurface
CodexJobSurface
ProofSurface
RuntimeInspectorSurface
```

This is required for v1.1 stability.

### Level 2: A2UI / X Card surfaces

Use `@ant-design/x-card` and A2UI v0.9 when Agent output is structured as JSON commands.

Use A2UI only with a registered component catalog. Never render LLM-generated raw HTML.

## A2UI safety rule

Allowed:

```text
Agent → structured JSON commands → registered catalog → native components
```

Forbidden:

```text
Agent → raw HTML/JS/CSS → dangerouslySetInnerHTML
```

## Implementation order

When implementing this skill, follow this order:

1. Inspect current frontend stack and package.json.
2. Add dependencies only if missing.
3. Add `AppProviders.tsx`, `theme.ts`, and top-level `XProvider`.
4. Add Copilot shell route.
5. Add AgentRoute API client and hook.
6. Add conversation renderer using Bubble / Sender / Attachments / Prompts.
7. Add DynamicSurfaceHost.
8. Add typed React surfaces for PageSpec, CodexJob, Proof, Runtime.
9. Add ThoughtChain / trace visualization.
10. Add A2UI catalog only after typed surfaces work.
11. Add tests/build checks.
12. Update docs.

## Acceptance checklist

Implementation is acceptable only if:

- The default user entry is Copilot-first.
- The UI is not a flat dashboard.
- User intent routes to an Agent.
- Agent route result opens a Dynamic Surface.
- PageSpec can be created or displayed.
- CodexJob can be created/displayed with status machine.
- Codex execution is not triggered directly from frontend shell.
- Runtime APIs own state.
- Proof / verification states are visible.
- Ant Design / Ant Design X components are used rather than custom UI.
- `npm run lint`, `npm run build`, and existing frontend verification commands pass.
