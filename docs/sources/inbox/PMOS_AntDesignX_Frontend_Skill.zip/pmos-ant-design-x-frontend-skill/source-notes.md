# Source Notes

These notes summarize the official materials used to create this PMOS Ant Design X Frontend Skill.

## Ant Design

Official repository:

```text
https://github.com/ant-design/ant-design
```

Key points:

```text
Ant Design is an enterprise-class UI design language and React UI library.
It provides high-quality React components, TypeScript support, internationalization, design resources, and CSS-in-JS theme customization.
It supports modern browsers, SSR, and Electron.
```

Official React docs:

```text
https://ant.design/docs/react/introduce/
```

Official design values:

```text
https://ant.design/docs/spec/values/
https://ant.design/docs/spec/introduce/
```

Key values:

```text
Natural
Certain
Meaningful
Growing
```

## Ant Design X

Official site:

```text
https://x.ant.design/
```

Key points:

```text
Ant Design X presents the RICH paradigm:
Role, Intention, Conversation, Hybrid UI.

It focuses on AI interface solutions and combines GUI with natural conversation.
```

Components introduction:

```text
https://x.ant.design/components/introduce/
https://x.ant.design/components/overview/
```

Key components:

```text
Bubble
Conversations
Notification
Welcome
Prompts
Sender
Attachments
Suggestion
Think
ThoughtChain
Actions
FileCard
Sources
CodeHighlighter
Mermaid
Folder
XProvider
```

XProvider:

```text
https://ant-design-x.antgroup.com/components/x-provider
```

Key point:

```text
XProvider extends antd ConfigProvider and provides global configuration for Ant Design X components.
```

X SDK:

```text
https://x.ant.design/x-sdks/introduce/
https://x.ant.design/x-sdks/use-x-chat/
https://x.ant.design/x-sdks/use-x-conversations/
https://x.ant.design/x-sdks/x-stream
```

Key points:

```text
X SDK helps manage AI conversation data flow.
useXChat manages single conversation data through Agent.
useXConversations manages multiple sessions.
XStream transforms SSE or other readable streams.
```

X Card / A2UI:

```text
https://x.ant.design/x-cards/introduce/
```

Key points:

```text
X Card is a dynamic card renderer based on A2UI.
A2UI lets Agents describe interaction intent with declarative JSON message sequences.
Frontend runtime renders native UI components from registered catalogs.
A2UI is safer than AI-generated HTML because it avoids arbitrary code execution.
Recommended protocol version is v0.9.
```

X Skill:

```text
https://x.ant.design/x-skills/introduce/
https://x.ant.design/x-skills/skills/
```

Key points:

```text
Ant Design X Skill provides Agent skills for building high-quality AI conversation applications.
Skills cover x-sdk, x-components, x-markdown, x-card and related best practices.
```

## PMOS interpretation

This skill maps official Ant Design X concepts to PMOS:

```text
RICH Role → PMOS user role + active agent
RICH Intention → Agent Router
RICH Conversation → PMOS Copilot
RICH Hybrid UI → Dynamic Work Surface
X Card / A2UI → Agent-generated safe structured UI
ThoughtChain → visible Runtime/Codex/Verification trace
FileCard → PageSpec/CodexJob/Proof artifacts
Sources → PMOS truth source references
```
