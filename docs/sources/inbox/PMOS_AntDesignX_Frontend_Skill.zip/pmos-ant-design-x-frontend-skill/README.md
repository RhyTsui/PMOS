# PMOS Ant Design X Frontend Skill

用途：部署到本地 PMOS / Codex，作为 v1.1 Studio 前端默认框架、组件库、Agent 动态路由、Dynamic Surface 和验收标准的执行规范。

本包不包含 UI 视觉稿，不规定最终视觉排版；它定义的是：

```text
前端默认技术栈
组件选择规则
Ant Design / Ant Design X 使用原则
Copilot-first 架构
Agent Dynamic Routing
Dynamic Work Surface
A2UI / X Card 结构化渲染策略
Codex 实施顺序
验收标准
```

## 文件

| 文件 | 作用 |
|---|---|
| `SKILL.md` | 可放入本地 Codex / PMOS skill 目录的核心技能说明 |
| `design.md` | 深度设计说明：Ant Design / Ant Design X 如何转化为 PMOS 前端框架 |
| `frontend-framework.md` | PMOS v1.1 默认前端工程结构、依赖、Provider、数据流 |
| `component-policy.md` | Ant Design X / Ant Design 组件选型策略 |
| `a2ui-dynamic-surface.md` | Dynamic Surface / X Card / A2UI 执行规范 |
| `codex-implementation-prompt.md` | 可直接贴给 Codex CLI 的实施提示词 |
| `acceptance-checklist.md` | 实施验收清单 |
| `source-notes.md` | 官方资料摘录与链接 |

## 一句话原则

```text
PMOS 前端不是平铺式后台，也不是普通聊天页。
它是 Ant Design X 风格的 Copilot-first 前端：
用户表达目标，Agent Router 选择工作面，Dynamic Surface 承载结构化操作，Runtime 管状态，Codex 只执行。
```
