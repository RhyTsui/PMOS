# Acceptance Checklist: PMAIOS Chat Process & Evidence Disclosure Layer

## Product acceptance

- [ ] Message action has “过程与依据” entry.
- [ ] Existing “来源” entry remains compatible or opens the Evidence tab.
- [ ] Drawer defaults to Overview, not Raw JSON.
- [ ] Header shows status, duration, step count, tool count, source count, returned field count, matched field count, warning count.
- [ ] Execution tab shows stage tree/timeline.
- [ ] Evidence tab distinguishes no external source vs missing source metadata.
- [ ] Field Catalog tab shows matched/ambiguous/unmatched/masked statuses.
- [ ] Quality Checks tab shows pass/warning/fail/info with suggestions.
- [ ] Raw Info tab is permission-aware and collapsed by default.
- [ ] Trace ID or trace link is visible only when permission allows.

## Architecture acceptance

- [ ] UI renders only `MessageDisclosureView`.
- [ ] No frontend hardcoded field-to-metric mapping.
- [ ] No frontend hardcoded tool-specific business display.
- [ ] Projection Builder composes runtime events, trace spans, tool results, artifacts, catalog, and quality checks.
- [ ] Legacy Adapter supports existing raw result structures without creating business-specific hacks.
- [ ] ToolResultEnvelope is documented and adopted by at least one standard tool path.
- [ ] Server performs redaction before UI receives data.

## Test acceptance

- [ ] Unit tests cover standard envelope projection.
- [ ] Unit tests cover legacy projection.
- [ ] Unit tests cover source metadata missing warning.
- [ ] Unit tests cover field catalog missing warning.
- [ ] Unit tests cover requested metric coverage warning.
- [ ] Component tests cover empty states.
- [ ] Component tests verify raw JSON is not default.
- [ ] E2E test covers one-tool-call report query with missing metadata.
