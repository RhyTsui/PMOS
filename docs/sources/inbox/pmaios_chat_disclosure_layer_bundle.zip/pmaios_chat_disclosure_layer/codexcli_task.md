# Codex CLI Task: Implement PMAIOS Enterprise Chat Process & Evidence Disclosure Layer v1

## Goal

Implement a generic enterprise-grade Process & Evidence Disclosure Layer for Chat messages. The UI must no longer treat “source” as the whole disclosure surface. It must show a structured, permission-safe, message-scoped projection of process, evidence, field definitions, quality checks, and raw diagnostics.

## Non-negotiable constraints

- Do not hardcode report tool names, field names, or business metric meanings in UI.
- The Chat UI must render `MessageDisclosureView` only.
- Field explanations must come from Field / Metric Catalog or the standardized tool envelope, never frontend substring logic.
- Source empty state must explain the reason instead of showing only “empty”.
- Raw JSON must be available only in Raw Info and must not be the default tab.
- Server must perform redaction and permission projection before returning data to UI.
- Existing source/execution/raw-detail functionality must remain compatible via a Legacy Adapter.

## Implement in this order

1. Search the repository for existing code:
   - message action bar
   - source button/panel
   - trace or execution detail viewer
   - tool call models
   - runtime state models
   - artifact/source models
   - report query result handling
   - API routes for message details

2. Add shared types:
   - `MessageDisclosureView`
   - `ExecutionStep`
   - `EvidenceBundle`
   - `FieldCatalogView`
   - `QualityCheck`
   - `RawInfoBundle`
   - `DisclosureEvent`
   - `ToolResultEnvelope`

3. Add a Projection Builder:
   - input: message/run/tool calls/trace/events/artifacts/legacy raw
   - output: `MessageDisclosureView`
   - include `legacyDisclosureAdapter`
   - include server-side permission projection

4. Add quality checks:
   - `source_metadata_coverage`
   - `field_catalog_coverage`
   - `requested_metric_coverage`
   - `result_non_empty`
   - `permission_redaction`
   - `tool_error_warning`

5. Add API:
   - `GET /api/chat/messages/:messageId/disclosure?scope=message`
   - If existing route conventions differ, integrate with the existing routing style.

6. Add UI:
   - Rename/alias source entry to “过程与依据” / Process & Evidence.
   - Add right drawer with tabs:
     - Overview
     - Execution Chain
     - Evidence
     - Field Catalog
     - Quality Checks
     - Raw Info
   - Default tab is Overview.
   - Legacy source button may open Evidence tab.

7. Add tests:
   - Builder from standard envelope.
   - Builder from legacy raw details.
   - Missing source metadata warning.
   - Missing field catalog warning.
   - Requested metric not covered warning.
   - UI empty states.
   - Raw JSON not shown by default.

## Acceptance scenario

Given a message with one tool call, raw result fields, no source refs, and no field catalog:

- Header shows completed state, 1 tool call, returned field count, 0 matched fields.
- Evidence tab explains source metadata is missing.
- Field Catalog tab lists returned fields as unmatched.
- Quality Checks tab shows source and field warnings.
- Raw JSON is only visible in Raw Info.
- No frontend code maps a specific field name to a business metric.

## Reference spec

Read `PMAIOS_ENTERPRISE_CHAT_DISCLOSURE_LAYER_SPEC.md` in this bundle for full contracts and implementation details.
