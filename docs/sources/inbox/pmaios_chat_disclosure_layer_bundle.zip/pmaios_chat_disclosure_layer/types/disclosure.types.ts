export type DisclosureScope = 'message' | 'task' | 'conversation';

export type DisclosureStatus = 'running' | 'completed' | 'partial' | 'failed' | 'cancelled';
export type DisclosureSeverity = 'info' | 'success' | 'warning' | 'error';
export type DisclosureVisibility = 'visible' | 'redacted' | 'hidden';

export type DisclosureStage =
  | 'understanding'
  | 'context_loading'
  | 'slot_extract'
  | 'skill_contract'
  | 'permission_check'
  | 'workflow'
  | 'mcp_orchestration'
  | 'tool_call'
  | 'data_fetching'
  | 'analysis'
  | 'field_resolution'
  | 'quality_check'
  | 'response_generation'
  | 'rendering'
  | 'unknown';

export interface MessageDisclosureView {
  schema_version: 'pmaios.disclosure.v1';
  tenant_id?: string;
  conversation_id: string;
  message_id: string;
  task_id?: string;
  run_id: string;
  trace_id?: string;
  trace_url?: string;
  scope: DisclosureScope;
  status: DisclosureStatus;
  started_at?: string;
  completed_at?: string;
  duration_ms?: number;
  summary: DisclosureSummary;
  intent?: IntentDisclosure;
  route?: RouteDisclosure;
  steps: ExecutionStep[];
  evidence: EvidenceBundle;
  fields: FieldCatalogView;
  quality: QualityCheck[];
  raw: RawInfoBundle;
  permissions: DisclosurePermissionView;
  ui_hints?: DisclosureUiHints;
}

export interface DisclosureSummary {
  title: string;
  description?: string;
  task_type?: string;
  counters: {
    step_count: number;
    tool_call_count: number;
    source_count: number;
    evidence_count: number;
    returned_field_count: number;
    matched_field_count: number;
    warning_count: number;
    error_count: number;
  };
  highlights: Array<{
    label: string;
    value: string | number;
    severity?: DisclosureSeverity;
  }>;
  warnings?: Array<{
    code: string;
    message: string;
    stage?: DisclosureStage;
  }>;
}

export interface IntentDisclosure {
  raw_user_query?: string;
  intent_type?: string;
  normalized_task?: string;
  confidence?: number;
  slots: Array<{
    key: string;
    label?: string;
    value: unknown;
    display_value?: string;
    confidence?: number;
    source?: 'user' | 'context' | 'default' | 'inferred' | 'system';
  }>;
  requested_metrics?: Array<{
    key?: string;
    label: string;
    canonical_metric_id?: string;
    confidence?: number;
  }>;
}

export interface RouteDisclosure {
  task_intent?: string;
  skill_contract_id?: string;
  skill_contract_version?: string;
  workflow_id?: string;
  workflow_version?: string;
  agent_id?: string;
  capabilities: Array<{
    capability_id: string;
    name?: string;
    type: 'tool' | 'workflow' | 'mcp' | 'model' | 'retriever' | 'renderer' | 'other';
    descriptor_version?: string;
  }>;
}

export interface ExecutionStep {
  step_id: string;
  parent_step_id?: string;
  order: number;
  stage: DisclosureStage;
  title: string;
  status: 'running' | 'success' | 'warning' | 'failed' | 'skipped';
  severity?: DisclosureSeverity;
  component?: string;
  capability_id?: string;
  span_id?: string;
  parent_span_id?: string;
  tool_call_id?: string;
  started_at?: string;
  completed_at?: string;
  duration_ms?: number;
  input_summary?: string;
  output_summary?: string;
  request?: RedactedPayload;
  response?: RedactedPayload;
  artifacts?: ArtifactRef[];
  warnings?: Array<{ code: string; message: string; suggestion?: string }>;
  errors?: Array<{ code: string; message: string; retryable?: boolean }>;
}

export interface RedactedPayload {
  visibility: DisclosureVisibility;
  redaction_reason?: string;
  content_type: 'json' | 'text' | 'table' | 'markdown' | 'binary_ref';
  data?: unknown;
  artifact_id?: string;
}

export interface ArtifactRef {
  artifact_id: string;
  type: 'table' | 'json' | 'text' | 'file' | 'image' | 'chart' | 'log' | 'other';
  title?: string;
  preview_url?: string;
  download_url?: string;
  visibility?: DisclosureVisibility;
}

export interface EvidenceBundle {
  sources: SourceRef[];
  items: EvidenceItem[];
  empty_state?: {
    reason: 'no_tool_call' | 'no_external_source' | 'source_metadata_missing' | 'permission_hidden' | 'not_applicable';
    message: string;
    suggestion?: string;
  };
}

export interface SourceRef {
  source_id: string;
  type: 'data_api' | 'report' | 'database' | 'knowledge_base' | 'file' | 'web' | 'mcp_tool' | 'runtime_context' | 'conversation' | 'other';
  name: string;
  description?: string;
  owner?: string;
  query_id?: string;
  report_id?: string;
  dataset_id?: string;
  table_name?: string;
  snapshot_at?: string;
  catalog_version?: string;
  permission_status?: 'allowed' | 'redacted' | 'hidden' | 'denied';
  url?: string;
  metadata?: Record<string, unknown>;
}

export interface EvidenceItem {
  evidence_id: string;
  source_id?: string;
  type: 'metric' | 'table' | 'document_snippet' | 'query_result' | 'tool_response' | 'file_excerpt' | 'chart' | 'log' | 'other';
  title: string;
  summary?: string;
  artifact_id?: string;
  preview?: RedactedPayload;
  related_fields?: string[];
  related_steps?: string[];
}

export interface FieldCatalogView {
  returned_fields: FieldDefinition[];
  requested_metric_alignment?: MetricAlignment[];
  coverage: {
    returned_field_count: number;
    matched_count: number;
    ambiguous_count: number;
    unmatched_count: number;
    masked_count: number;
  };
  empty_state?: {
    reason: 'no_returned_fields' | 'catalog_missing' | 'permission_hidden' | 'not_applicable';
    message: string;
    suggestion?: string;
  };
}

export interface FieldDefinition {
  field: string;
  label?: string;
  description?: string;
  data_type?: string;
  unit?: string;
  formula?: string;
  aggregation?: string;
  attribution_window?: string;
  semantic_type?: 'metric' | 'dimension' | 'time' | 'identifier' | 'unknown';
  catalog_status: 'matched' | 'ambiguous' | 'unmatched' | 'masked';
  catalog_id?: string;
  catalog_version?: string;
  confidence?: number;
  warnings?: Array<{ code: string; message: string }>;
}

export interface MetricAlignment {
  requested_label: string;
  canonical_metric_id?: string;
  status: 'covered' | 'partially_covered' | 'not_covered' | 'ambiguous';
  matched_fields: string[];
  message?: string;
}

export interface QualityCheck {
  check_id: string;
  code: string;
  title: string;
  status: 'pass' | 'warning' | 'fail' | 'info';
  stage?: DisclosureStage;
  severity: DisclosureSeverity;
  message: string;
  suggestion?: string;
  affected_steps?: string[];
  affected_fields?: string[];
  evidence_ids?: string[];
}

export interface RawInfoBundle {
  visibility: DisclosureVisibility;
  redaction_reason?: string;
  trace?: {
    trace_id?: string;
    trace_url?: string;
    run_id: string;
  };
  tool_calls: Array<{
    tool_call_id: string;
    capability_id?: string;
    operation?: string;
    status: string;
    duration_ms?: number;
    request?: RedactedPayload;
    response?: RedactedPayload;
    span_id?: string;
  }>;
  artifacts: ArtifactRef[];
  legacy_raw?: RedactedPayload;
}

export interface DisclosurePermissionView {
  viewer_role?: 'viewer' | 'business' | 'developer' | 'admin';
  can_view_raw_request: boolean;
  can_view_raw_response: boolean;
  can_view_trace_url: boolean;
  can_copy_raw: boolean;
  redactions: Array<{ path: string; reason: string }>;
}

export interface DisclosureUiHints {
  default_tab?: 'overview' | 'execution' | 'evidence' | 'fields' | 'quality' | 'raw';
  initially_expanded_step_ids?: string[];
  preferred_density?: 'comfortable' | 'compact';
}

export interface DisclosureEvent {
  schema_version: 'pmaios.disclosure_event.v1';
  event_id: string;
  tenant_id?: string;
  conversation_id: string;
  message_id: string;
  task_id?: string;
  run_id: string;
  trace_id?: string;
  span_id?: string;
  parent_span_id?: string;
  timestamp: string;
  stage: DisclosureStage;
  event_type: 'stage_started' | 'stage_completed' | 'stage_warning' | 'stage_failed' | 'artifact_created' | 'source_attached' | 'field_resolved' | 'quality_check';
  title?: string;
  input_summary?: string;
  output_summary?: string;
  payload?: unknown;
  visibility?: DisclosureVisibility;
}

export interface ToolResultEnvelope<T = unknown> {
  schema_version: 'pmaios.tool_result.v1';
  tool_call_id: string;
  capability_id: string;
  operation?: string;
  status: 'success' | 'partial' | 'failed';
  trace_id?: string;
  span_id?: string;
  started_at?: string;
  completed_at?: string;
  duration_ms?: number;
  request_redacted?: unknown;
  response_redacted?: T;
  source_refs?: SourceRef[];
  evidence_items?: EvidenceItem[];
  artifacts?: ArtifactRef[];
  returned_fields?: Array<{ field: string; data_type?: string; semantic_type?: string }>;
  field_catalog_refs?: Array<{ field: string; catalog_id?: string; catalog_version?: string; status: 'matched' | 'ambiguous' | 'unmatched' | 'masked' }>;
  warnings?: Array<{ code: string; message: string; suggestion?: string }>;
  error?: { code: string; message: string; retryable?: boolean };
}
