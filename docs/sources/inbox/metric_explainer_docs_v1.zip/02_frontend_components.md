# 智投 Chat 指标解释器：前端组件设计需求

版本：v1.0  
适用项目：智投 Chat / PMChat / Ant Design X / A2UI  
建议路径：`docs/metric-explainer/02_frontend_components.md`

---

# 1. 设计目标

指标解释器前端组件用于在 Chat 中结构化展示指标解释结果。

目标不是普通 Markdown 回答，而是形成：

```text
对话消息
+ 指标解释卡
+ 公式拆解卡
+ 数据来源卡
+ 上报信息卡
+ 预处理卡
+ 计算口径卡
+ 调度状态卡
+ 报表差异卡
+ 口径差异卡
+ 血缘卡
+ FAQ / 推荐追问
+ 下一步操作
```

整体设计原则：

```text
Chat-first
Message-first
Card-based
Progressive Disclosure
Agent-controlled UI
Evidence Traceable
Actionable
```

---

# 2. 技术基线

前端技术栈：

```text
React
TypeScript
Ant Design
Ant Design X
@ant-design/x-markdown
@ant-design/x-card
@ant-design/x-skill
A2UI
React Query
Zustand
```

组件接入位置：

```text
src/
├── features/
│   └── metric-explainer/
│       ├── components/
│       ├── schemas/
│       ├── renderers/
│       ├── hooks/
│       └── mock/
```

---

# 3. 动态 UI 渲染协议

Agent 返回结构化 UI Schema。

```ts
export interface MetricExplainerUISchema {
  ui_schema_version: 'metric_explainer_v1';
  answer_type:
    | 'metric_definition'
    | 'metric_formula'
    | 'metric_source'
    | 'metric_difference'
    | 'metric_diagnosis'
    | 'metric_faq';
  metric_id?: string;
  metric_name?: string;
  summary?: string;
  components: MetricExplainerComponent[];
  sources?: MetricSourceRef[];
  actions?: MetricAction[];
}
```

组件类型：

```ts
export type MetricExplainerComponent =
  | MetricExplainCardSchema
  | FormulaCardSchema
  | DataSourceCardSchema
  | TrackingCardSchema
  | PreprocessingCardSchema
  | CalculationCardSchema
  | SchedulerCardSchema
  | ReportDifferenceCardSchema
  | MetricDifferenceCardSchema
  | AmbiguityCardSchema
  | LineageCardSchema
  | FAQCardSchema
  | ActionCardSchema;
```

---

# 4. 组件清单

## 4.1 MetricExplainCard

用途：

回答“这个指标是什么意思”。

展示内容：

- 指标名称
- 指标分类
- 一句话解释
- 业务含义
- 使用场景
- 指标状态
- 负责人
- 更新时间

Schema：

```ts
export interface MetricExplainCardSchema {
  type: 'metric_explain_card';
  props: {
    metricId: string;
    metricName: string;
    aliases?: string[];
    category?: string;
    subCategory?: string;
    level?: 'core' | 'important' | 'normal';
    status?: 'online' | 'draft' | 'deprecated';
    shortDefinition: string;
    businessMeaning?: string;
    usageScenarios?: string[];
    updatedAt?: string;
    owner?: string;
  };
}
```

视觉要求：

```text
- 顶部展示指标名和分类 Tag
- 一句话解释作为主内容
- 使用场景用 Tag 或轻量 List 展示
- 如果 status=deprecated，需要展示红色风险提示
```

---

## 4.2 FormulaCard

用途：

回答“怎么算”。

展示内容：

- 公式
- 分子解释
- 分母解释
- 聚合逻辑
- 单位
- 示例计算

Schema：

```ts
export interface FormulaCardSchema {
  type: 'formula_card';
  props: {
    formulaText: string;
    formulaLatex?: string;
    numerator?: {
      name: string;
      description?: string;
      field?: string;
    };
    denominator?: {
      name: string;
      description?: string;
      field?: string;
    };
    aggregation?: string;
    unit?: string;
    displayFormat?: string;
    roundRule?: string;
    example?: {
      input: string;
      output: string;
    };
  };
}
```

视觉要求：

```text
- 公式区使用高亮背景
- 分子 / 分母并列展示
- 示例计算默认折叠
- 字段名用 code 样式
```

---

## 4.3 DataSourceCard

用途：

回答“数据从哪里来”。

展示内容：

- 来源系统
- 表名
- 字段名
- 更新频率
- 数据负责人
- 可靠性等级

Schema：

```ts
export interface DataSourceCardSchema {
  type: 'data_source_card';
  props: {
    sources: Array<{
      sourceName: string;
      sourceType?: string;
      system?: string;
      database?: string;
      table?: string;
      field?: string;
      fieldDescription?: string;
      updateFrequency?: string;
      owner?: string;
      reliability?: 'high' | 'medium' | 'low';
    }>;
  };
}
```

视觉要求：

```text
- 多来源用 Table 或 Descriptions 展示
- reliability=low 时展示风险图标
- 表名、字段名可复制
```

---

## 4.4 TrackingCard

用途：

回答“数据怎么上报”。

展示内容：

- 事件名称
- 事件 ID
- 触发时机
- 触发逻辑
- SDK / API
- 上传方式
- 重试策略
- 去重键
- 常见上报问题

Schema：

```ts
export interface TrackingCardSchema {
  type: 'tracking_card';
  props: {
    eventName?: string;
    eventId?: string;
    triggerTiming?: string;
    triggerLogic?: string;
    sdkOrApi?: string;
    uploadMode?: string;
    uploadTiming?: string;
    retryStrategy?: string;
    dedupKey?: string;
    validationRule?: string;
    commonIssues?: string[];
  };
}
```

视觉要求：

```text
- 核心上报字段用 Descriptions
- commonIssues 用 Alert + List
- 适合埋点、回传、订单事件说明
```

---

## 4.5 PreprocessingCard

用途：

回答“数据如何预处理”。

展示内容：

- 时区转换
- 汇率转换
- 去重规则
- 脏数据过滤
- 测试数据过滤
- 用户合并
- 归因合并
- 空值处理
- 异常值处理

Schema：

```ts
export interface PreprocessingCardSchema {
  type: 'preprocessing_card';
  props: {
    timezoneProcess?: string;
    currencyConvert?: string;
    dedupRule?: string;
    dirtyDataFilter?: string;
    testDataFilter?: string;
    userMergeRule?: string;
    attributionMergeRule?: string;
    nullValueProcess?: string;
    outlierProcess?: string;
  };
}
```

视觉要求：

```text
- 用 Steps 或 Timeline 展示处理顺序
- 高风险处理逻辑使用 Warning Tag
- 支持展开查看详细说明
```

---

## 4.6 CalculationCard

用途：

回答“计算口径是什么”。

展示内容：

- SQL 或伪 SQL
- 聚合逻辑
- group by 维度
- 过滤条件
- 归因规则
- 时间窗口
- 示例输入输出

Schema：

```ts
export interface CalculationCardSchema {
  type: 'calculation_card';
  props: {
    calculationLogic?: string;
    calculationSql?: string;
    groupByDimensions?: string[];
    filterConditions?: string[];
    attributionRule?: string;
    timeWindow?: {
      eventTime?: string;
      start?: string;
      end?: string;
      timezone?: string;
    };
    example?: {
      input: string;
      output: string;
    };
  };
}
```

视觉要求：

```text
- 计算逻辑默认展开
- SQL 默认折叠
- 时间窗口必须醒目展示
- 过滤条件用 Checklist 样式
```

---

## 4.7 SchedulerCard

用途：

回答“什么时候更新”。

展示内容：

- 调度任务
- cron
- 依赖任务
- 输出表
- SLA
- 重试策略
- 延迟策略
- 告警策略

Schema：

```ts
export interface SchedulerCardSchema {
  type: 'scheduler_card';
  props: {
    taskName?: string;
    taskType?: string;
    cron?: string;
    dependencies?: string[];
    outputTable?: string;
    sla?: string;
    retryPolicy?: string;
    delayPolicy?: string;
    owner?: string;
    alertPolicy?: string;
    latestStatus?: 'success' | 'running' | 'failed' | 'delayed' | 'unknown';
    latestRunTime?: string;
  };
}
```

视觉要求：

```text
- latestStatus 用状态 Badge
- dependencies 用 Tag 或小型 DAG
- failed/delayed 状态展示 Alert
```

---

## 4.8 ReportDifferenceCard

用途：

回答“为什么不同报表不一样”。

展示内容：

- 报表 A
- 报表 B
- 差异类型
- 差异原因
- 用户解释
- 排查方式

Schema：

```ts
export interface ReportDifferenceCardSchema {
  type: 'report_difference_card';
  props: {
    differences: Array<{
      reportA: string;
      reportB: string;
      differenceType: string;
      reason: string;
      userExplanation?: string;
      diagnosisMethod?: string;
    }>;
  };
}
```

视觉要求：

```text
- 左右对比布局
- 差异原因用重点块展示
- diagnosisMethod 转换为可点击 Action
```

---

## 4.9 MetricDifferenceCard

用途：

回答“为什么两个指标口径不一样”。

展示内容：

- 指标 A
- 指标 B
- 差异类型
- 差异原因
- 用户解释

Schema：

```ts
export interface MetricDifferenceCardSchema {
  type: 'metric_difference_card';
  props: {
    differences: Array<{
      metricA: string;
      metricB: string;
      differenceType: string;
      reason: string;
      userExplanation?: string;
    }>;
  };
}
```

视觉要求：

```text
- 使用对比卡
- 对差异字段加粗
- 支持点击“查看完整口径”
```

---

## 4.10 AmbiguityCard

用途：

解释常见误解。

Schema：

```ts
export interface AmbiguityCardSchema {
  type: 'ambiguity_card';
  props: {
    items: Array<{
      userMisunderstanding: string;
      actualMeaning: string;
      recommendedAnswer?: string;
    }>;
  };
}
```

视觉要求：

```text
- “常见误解”用 Warning 样式
- “实际含义”用 Normal 样式
- 推荐回答可复制
```

---

## 4.11 LineageCard

用途：

展示指标数据血缘。

展示方式：

```text
上游系统 → ODS → DWD → DWS → ADS → 报表/Chat/API
```

Schema：

```ts
export interface LineageCardSchema {
  type: 'lineage_card';
  props: {
    upstreamSystems?: string[];
    upstreamTables?: string[];
    processingLayers?: string[];
    downstreamReports?: string[];
    downstreamApis?: string[];
    downstreamAgents?: string[];
    mermaid?: string;
  };
}
```

视觉要求：

```text
- 简版用横向 Flow
- 复杂版用 Mermaid 或 React Flow
- 默认展示关键链路，详细血缘折叠
```

---

## 4.12 FAQCard

用途：

展示常见问题和推荐追问。

Schema：

```ts
export interface FAQCardSchema {
  type: 'faq_card';
  props: {
    faqs: Array<{
      question: string;
      answer: string;
      nextActions?: string[];
    }>;
  };
}
```

视觉要求：

```text
- 使用 Collapse
- question 作为标题
- nextActions 渲染为 Button
```

---

## 4.13 ActionCard

用途：

承接下一步动作。

支持动作：

```text
查看报表
查看 SQL
查看血缘
查看调度
启动差异排查
创建监控告警
生成指标文档
反馈口径问题
```

Schema：

```ts
export interface MetricAction {
  label: string;
  action:
    | 'open_report'
    | 'view_sql'
    | 'view_lineage'
    | 'view_scheduler'
    | 'start_diagnosis'
    | 'create_alert'
    | 'generate_doc'
    | 'feedback_metric';
  params?: Record<string, unknown>;
}

export interface ActionCardSchema {
  type: 'action_card';
  props: {
    actions: MetricAction[];
  };
}
```

---

# 5. 渲染器设计

建议实现统一渲染入口：

```tsx
export function MetricExplainerRenderer({ schema }: { schema: MetricExplainerUISchema }) {
  return (
    <div className="metric-explainer-renderer">
      {schema.summary && <MetricSummary summary={schema.summary} />}
      {schema.components.map((component, index) => (
        <MetricComponentRenderer key={index} component={component} />
      ))}
      {schema.sources?.length ? <MetricSources sources={schema.sources} /> : null}
      {schema.actions?.length ? <MetricActions actions={schema.actions} /> : null}
    </div>
  );
}
```

组件路由：

```tsx
export function MetricComponentRenderer({ component }: { component: MetricExplainerComponent }) {
  switch (component.type) {
    case 'metric_explain_card':
      return <MetricExplainCard {...component.props} />;
    case 'formula_card':
      return <FormulaCard {...component.props} />;
    case 'data_source_card':
      return <DataSourceCard {...component.props} />;
    case 'tracking_card':
      return <TrackingCard {...component.props} />;
    case 'preprocessing_card':
      return <PreprocessingCard {...component.props} />;
    case 'calculation_card':
      return <CalculationCard {...component.props} />;
    case 'scheduler_card':
      return <SchedulerCard {...component.props} />;
    case 'report_difference_card':
      return <ReportDifferenceCard {...component.props} />;
    case 'metric_difference_card':
      return <MetricDifferenceCard {...component.props} />;
    case 'ambiguity_card':
      return <AmbiguityCard {...component.props} />;
    case 'lineage_card':
      return <LineageCard {...component.props} />;
    case 'faq_card':
      return <FAQCard {...component.props} />;
    case 'action_card':
      return <ActionCard {...component.props} />;
    default:
      return <UnknownMetricComponent component={component} />;
  }
}
```

---

# 6. Chat 消息接入方式

在 PMChat 中，消息内容建议支持三类渲染：

```ts
type ChatMessageContent =
  | { kind: 'markdown'; content: string }
  | { kind: 'metric_explainer'; schema: MetricExplainerUISchema }
  | { kind: 'mixed'; markdown?: string; schema?: MetricExplainerUISchema };
```

当 Agent 判断为指标解释类问题时：

```text
1. 先返回一句自然语言 summary
2. 再返回 metric_explainer schema
3. 前端使用 MetricExplainerRenderer 渲染
```

---

# 7. 不同问题的组件编排

## 7.1 用户问“这个指标是什么意思”

推荐组件：

```text
MetricExplainCard
FormulaCard
FAQCard
ActionCard
```

## 7.2 用户问“怎么算”

推荐组件：

```text
FormulaCard
CalculationCard
DataSourceCard
ActionCard
```

## 7.3 用户问“数据从哪里来”

推荐组件：

```text
DataSourceCard
TrackingCard
PreprocessingCard
LineageCard
```

## 7.4 用户问“为什么不一致”

推荐组件：

```text
ReportDifferenceCard
MetricDifferenceCard
CalculationCard
SchedulerCard
ActionCard
```

## 7.5 用户问“为什么异常波动”

推荐组件：

```text
MetricExplainCard
SchedulerCard
DataSourceCard
ReportDifferenceCard
LineageCard
ActionCard
```

---

# 8. 样例 UI Schema

```json
{
  "ui_schema_version": "metric_explainer_v1",
  "answer_type": "metric_difference",
  "metric_id": "roi_d1",
  "metric_name": "首日ROI",
  "summary": "首日ROI用于衡量用户激活当天的广告收入回收效率。BI 和媒体后台不一致通常来自归因口径、刷新周期和收入口径差异。",
  "components": [
    {
      "type": "metric_explain_card",
      "props": {
        "metricId": "roi_d1",
        "metricName": "首日ROI",
        "aliases": ["D1 ROI", "首日回收"],
        "category": "投放效果",
        "subCategory": "回收指标",
        "level": "core",
        "status": "online",
        "shortDefinition": "首日ROI用于衡量用户激活当天的广告收入回收效率。",
        "businessMeaning": "用于判断新素材、新计划、新渠道在冷启动阶段的短期回收质量。",
        "usageScenarios": ["新广告计划冷启动", "素材初筛", "渠道质量初判"],
        "updatedAt": "2026-05-14",
        "owner": "广告数据产品"
      }
    },
    {
      "type": "formula_card",
      "props": {
        "formulaText": "首日ROI = 首日充值收入 / 广告消耗",
        "formulaLatex": "ROI_{D1}=Revenue_{D1}/Cost",
        "numerator": {
          "name": "首日充值收入",
          "description": "归因用户在激活当天产生的充值金额",
          "field": "pay_amount_d1"
        },
        "denominator": {
          "name": "广告消耗",
          "description": "媒体 API 或广告成本表中的消耗金额",
          "field": "cost"
        },
        "unit": "%",
        "roundRule": "保留两位小数"
      }
    },
    {
      "type": "report_difference_card",
      "props": {
        "differences": [
          {
            "reportA": "广告BI",
            "reportB": "媒体后台",
            "differenceType": "归因口径差异",
            "reason": "广告BI采用内部混合归因，媒体后台采用媒体自归因。",
            "userExplanation": "两个系统对用户来源的归属规则不同，因此 ROI 不会完全一致。",
            "diagnosisMethod": "先对比消耗、激活、收入三个基础指标。"
          }
        ]
      }
    }
  ],
  "actions": [
    {
      "label": "查看相关报表",
      "action": "open_report",
      "params": {
        "report_id": "ad_roi_dashboard"
      }
    },
    {
      "label": "启动差异排查",
      "action": "start_diagnosis",
      "params": {
        "metric_id": "roi_d1"
      }
    }
  ]
}
```

---

# 9. 视觉规范

推荐风格：

```text
- Chat 气泡内嵌卡片
- 卡片圆角 12px
- 主解释卡信息密度中等
- 公式卡高亮但不喧宾夺主
- 差异卡用左右对比
- 血缘卡用横向 Flow
- FAQ 默认折叠
- SQL / 调度 / 技术细节默认折叠
```

信息优先级：

```text
P0：一句话解释、公式、关键差异
P1：数据来源、计算口径、时间窗口
P2：上报、预处理、调度、血缘
P3：SQL、任务依赖、详细 FAQ
```

---

# 10. 验收标准

前端验收：

```text
1. 能渲染 metric_explainer_v1 schema。
2. 每类组件都有空数据 fallback。
3. 未知组件不会导致页面崩溃。
4. 长内容默认折叠。
5. 表名、字段名、SQL 支持复制。
6. Action 能统一派发事件。
7. Chat 中同一条消息可以同时包含 Markdown 和结构化组件。
8. 移动端下卡片可纵向堆叠。
9. 所有组件支持 loading / error / empty 状态。
10. 支持后续接入真实报表、调度、血缘服务。
```
