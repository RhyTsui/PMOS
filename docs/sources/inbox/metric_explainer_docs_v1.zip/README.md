# 智投 Chat 指标解释器 README

本压缩包包含 3 份可直接放入智投 Chat / PMChat 项目的设计与实现文档。

## 文件说明

```text
01_metric_template.md
```

指标知识库模板与治理规范。  
用于定义每个指标应该如何录入，包括定义、公式、数据来源、上报、预处理、计算、调度、血缘、报表差异、口径差异、常见歧义和 FAQ。

```text
02_frontend_components.md
```

前端组件设计需求。  
用于指导 React + Ant Design X + A2UI 实现 Chat 内的结构化指标解释组件。

```text
03_codex_prompts.md
```

Codex CLI 实现提示词与任务清单。  
可以直接拆段复制给 Codex CLI，在智投 Chat 项目中实现指标解释器能力。

## 推荐放置路径

```text
docs/
└── metric-explainer/
    ├── 01_metric_template.md
    ├── 02_frontend_components.md
    └── 03_codex_prompts.md
```

## 推荐执行顺序

1. 先把 `01_metric_template.md` 放入知识库规范。
2. 再把 `02_frontend_components.md` 给前端作为组件需求。
3. 最后把 `03_codex_prompts.md` 分阶段丢给 Codex CLI 执行。

## 最小落地目标

第一阶段只需要实现：

```text
MetricExplainCard
FormulaCard
DataSourceCard
CalculationCard
ReportDifferenceCard
ActionCard
```

配合一个 `roi_d1` mock schema，即可完成指标解释器 MVP。
