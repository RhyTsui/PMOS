# 智投 Chat 指标解释器：Codex CLI 实现提示词与任务清单

版本：v1.0  
适用项目：智投 Chat / PMChat / Codex CLI  
建议路径：`docs/metric-explainer/03_codex_prompts.md`

---

# 1. 使用方式

本文档用于直接给 Codex CLI 执行。

推荐执行方式：

```bash
cd E:\AI\ai-os
codex
```

然后把下面的任务提示词分阶段贴给 Codex CLI。

目标是在智投 Chat 项目中落地：

```text
1. 指标解释器知识模板
2. 前端结构化组件
3. A2UI 动态渲染协议
4. Mock 数据
5. Chat 消息接入示例
6. 基础验收测试
```

---

# 2. 总任务提示词

```text
你现在在智投 Chat / PMChat 项目中工作。请基于 React + TypeScript + Ant Design + Ant Design X 实现一个“指标解释器 Metric Explainer”能力。

这个能力用于广告 BI / 监测管理系统中的指标问答。用户在 Chat 中询问指标定义、计算公式、数据来源、上报信息、预处理信息、计算口径、调度信息、报表差异、口径差异、常见歧义、常见问题时，Agent 会返回结构化 UI Schema，前端需要将其渲染为 Chat 内的结构化组件。

请严格遵循以下原则：

1. 不要做成独立 Dashboard 页面，必须是 Chat-first 的消息内组件。
2. 使用 TypeScript 定义 schema。
3. 组件必须可组合、可扩展、可 fallback。
4. 未知组件不能导致页面崩溃。
5. 长内容默认折叠。
6. 表名、字段名、SQL 支持复制。
7. 所有组件支持 empty / error / loading 的基础状态。
8. 先实现 mock 数据和静态渲染，再预留 API 接口。
9. 组件放在 feature 目录，不要污染全局组件。
10. 输出必要的 README 和示例。
```

---

# 3. 推荐文件结构

要求 Codex 创建以下结构：

```text
src/
└── features/
    └── metric-explainer/
        ├── README.md
        ├── index.ts
        ├── schemas/
        │   ├── metricExplainerSchema.ts
        │   └── metricKnowledgeTemplate.ts
        ├── components/
        │   ├── MetricExplainerRenderer.tsx
        │   ├── MetricComponentRenderer.tsx
        │   ├── MetricExplainCard.tsx
        │   ├── FormulaCard.tsx
        │   ├── DataSourceCard.tsx
        │   ├── TrackingCard.tsx
        │   ├── PreprocessingCard.tsx
        │   ├── CalculationCard.tsx
        │   ├── SchedulerCard.tsx
        │   ├── ReportDifferenceCard.tsx
        │   ├── MetricDifferenceCard.tsx
        │   ├── AmbiguityCard.tsx
        │   ├── LineageCard.tsx
        │   ├── FAQCard.tsx
        │   ├── ActionCard.tsx
        │   └── UnknownMetricComponent.tsx
        ├── hooks/
        │   └── useMetricExplainerActions.ts
        ├── mock/
        │   ├── roiD1MetricSchema.ts
        │   └── metricExplainerExamples.ts
        └── styles/
            └── metricExplainer.css
```

---

# 4. 阶段一：创建 Schema

给 Codex 的提示词：

```text
请先实现指标解释器的 TypeScript schema。

创建文件：

src/features/metric-explainer/schemas/metricExplainerSchema.ts

要求：

1. 定义 MetricExplainerUISchema。
2. 定义 answer_type 枚举：
   - metric_definition
   - metric_formula
   - metric_source
   - metric_tracking
   - metric_preprocessing
   - metric_calculation
   - metric_scheduler
   - metric_difference
   - metric_diagnosis
   - metric_faq

3. 定义组件 union type：
   - metric_explain_card
   - formula_card
   - data_source_card
   - tracking_card
   - preprocessing_card
   - calculation_card
   - scheduler_card
   - report_difference_card
   - metric_difference_card
   - ambiguity_card
   - lineage_card
   - faq_card
   - action_card

4. 每个组件都要有独立 interface。
5. 定义 MetricAction、MetricSourceRef。
6. 所有字段尽量 optional，但核心展示字段必须明确。
7. 导出所有类型。
8. 不要引入 React。
9. 代码需要可通过 TypeScript 编译。
```

---

# 5. 阶段二：创建知识模板类型

给 Codex 的提示词：

```text
请创建指标知识库模板 TypeScript 类型。

创建文件：

src/features/metric-explainer/schemas/metricKnowledgeTemplate.ts

要求定义 MetricKnowledgeTemplate 类型，覆盖以下层次：

1. 基础信息层
2. 指标定义层
3. 公式计算层
4. 数据来源层
5. 上报信息层
6. 预处理信息层
7. 计算信息层
8. 调度信息层
9. 数据血缘层
10. 报表差异层
11. 计算口径差异层
12. 常见歧义层
13. 常见问题层
14. 治理与版本层

需要让这个类型能够承载 YAML 中的指标知识模板。请同时导出一个 createEmptyMetricTemplate() 方法，返回空模板对象，方便后续编辑器或录入工具使用。
```

---

# 6. 阶段三：实现 Renderer

给 Codex 的提示词：

```text
请实现指标解释器的统一渲染器。

创建文件：

src/features/metric-explainer/components/MetricExplainerRenderer.tsx
src/features/metric-explainer/components/MetricComponentRenderer.tsx
src/features/metric-explainer/components/UnknownMetricComponent.tsx

要求：

1. MetricExplainerRenderer 接收 schema: MetricExplainerUISchema。
2. 顶部展示 schema.summary。
3. 遍历 schema.components，调用 MetricComponentRenderer。
4. 底部展示 schema.sources 和 schema.actions。
5. MetricComponentRenderer 根据 component.type 渲染对应组件。
6. UnknownMetricComponent 用于未知组件 fallback，不能抛异常。
7. 使用 Ant Design 的 Card、Space、Typography、Alert 等基础组件。
8. 先不要实现复杂样式，保证结构清晰。
```

---

# 7. 阶段四：实现核心卡片组件

给 Codex 的提示词：

```text
请实现第一批核心组件：

1. MetricExplainCard
2. FormulaCard
3. DataSourceCard
4. CalculationCard
5. ReportDifferenceCard
6. ActionCard

要求：

- 文件放在 src/features/metric-explainer/components/
- 使用 Ant Design 组件实现
- 样式轻量，不要写复杂视觉
- 所有组件都要支持空字段 fallback
- FormulaCard 中公式区域要高亮展示
- DataSourceCard 中表名和字段名用 Typography.Text code 展示
- CalculationCard 中 SQL 默认折叠
- ReportDifferenceCard 使用左右对比或列表对比
- ActionCard 将 action 统一回调给 onAction
```

---

# 8. 阶段五：实现增强卡片组件

给 Codex 的提示词：

```text
请实现第二批增强组件：

1. TrackingCard
2. PreprocessingCard
3. SchedulerCard
4. MetricDifferenceCard
5. AmbiguityCard
6. LineageCard
7. FAQCard

要求：

- TrackingCard 使用 Descriptions + Alert 展示常见上报问题
- PreprocessingCard 使用 Timeline 或 List 展示处理规则
- SchedulerCard 使用 Badge 展示 latestStatus
- MetricDifferenceCard 使用对比布局
- AmbiguityCard 明确展示“常见误解”和“实际含义”
- LineageCard 先实现简版横向链路；如果有 mermaid 字段，预留 Mermaid 渲染位置
- FAQCard 使用 Collapse 展示问答
```

---

# 9. 阶段六：创建 Mock 数据

给 Codex 的提示词：

```text
请创建指标解释器 mock 数据。

创建文件：

src/features/metric-explainer/mock/roiD1MetricSchema.ts
src/features/metric-explainer/mock/metricExplainerExamples.ts

要求：

1. roiD1MetricSchema 导出一个完整的首日 ROI 指标解释 schema。
2. 必须覆盖以下组件：
   - metric_explain_card
   - formula_card
   - data_source_card
   - tracking_card
   - preprocessing_card
   - calculation_card
   - scheduler_card
   - report_difference_card
   - metric_difference_card
   - ambiguity_card
   - lineage_card
   - faq_card
   - action_card

3. metricExplainerExamples 导出多个场景：
   - 什么是首日 ROI
   - 首日 ROI 怎么算
   - 数据从哪里来
   - 为什么和媒体后台不一样
   - 为什么今天 ROI 下降
```

---

# 10. 阶段七：Chat 接入示例

给 Codex 的提示词：

```text
请在不破坏现有 PMChat 架构的前提下，增加一个指标解释器消息渲染示例。

要求：

1. 不要重构现有 Chat 主流程。
2. 找到当前消息渲染入口。
3. 如果消息 content.kind === 'metric_explainer'，则调用 MetricExplainerRenderer。
4. 如果消息 content.kind === 'markdown'，保持原有 Markdown 渲染。
5. 如果消息 content.kind === 'mixed'，则先展示 markdown，再展示 MetricExplainerRenderer。
6. 如果当前项目还没有这种 message content 结构，只新增一个示例 Demo 或 Story，不要强行改核心架构。
7. 加入 roiD1MetricSchema 的展示入口，方便本地验证。
```

---

# 11. 阶段八：导出入口

给 Codex 的提示词：

```text
请为 metric-explainer feature 增加统一导出。

创建或更新：

src/features/metric-explainer/index.ts

导出：

- MetricExplainerRenderer
- MetricComponentRenderer
- 所有 card components
- 所有 schema types
- mock examples

同时创建 README.md，说明：

1. 这个 feature 是什么
2. 如何传入 schema
3. 如何渲染
4. 如何处理 actions
5. 如何扩展新组件
```

---

# 12. 阶段九：基础测试

给 Codex 的提示词：

```text
请为指标解释器补充最小测试或验收脚本。

如果项目已有测试框架，请使用现有框架。
如果没有测试框架，请至少创建一个开发验收文档。

测试要求：

1. MetricExplainerRenderer 能正常渲染 roiD1MetricSchema。
2. 未知组件 type 不会导致崩溃。
3. 空 components 能展示 empty 状态。
4. ActionCard 点击后能触发 onAction。
5. FormulaCard 在缺少 numerator/denominator 时仍能展示公式。
6. SchedulerCard 能展示 success/running/failed/delayed/unknown 状态。
```

---

# 13. Agent 侧提示词模板

用于智投 Chat 后端或 Agent 服务。

```text
你是智投 Chat 的指标解释 Agent。你需要根据用户问题和指标知识库内容，生成结构化指标解释结果。

你必须遵守：

1. 不要只返回普通文本。
2. 必须优先生成 metric_explainer_v1 UI Schema。
3. 如果用户问“是什么”，优先返回 metric_explain_card、formula_card、faq_card。
4. 如果用户问“怎么算”，优先返回 formula_card、calculation_card、data_source_card。
5. 如果用户问“数据来源”，优先返回 data_source_card、tracking_card、preprocessing_card、lineage_card。
6. 如果用户问“为什么不一致”，优先返回 report_difference_card、metric_difference_card、scheduler_card。
7. 如果用户问“为什么异常”，优先返回 scheduler_card、data_source_card、report_difference_card、lineage_card、action_card。
8. 所有解释必须基于知识库，不能编造不存在的口径。
9. 如果知识库没有明确答案，需要标记 unknown，并给出建议排查路径。
10. 对用户可能误解的地方，优先使用 ambiguity_card 纠正。
```

输出格式：

```json
{
  "ui_schema_version": "metric_explainer_v1",
  "answer_type": "metric_definition",
  "metric_id": "",
  "metric_name": "",
  "summary": "",
  "components": [],
  "sources": [],
  "actions": []
}
```

---

# 14. 指标问题分类提示词

```text
请判断用户的问题属于哪一类指标问题，只输出 JSON。

可选类型：

- metric_definition：问指标是什么
- metric_formula：问指标怎么算
- metric_source：问数据来源
- metric_tracking：问上报/埋点
- metric_preprocessing：问预处理
- metric_calculation：问计算口径
- metric_scheduler：问更新时间/调度
- metric_difference：问报表或口径差异
- metric_diagnosis：问异常原因或排查
- metric_faq：普通常见问题

输出：

{
  "intent": "",
  "metric_candidates": [],
  "systems_mentioned": [],
  "reports_mentioned": [],
  "need_clarification": false,
  "clarification_question": ""
}
```

---

# 15. 知识库补全提示词

用于批量补齐指标文档。

```text
请根据下面的指标名称，生成一份指标知识库 YAML 草稿。

要求：

1. 按 MetricKnowledgeTemplate 结构生成。
2. 不确定的信息标记为 TODO，不要编造。
3. 业务解释要面向游戏广告投放。
4. 必须包含：
   - definition
   - formula
   - data_sources
   - calculation
   - report_differences
   - metric_differences
   - ambiguities
   - faq
   - governance

指标名称：
{{metric_name}}

已知背景：
{{context}}
```

---

# 16. 首日 ROI Mock Schema 示例

```ts
export const roiD1MetricSchema = {
  ui_schema_version: 'metric_explainer_v1',
  answer_type: 'metric_difference',
  metric_id: 'roi_d1',
  metric_name: '首日ROI',
  summary:
    '首日ROI用于衡量用户激活当天的广告收入回收效率。BI 和媒体后台不一致通常来自归因口径、刷新周期和收入口径差异。',
  components: [
    {
      type: 'metric_explain_card',
      props: {
        metricId: 'roi_d1',
        metricName: '首日ROI',
        aliases: ['D1 ROI', '首日回收'],
        category: '投放效果',
        subCategory: '回收指标',
        level: 'core',
        status: 'online',
        shortDefinition: '首日ROI用于衡量用户激活当天的广告收入回收效率。',
        businessMeaning: '用于判断新素材、新计划、新渠道在冷启动阶段的短期回收质量。',
        usageScenarios: ['新广告计划冷启动', '素材初筛', '渠道质量初判'],
        updatedAt: '2026-05-14',
        owner: '广告数据产品'
      }
    },
    {
      type: 'formula_card',
      props: {
        formulaText: '首日ROI = 首日充值收入 / 广告消耗',
        formulaLatex: 'ROI_{D1}=Revenue_{D1}/Cost',
        numerator: {
          name: '首日充值收入',
          description: '归因用户在激活当天产生的充值金额',
          field: 'pay_amount_d1'
        },
        denominator: {
          name: '广告消耗',
          description: '媒体 API 或广告成本表中的消耗金额',
          field: 'cost'
        },
        unit: '%',
        roundRule: '保留两位小数'
      }
    }
  ],
  actions: [
    {
      label: '查看相关报表',
      action: 'open_report',
      params: {
        report_id: 'ad_roi_dashboard'
      }
    },
    {
      label: '启动差异排查',
      action: 'start_diagnosis',
      params: {
        metric_id: 'roi_d1'
      }
    }
  ]
};
```

---

# 17. 代码质量要求

Codex 实现时必须满足：

```text
1. TypeScript 不使用 any，除非确实需要 Record<string, unknown>。
2. 组件 props 来自 schema interface。
3. 不要把 mock 数据写死在组件里。
4. 不要在组件里直接请求接口。
5. Action 统一通过 onAction 回调派发。
6. 复杂组件先做可用版本，不追求炫技。
7. 所有 fallback 文案使用中文。
8. 保持和 Ant Design X Chat 的消息风格一致。
9. 不要引入重型新依赖，除非已有项目使用。
10. README 必须写清楚如何扩展新组件。
```

---

# 18. 验收清单

交付后请确认：

```text
[ ] schema 类型完整
[ ] renderer 可用
[ ] 核心组件可用
[ ] 增强组件可用
[ ] mock 数据完整
[ ] Chat 示例可预览
[ ] unknown component 有 fallback
[ ] Action 能触发
[ ] SQL 可折叠
[ ] 长 FAQ 可折叠
[ ] 移动端不溢出
[ ] README 完整
```
