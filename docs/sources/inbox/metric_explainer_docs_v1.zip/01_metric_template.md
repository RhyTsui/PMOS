# 智投 Chat 指标解释器：知识库模板与治理规范

版本：v1.0  
适用项目：智投 Chat / 广告 BI / 监测管理系统 / PMChat  
建议路径：`docs/metric-explainer/01_metric_template.md`

---

# 1. 设计目标

指标解释器不是简单的“指标口径说明”，而是用于支撑 Chat Agent 回答指标问题的结构化知识资产。

它需要让 Agent 能够回答以下问题：

- 这个指标是什么意思？
- 这个指标怎么算？
- 数据从哪里来？
- 埋点或上报信息是什么？
- 数据经过了哪些预处理？
- 指标什么时候调度更新？
- 为什么不同报表里的值不一样？
- 为什么不同系统里的口径不一样？
- 用户常见误解是什么？
- 出现异常时应该怎么排查？

最终目标是让指标知识库成为：

```text
Chat 可调用
Agent 可推理
组件可渲染
排查可闭环
治理可追溯
```

---

# 2. 指标知识模板总结构

建议每个指标一个 YAML 或 Markdown+YAML 文件。

推荐目录：

```text
knowledge/
└── metrics/
    ├── roi_d1.yaml
    ├── roi_d7.yaml
    ├── cost.yaml
    ├── activation_cost.yaml
    ├── retention_d1.yaml
    └── revenue_ltv.yaml
```

每个指标模板分为 14 层：

```text
1. 基础信息层
2. 指标定义层
3. 公式计算层
4. 数据来源层
5. 上报信息层
6. 预处理信息层
7. 计算信息层
8. 调度信息层
9. 数据血缘层
10. 报表差异层
11. 计算口径差异层
12. 常见歧义层
13. 常见问题层
14. 治理与版本层
```

---

# 3. 标准 YAML 模板

```yaml
metric_id: ""
metric_name: ""
metric_alias: []
category: ""
sub_category: ""
business_domain: ""
metric_level: ""
status: "draft"

definition:
  short: ""
  full: ""
  business_meaning: ""
  usage_scenarios: []
  not_suitable_for: []

formula:
  text: ""
  latex: ""
  numerator:
    name: ""
    description: ""
    field: ""
  denominator:
    name: ""
    description: ""
    field: ""
  aggregation: ""
  unit: ""
  display_format: ""
  round_rule: ""

data_sources:
  - source_name: ""
    source_type: ""
    system: ""
    database: ""
    table: ""
    field: ""
    field_description: ""
    update_frequency: ""
    owner: ""
    reliability: ""

tracking_info:
  event_name: ""
  event_id: ""
  trigger_timing: ""
  trigger_logic: ""
  sdk_or_api: ""
  upload_mode: ""
  upload_timing: ""
  retry_strategy: ""
  dedup_key: ""
  validation_rule: ""
  common_tracking_issues: []

preprocessing:
  timezone_process: ""
  currency_convert: ""
  dedup_rule: ""
  dirty_data_filter: ""
  test_data_filter: ""
  user_merge_rule: ""
  attribution_merge_rule: ""
  null_value_process: ""
  outlier_process: ""

calculation:
  calculation_sql: ""
  calculation_logic: ""
  group_by_dimensions: []
  filter_conditions: []
  attribution_rule: ""
  time_window:
    event_time: ""
    start: ""
    end: ""
    timezone: ""
  example:
    input: ""
    output: ""

scheduler:
  task_name: ""
  task_type: ""
  cron: ""
  dependencies: []
  output_table: ""
  sla: ""
  retry_policy: ""
  delay_policy: ""
  owner: ""
  alert_policy: ""

lineage:
  upstream_systems: []
  upstream_tables: []
  processing_layers: []
  downstream_reports: []
  downstream_apis: []
  downstream_agents: []

report_differences:
  - report_a: ""
    report_b: ""
    difference_type: ""
    reason: ""
    user_explanation: ""
    diagnosis_method: ""

metric_differences:
  - metric_a: ""
    metric_b: ""
    difference_type: ""
    reason: ""
    user_explanation: ""

ambiguities:
  - user_misunderstanding: ""
    actual_meaning: ""
    recommended_answer: ""

faq:
  - question: ""
    answer: ""
    related_components: []
    next_actions: []

governance:
  product_owner: ""
  data_owner: ""
  tech_owner: ""
  approval_status: ""
  version: "v1.0"
  updated_at: ""
  change_log: []
  confidence_level: ""
```

---

# 4. 字段说明

## 4.1 基础信息层

用于 Agent 识别用户问的是哪个指标。

| 字段 | 含义 | 示例 |
|---|---|---|
| metric_id | 指标唯一 ID | roi_d1 |
| metric_name | 指标中文名 | 首日 ROI |
| metric_alias | 别名 | D1 ROI、首日回收 |
| category | 一级分类 | 投放效果 |
| sub_category | 二级分类 | 回收指标 |
| business_domain | 业务域 | 游戏广告投放 |
| metric_level | 指标等级 | 核心指标 |
| status | 状态 | draft / online / deprecated |

---

## 4.2 指标定义层

用于回答“这个指标是什么意思”。

必须包含：

- 一句话定义
- 完整定义
- 业务含义
- 使用场景
- 不适用场景

示例：

```yaml
definition:
  short: "首日 ROI 用于衡量用户激活当天的广告收入回收效率。"
  full: "首日 ROI 表示归因用户在激活当天产生的充值收入，与对应广告消耗之间的比值。"
  business_meaning: "用于判断新素材、新计划、新渠道在冷启动阶段的短期回收质量。"
  usage_scenarios:
    - "新广告计划冷启动"
    - "素材初筛"
    - "渠道质量初判"
  not_suitable_for:
    - "判断长期利润"
    - "替代完整 LTV 分析"
```

---

## 4.3 公式计算层

用于回答“怎么算”。

示例：

```yaml
formula:
  text: "首日ROI = 首日充值收入 / 广告消耗"
  latex: "ROI_{D1}=Revenue_{D1}/Cost"
  numerator:
    name: "首日充值收入"
    description: "归因用户在激活当天产生的充值金额"
    field: "pay_amount_d1"
  denominator:
    name: "广告消耗"
    description: "媒体 API 或消耗表中的广告花费"
    field: "cost"
  aggregation: "SUM(pay_amount_d1) / SUM(cost)"
  unit: "%"
  display_format: "xx.xx%"
  round_rule: "保留两位小数"
```

---

## 4.4 数据来源层

用于回答“数据从哪里来”。

示例：

```yaml
data_sources:
  - source_name: "广告消耗"
    source_type: "媒体 API"
    system: "OceanEngine"
    database: "ads_dw"
    table: "dwd_ads_cost_di"
    field: "cost"
    field_description: "广告消耗金额"
    update_frequency: "hourly"
    owner: "广告数据开发"
    reliability: "high"

  - source_name: "充值订单"
    source_type: "游戏订单系统"
    system: "Pay Center"
    database: "game_dw"
    table: "dwd_pay_order_di"
    field: "pay_amount"
    field_description: "支付成功金额"
    update_frequency: "realtime/hourly"
    owner: "游戏数据开发"
    reliability: "high"
```

---

## 4.5 上报信息层

用于回答“原始数据是怎么产生的”。

适合解释：

- 激活
- 注册
- 登录
- 充值
- 付费成功
- 关键行为事件
- 媒体回传事件

示例：

```yaml
tracking_info:
  event_name: "pay_success"
  event_id: "10031"
  trigger_timing: "用户支付成功后"
  trigger_logic: "支付系统确认订单成功后触发"
  sdk_or_api: "Game SDK / Server API"
  upload_mode: "服务端上报"
  upload_timing: "实时"
  retry_strategy: "失败后最多重试 3 次"
  dedup_key: "order_id"
  validation_rule: "order_id、user_id、pay_amount 不允许为空"
  common_tracking_issues:
    - "客户端重复上报"
    - "服务端延迟上报"
    - "测试订单未过滤"
    - "订单状态变更后未同步"
```

---

## 4.6 预处理信息层

用于回答“数据如何被加工”。

示例：

```yaml
preprocessing:
  timezone_process: "UTC 转北京时间"
  currency_convert: "按订单支付币种转换为 CNY"
  dedup_rule: "按 order_id 去重"
  dirty_data_filter: "过滤金额小于等于 0 的异常订单"
  test_data_filter: "过滤测试账号、测试区服、内部白名单设备"
  user_merge_rule: "按内部 user_id 合并同一用户"
  attribution_merge_rule: "按归因 click_id / install_id 关联广告来源"
  null_value_process: "缺失 campaign_id 归为 unknown"
  outlier_process: "超大金额订单进入异常审核队列"
```

---

## 4.7 计算信息层

用于回答“指标怎么聚合”。

示例：

```yaml
calculation:
  calculation_sql: |
    SELECT
      dt,
      project_id,
      media,
      SUM(pay_amount_d1) / SUM(cost) AS roi_d1
    FROM ads_metric_wide_di
    GROUP BY dt, project_id, media

  calculation_logic: "按日期、项目、媒体聚合后，用首日充值收入总和除以广告消耗总和"
  group_by_dimensions:
    - "日期"
    - "项目"
    - "媒体"
    - "campaign"
    - "creative"
  filter_conditions:
    - "只统计有效归因用户"
    - "排除测试账号"
    - "排除无效订单"
  attribution_rule: "内部混合归因"
  time_window:
    event_time: "激活时间"
    start: "激活当日 00:00:00"
    end: "激活当日 23:59:59"
    timezone: "北京时间"
  example:
    input: "首日充值收入 10000，广告消耗 50000"
    output: "首日 ROI = 20%"
```

---

## 4.8 调度信息层

用于回答“数据什么时候更新”。

示例：

```yaml
scheduler:
  task_name: "ads_roi_d1_task"
  task_type: "hourly batch"
  cron: "0 * * * *"
  dependencies:
    - "ads_cost_sync"
    - "install_attribution_sync"
    - "pay_order_sync"
  output_table: "ads_metric_wide_di"
  sla: "T+1 08:00 前完成昨日全量刷新"
  retry_policy: "失败后自动重试 3 次，每次间隔 10 分钟"
  delay_policy: "上游未完成时进入等待状态，超过 SLA 后告警"
  owner: "广告数据开发"
  alert_policy: "任务失败或延迟超过 30 分钟发送飞书告警"
```

---

## 4.9 报表差异层

用于回答“为什么不同报表不一致”。

典型差异来源：

```text
1. 数据更新时间不同
2. 归因口径不同
3. 过滤条件不同
4. 维度聚合方式不同
5. 时区不同
6. 是否包含退款/补单
7. 是否包含回刷数据
8. 实时表与离线表不一致
```

示例：

```yaml
report_differences:
  - report_a: "广告 BI ROI 日报"
    report_b: "媒体后台"
    difference_type: "归因口径差异"
    reason: "广告 BI 使用内部混合归因，媒体后台使用媒体自归因。"
    user_explanation: "两个系统看到的用户归属规则不同，所以 ROI 不会完全一致。"
    diagnosis_method: "优先对比激活数、消耗、充值收入三个基础指标。"

  - report_a: "实时 ROI 看板"
    report_b: "离线 ROI 日报"
    difference_type: "刷新周期差异"
    reason: "实时看板未包含退款、补单和完整归因回刷。"
    user_explanation: "实时看板用于趋势观察，离线日报用于正式复盘。"
    diagnosis_method: "查看任务调度状态和最近一次离线刷新时间。"
```

---

## 4.10 计算口径差异层

用于回答“为什么同名指标不一样”。

示例：

```yaml
metric_differences:
  - metric_a: "首日 ROI"
    metric_b: "首周 ROI"
    difference_type: "收入窗口不同"
    reason: "首日 ROI 只统计激活当天收入，首周 ROI 统计激活后 7 日累计收入。"
    user_explanation: "首日 ROI 看短期回收，首周 ROI 更适合看早期留存和付费质量。"

  - metric_a: "2-30 日 ROI"
    metric_b: "首月 ROI"
    difference_type: "是否包含首日收入"
    reason: "2-30 日 ROI 不包含首日收入，首月 ROI 通常包含首日到第 30 日收入。"
    user_explanation: "2-30 日 ROI 更适合观察首日之后的持续付费能力。"
```

---

## 4.11 常见歧义层

用于帮助 Agent 纠正用户误解。

示例：

```yaml
ambiguities:
  - user_misunderstanding: "ROI 超过 100% 就代表项目赚钱"
    actual_meaning: "ROI 超过 100% 只表示收入超过广告消耗，不代表扣除渠道分成、税费、人力、服务器成本后整体盈利。"
    recommended_answer: "ROI 是投放回收指标，不等同于项目利润率。"

  - user_misunderstanding: "媒体后台数据一定最准"
    actual_meaning: "媒体后台只掌握媒体侧归因和消耗，不一定掌握完整游戏内订单、退款、补单和内部归因逻辑。"
    recommended_answer: "媒体后台适合看媒体侧优化效果，内部 BI 适合看公司统一口径。"
```

---

## 4.12 FAQ 层

用于 Agent 生成自然语言问答。

示例：

```yaml
faq:
  - question: "为什么今天首日 ROI 突然下降？"
    answer: "常见原因包括消耗已更新但充值尚未完全同步、归因数据延迟、某些渠道成本突增、或新素材质量下降。建议先查看消耗、激活、首日收入三个基础指标是否同步波动。"
    related_components:
      - "difference_card"
      - "scheduler_card"
      - "lineage_card"
    next_actions:
      - "查看调度状态"
      - "查看分媒体 ROI"
      - "启动数据差异排查"

  - question: "为什么 BI 的 ROI 比媒体后台低？"
    answer: "通常是归因口径、收入口径或时区口径不同导致。媒体后台一般采用媒体自归因，内部 BI 通常使用统一混合归因，并结合游戏订单数据计算收入。"
    related_components:
      - "report_difference_card"
      - "metric_rule_card"
    next_actions:
      - "查看口径对比"
      - "查看归因差异"
```

---

# 5. 智投 Chat 推荐指标模板文件结构

```text
knowledge/metrics/
├── README.md
├── categories.yaml
├── roi/
│   ├── roi_d1.yaml
│   ├── roi_d7.yaml
│   ├── roi_d30.yaml
│   └── roi_2_30.yaml
├── cost/
│   ├── cost.yaml
│   ├── cpi.yaml
│   ├── cpa.yaml
│   └── activation_cost.yaml
├── attribution/
│   ├── activation.yaml
│   ├── registration.yaml
│   └── attributed_pay.yaml
└── retention/
    ├── retention_d1.yaml
    ├── retention_d7.yaml
    └── retention_d30.yaml
```

---

# 6. Agent 检索策略

指标问题进入 Chat 后，建议按以下顺序检索：

```text
1. 指标名称精确匹配
2. 指标别名匹配
3. 业务域 + 分类匹配
4. FAQ 相似问题匹配
5. 常见歧义匹配
6. 报表差异匹配
7. 口径差异匹配
```

推荐召回内容：

```text
metric.definition
metric.formula
metric.data_sources
metric.calculation
metric.report_differences
metric.metric_differences
metric.ambiguities
metric.faq
```

---

# 7. 回答质量要求

Agent 回答指标问题时必须满足：

```text
1. 不只给定义，还要给口径。
2. 涉及差异时，必须说明差异来源。
3. 涉及异常时，必须给排查路径。
4. 涉及报表时，必须说明报表口径。
5. 涉及时间窗口时，必须说明时区和统计窗口。
6. 涉及金额时，必须说明币种和汇率处理。
7. 涉及归因时，必须说明归因规则。
8. 涉及调度时，必须说明数据更新时间。
```

---

# 8. 最小可用版本

第一阶段只要求每个指标补齐以下字段：

```yaml
metric_id:
metric_name:
metric_alias:
definition:
formula:
data_sources:
calculation:
report_differences:
metric_differences:
faq:
governance:
```

这样即可支撑 80% 的指标解释问答。

---

# 9. 后续增强版本

第二阶段补齐：

```yaml
tracking_info:
preprocessing:
scheduler:
lineage:
ambiguities:
```

第三阶段接入：

```text
真实血缘系统
调度系统
报表元数据
SQL 元数据
数据质量监控
归因诊断服务
```
