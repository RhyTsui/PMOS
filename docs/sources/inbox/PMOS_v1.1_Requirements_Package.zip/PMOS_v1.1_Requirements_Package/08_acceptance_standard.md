# 08. PMOS v1.1 Studio Edition 验收标准

## 1. 产品级验收原则

v1.1 不按“页面是否存在”验收，而按“主链是否跑通”验收。

主链：

```text
Original Demand
→ Requirement
→ PageSpec
→ CodexJob
→ Code Diff
→ Preview
→ Browser Verification
→ Review Gate
→ Proof-of-Work
→ Version Writeback
```

## 2. 必须满足

### 2.1 Copilot-first

用户打开 PMOS Studio 后，默认能通过 Copilot 输入目标，而不是必须先理解模块菜单。

验收：

```text
用户输入“做一个页面”
系统能路由到 BuilderAgent
系统能生成 Dynamic Surface
```

### 2.2 Agent Router

必须支持至少以下路由：

```text
IntakeAgent
BuilderAgent
CodexAgent
VerifierAgent
EvidenceAgent
WorkflowAgent
KnowledgeAgent
RuntimeAgent
```

验收：

```text
每次路由有 selectedAgent、reason、nextSafeStep、targetEntityType
```

### 2.3 PageSpec

必须能从需求创建 PageSpec。

验收：

```text
PageSpec 包含目标、页面类型、组件需求、数据需求、API 需求、验收条件、coding instructions
```

### 2.4 CodexJob

必须能从 PageSpec 创建 CodexJob。

验收：

```text
CodexJob 有状态机
CodexJob 有 workingDirectory
CodexJob 有 allowedPaths
CodexJob 有 verificationCommands
CodexJob 有 events/logs
```

### 2.5 状态机

CodexJob 必须支持：

```text
draft
queued
running
awaiting_approval
verifying
completed
failed
cancelled
rework_required
```

### 2.6 执行边界

必须满足：

```text
前端不能直接 shell
前端不能直接调用 Codex CLI
CLI 执行必须通过 Runtime
所有执行必须绑定 jobId
```

### 2.7 验证和证据

completed 必须满足：

```text
有 diff 或 no-op reason
有 verification report
有 proof-of-work
有 approval 或 review decision
```

### 2.8 Runtime 状态

必须能查看：

```text
Codex local state
Connector status
Provider / MCP 状态
active jobs
failed jobs
drift reasons
```

## 3. 验收命令

必须通过：

```bash
npm run lint
npm run build
npm run test
npm run verify:frontend-browser
npm start
```

## 4. 文档验收

必须更新：

```text
README.md
CHANGELOG.md
docs/operations/current-version-progress.md
docs/operations/pmaios-v1.1-studio-direction.md
docs/operations/pmaios-v1.1-design-constitution.md
docs/operations/v1.1-acceptance-standard.md
docs/operations/codex-execution-boundary.md
```

## 5. 不通过条件

任一情况成立，则 v1.1 不通过：

```text
1. 用户仍必须进入命令行才能创建主链任务
2. 前端直接 shell
3. Codex 执行没有状态机
4. Codex 执行没有 events/logs
5. completed 没有 proof
6. coding 交付没有 verification
7. Dynamic Surface 没有绑定 PMOS 实体
8. Agent Router 不能解释路由原因
9. mock 数据散落在 UI 层
10. 文档和代码版本口径不一致
```

## 6. 最小可接受版本

v1.1 最小可接受版本允许真实 Codex 执行仍为 mock-first，但必须：

```text
1. 主链完整
2. 状态机完整
3. API skeleton 完整
4. Dynamic Surface 可用
5. CodexJob 可 mock 执行
6. proof / verification 可 mock 生成
7. 后续接真实 CLI 的边界已固定
```
