# 04. 核心实体与状态机

## 1. 核心实体

v1.1 必须围绕以下实体设计：

```text
Requirement
PageSpec
CodexJob
CodexJobEvent
CodexJobArtifact
VerificationReport
ProofOfWorkBundle
ReviewDecision
VersionEntry
AgentRoute
DynamicSurface
StudioSession
```

## 2. PageSpec

```ts
type PageSpecStatus =
  | 'draft'
  | 'ready'
  | 'linked_to_codex_job'
  | 'implemented'
  | 'archived';

type PageSpec = {
  id: string;
  title: string;
  status: PageSpecStatus;
  subprojectId: string | null;
  linkedRequirementIds: string[];
  route: string | null;
  userGoal: string;
  pageType:
    | 'dashboard'
    | 'form'
    | 'detail'
    | 'workflow'
    | 'review'
    | 'admin'
    | 'copilot-surface';
  layoutRegions: Array<{
    id: string;
    name: string;
    purpose: string;
    priority: 'P0' | 'P1' | 'P2';
  }>;
  componentRequirements: Array<{
    id: string;
    name: string;
    purpose: string;
    dataDependencies: string[];
  }>;
  dataRequirements: Array<{
    id: string;
    name: string;
    source: 'existing-api' | 'new-api' | 'mock' | 'runtime-state';
    endpoint?: string;
    fields: string[];
  }>;
  apiRequirements: Array<{
    id: string;
    method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
    path: string;
    purpose: string;
    requestSchema?: unknown;
    responseSchema?: unknown;
  }>;
  acceptanceCriteria: string[];
  codingInstructions: string[];
  createdAt: string;
  updatedAt: string;
};
```

## 3. CodexJob

```ts
type CodexJobStatus =
  | 'draft'
  | 'queued'
  | 'running'
  | 'awaiting_approval'
  | 'verifying'
  | 'completed'
  | 'failed'
  | 'cancelled'
  | 'rework_required';

type CodexJobMode =
  | 'plan-only'
  | 'edit'
  | 'full-auto-sandbox';

type CodexJob = {
  id: string;
  title: string;
  status: CodexJobStatus;
  mode: CodexJobMode;
  subprojectId: string | null;
  requirementIds: string[];
  pageSpecId: string | null;
  workflowRunId: string | null;
  taskId: string | null;
  workingDirectory: string;
  allowedPaths: string[];
  blockedPaths: string[];
  branchName: string | null;
  prompt: string;
  executionPlan: string[];
  verificationCommands: string[];
  previewUrl: string | null;
  diffSummary: string | null;
  proofOfWorkBundleId: string | null;
  riskLevel: 'L1' | 'L2' | 'L3' | 'L4';
  requiresHumanApproval: boolean;
  createdAt: string;
  updatedAt: string;
  startedAt: string | null;
  completedAt: string | null;
  failedReason: string | null;
};
```

## 4. CodexJobEvent

```ts
type CodexJobEventKind =
  | 'job_created'
  | 'job_queued'
  | 'job_started'
  | 'prompt_prepared'
  | 'codex_invoked'
  | 'stdout'
  | 'stderr'
  | 'file_changed'
  | 'diff_captured'
  | 'command_started'
  | 'command_completed'
  | 'verification_started'
  | 'verification_completed'
  | 'approval_requested'
  | 'approved'
  | 'rework_requested'
  | 'job_completed'
  | 'job_failed'
  | 'job_cancelled';

type CodexJobEvent = {
  id: string;
  jobId: string;
  kind: CodexJobEventKind;
  status: 'ok' | 'warning' | 'error';
  timestamp: string;
  message: string;
  artifactRefs: string[];
  metadata: Record<string, unknown>;
};
```

## 5. CodexJobArtifact

```ts
type CodexJobArtifact = {
  id: string;
  jobId: string;
  kind:
    | 'log'
    | 'diff'
    | 'preview'
    | 'verification-report'
    | 'proof-of-work'
    | 'source-file'
    | 'screenshot';
  path: string;
  title: string;
  createdAt: string;
};
```

## 6. CodexJob 状态机

```text
draft
  ↓ submit
queued
  ↓ start
running
  ↓ require approval
awaiting_approval
  ↓ approve
verifying
  ↓ verification pass
completed

running
  ↓ fail
failed

verifying
  ↓ verification fail
rework_required

any active state
  ↓ cancel
cancelled
```

## 7. 状态机规则

### draft

允许：

```text
编辑 prompt
编辑工作目录
编辑 allowedPaths
编辑 verificationCommands
提交 queued
```

禁止：

```text
执行 CLI
标记 completed
生成 proof
```

### queued

允许：

```text
开始执行
取消
```

### running

允许：

```text
记录日志
记录事件
捕获文件变更
捕获 diff
取消
```

禁止：

```text
无验证直接 completed
```

### awaiting_approval

允许：

```text
用户 approve
用户 reject
用户 request rework
```

### verifying

允许：

```text
运行 build
运行 test
运行 browser verification
生成 verification report
```

### completed

必须满足：

```text
有 diff 或明确 no-op 说明
有 verification report
有 proof-of-work
有 review 或 human approval
```

### rework_required

必须提供：

```text
失败原因
需要返工的 PageSpec / Requirement / CodexJob 引用
next safe step
```

## 8. StudioSession

```ts
type StudioSession = {
  id: string;
  title: string;
  subprojectId: string | null;
  activeAgentId: string | null;
  activeSurfaceId: string | null;
  linkedEntityRefs: Array<{
    entityType: string;
    entityId: string;
  }>;
  createdAt: string;
  updatedAt: string;
};
```

## 9. StudioOverview

```ts
type StudioOverview = {
  generatedAt: string;
  selectedSubprojectId: string | null;
  activeMainlineTaskId: string | null;
  activeMainlineLabel: string | null;
  nextSafeStep: string | null;
  activeAgentId: string | null;
  activeSurface: DynamicSurfaceDescriptor | null;
  schedulerSummary: {
    running: number;
    paused: number;
    blocked: number;
    completed: number;
  };
  proofSummary: {
    ready: number;
    rework: number;
    blocked: number;
  };
  codexSummary: {
    aligned: boolean;
    activeJobs: number;
    failedJobs: number;
    driftReasons: string[];
  };
  connectorSummary: {
    configured: number;
    connected: number;
    blocked: number;
  };
};
```
