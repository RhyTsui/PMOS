# 00. PMOS v1.1 Studio Edition 总览

## 1. 背景

PMOS v1.0 已经完成独立产品仓、基础运行时、真源文档、Workflow、Task SSOT、Proof-of-Work、Review、Knowledge Connector、Codex Local State 等基础能力。

但当前系统仍存在核心产品瓶颈：

```text
有 Runtime
有 CLI
有 API
有文档
但缺少真正的用户操作入口
```

用户要推进一个产品交付任务时，仍然容易回到命令行、文件系统、分散 API 和人工上下文拼接。

v1.1 的目标不是“增加几个页面”，而是把 PMOS 从本地运行时升级为可被用户操作的 AI Product Operating System。

## 2. v1.1 一句话目标

```text
让用户不用直接进入命令行，也能通过 PMOS Copilot 把一个产品需求推进到可预览、可验证、可评审、可沉淀的代码交付状态。
```

## 3. 产品定位

PMOS v1.1 不做通用 Coze，不做普通 AI Studio，不做普通 Dashboard。

它的定位是：

```text
产品交付型 AI Studio / AI Product Operating System 用户桌面
```

核心场景：

```text
产品需求
→ 页面规格
→ 受控 Coding Job
→ 本地代码修改
→ 预览
→ 浏览器验证
→ 评审
→ 证据链
→ 版本沉淀
```

## 4. 核心架构

```text
用户
 ↓
PMOS Studio / PMOS Copilot
 ↓
Agent Router
 ↓
Dynamic Work Surface
 ↓
PMOS Runtime Gateway
 ↓
Task SSOT / Workflow / Proof / Review / Knowledge
 ↓
Codex Execution Gateway
 ↓
Codex CLI / Git / npm / Playwright
```

## 5. v1.1 必须回答的问题

1. 用户如何从一句需求进入 PMOS？
2. 用户如何不看命令行也能启动产品交付任务？
3. PMOS 如何把需求转成 PageSpec？
4. PMOS 如何创建受控 CodexJob？
5. Codex 执行过程如何被日志、状态机、diff 和验证追踪？
6. 什么条件下任务可以算 completed？
7. Proof-of-Work 如何生成并回写？
8. v1.1 如何为后续桌面客户端、Coze 集成、Workflow Canvas 留扩展空间？

## 6. v1.1 成功标志

v1.1 成功后，用户应该能完成：

```text
1. 打开 PMOS Studio / Copilot
2. 输入产品需求
3. 系统动态路由到合适 Agent
4. 生成 PageSpec
5. 确认后创建 CodexJob
6. 查看执行状态和日志
7. 查看 diff / preview / browser verification
8. 发起 review 或 rework
9. 查看 Proof-of-Work
10. 写入版本记录
```

## 7. v1.1 不做什么

v1.1 不追求：

```text
完整 Coze 复制
完整 AI Studio 复制
完整桌面客户端
完整 Workflow 拖拽编辑器
完整多租户 SaaS
完整权限系统
完整插件市场
完整 Agent 商店
```

v1.1 只打穿一条主链：

```text
Original Demand → PageSpec → CodexJob → Verify → Proof → Version
```
