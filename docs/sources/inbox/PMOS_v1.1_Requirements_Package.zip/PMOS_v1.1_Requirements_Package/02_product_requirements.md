# 02. PMOS v1.1 Studio Edition 产品需求文档

## 1. 版本定义

```text
Product Version: PMOS v1.1 Studio Edition
Runtime Baseline: v0.8+
Package Version Target: 1.1.0
Frontend Mode: Copilot-first Web Studio
Future Packaging: Desktop Shell in v1.1.1
```

## 2. 用户角色

### 2.1 Product Chief

负责定义产品方向、确认 PageSpec、审批 Review Gate 和版本写入。

### 2.2 Project PM

负责把原始需求推进到结构化 Requirement、PageSpec 和 workflow task。

### 2.3 Designer / UX

负责补充页面意图、交互约束、信息架构和验收条件。

### 2.4 Developer

负责查看 CodexJob 结果、diff、测试结果和技术风险。

### 2.5 Reviewer / QA

负责验证 Browser Verification、Proof-of-Work 和 Review 结论。

### 2.6 Runtime Operator

负责检查 Codex、MCP、Provider、Connector、环境变量和系统健康。

## 3. 核心使用场景

### 3.1 从需求创建页面规格

用户输入：

```text
做一个 PMOS v1.1 Builder 页面，支持从需求生成 PageSpec，并创建 CodexJob。
```

系统行为：

```text
1. Agent Router 判断意图属于 BuilderAgent
2. 系统生成 PageSpec 草稿
3. 用户确认页面目标、数据需求、组件需求和验收条件
4. PageSpec 进入 ready 状态
```

### 3.2 从 PageSpec 创建 CodexJob

系统行为：

```text
1. 用户确认 PageSpec
2. Runtime 创建 CodexJob draft
3. 用户确认工作目录、允许修改范围、执行模式和验证命令
4. CodexJob 进入 queued / running 状态
```

### 3.3 Codex 执行代码任务

系统行为：

```text
1. CodexExecutionService 调用 Codex CLI
2. 系统记录 stdout / stderr
3. 系统记录 job events
4. 系统捕获 git diff
5. 系统触发 build / test / browser verification
```

### 3.4 验证与证据链

系统行为：

```text
1. Browser Verification 生成报告
2. Proof-of-Work 生成 bundle
3. Review Gate 判断 pass / conditional / reject
4. 用户 approve / rework
5. 结果写入 Version Governance
```

## 4. 功能需求

### 4.1 PMOS Copilot

PMOS Copilot 是 v1.1 的默认入口。

必须支持：

```text
1. 输入自然语言目标
2. 附加文档、截图、上下文文件
3. 展示 Agent Router 的路由结果
4. 展示当前任务状态
5. 展示下一步安全动作
6. 发起确认、重试、返工、写入版本等动作
```

不要求包含具体视觉设计。

### 4.2 Agent Router

Agent Router 负责把用户意图路由到合适 Agent 和 Runtime 功能。

必须支持路由到：

```text
IntakeAgent
BuilderAgent
CodexAgent
VerifierAgent
EvidenceAgent
WorkflowAgent
KnowledgeAgent
RuntimeAgent
```

每次路由必须记录：

```text
userIntent
selectedAgent
reason
targetEntityType
targetEntityId
nextAction
createdAt
```

### 4.3 Dynamic Work Surface

Dynamic Work Surface 是 Agent 根据任务动态打开的结构化交互面。

它不是固定页面，也不是平铺 Dashboard。

必须支持：

```text
1. 展示结构化实体，例如 PageSpec、CodexJob、Proof
2. 支持用户编辑关键字段
3. 支持确认 / 取消 / 重试 / 返工
4. 支持将确认动作提交给 Runtime
5. 支持显示当前 Surface 与主链的关系
```

### 4.4 Product Intake

Product Intake 负责把原始输入转成 Requirement。

必须支持：

```text
1. 接收手动输入
2. 接收附件或外部来源引用
3. 生成 Requirement 草稿
4. 提取目标用户、场景、痛点、验收条件
5. 绑定 subproject
6. 转入 Builder 或 Workflow
```

### 4.5 PageSpec Builder

PageSpec Builder 负责把 Requirement 或用户目标转成页面规格。

PageSpec 至少包括：

```text
title
route
userGoal
pageType
layoutRegions
componentRequirements
dataRequirements
apiRequirements
acceptanceCriteria
codingInstructions
linkedRequirementIds
linkedSubprojectId
```

### 4.6 CodexJob Console

CodexJob Console 负责管理受控 coding 任务。

必须支持：

```text
1. 创建 CodexJob draft
2. 展示工作目录
3. 展示允许修改范围
4. 展示执行模式
5. 展示状态机
6. 展示执行日志
7. 展示 diff
8. 展示 preview
9. 展示 verification
10. 支持 approve / rework / cancel
```

### 4.7 Verification

必须支持：

```text
1. 运行 build / test
2. 运行 browser verification
3. 生成 verification report
4. 将结果关联 CodexJob 和 Proof
```

### 4.8 Proof-of-Work

必须支持：

```text
1. 生成 proof bundle
2. 汇总 diff、preview、verification、review、artifact paths
3. 给出 ready / rework / blocked 结论
4. 允许用户 approve / rework
5. 写入 version entry
```

### 4.9 Runtime Admin

Runtime Admin 只作为技术运维入口，不作为默认用户入口。

必须支持：

```text
1. Codex local state
2. Skills / Plugins
3. Providers
4. MCP Registry
5. Connector status
6. Environment check
7. Build / test / verification status
```

## 5. 非功能需求

### 5.1 可审计

所有 Codex 执行必须有：

```text
job id
events
logs
diff summary
verification result
proof link
```

### 5.2 可回放

关键状态必须能从 Task SSOT / CodexJob / Proof 恢复。

### 5.3 可扩展

v1.1 必须为后续支持以下能力预留：

```text
Desktop Shell
Coze Plugin
Gemini CLI Executor
Workflow Canvas
Team Collaboration
Cloud latest-state
```

### 5.4 安全

```text
前端不得直接 shell
执行目录必须受控
允许修改范围必须明确
敏感配置不得进入公开输出
CLI 执行必须经过 Runtime Gateway
```
