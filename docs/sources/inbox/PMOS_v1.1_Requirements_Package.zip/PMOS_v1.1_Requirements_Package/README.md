# PMOS v1.1 Studio Edition 需求包

版本：`v1.1 Studio Edition`  
用途：交给 CLI / Codex / 开发执行，用于实现 PMOS v1.1 的产品化升级。  
范围：本需求包只定义产品目标、系统边界、主流程、Agent 动态路由、数据模型、API、实施计划与验收标准。  
不包含：UI 视觉设计、页面视觉稿、具体配色、组件视觉排版、最终界面细节。

## 一句话定义

PMOS v1.1 Studio Edition 是 PMOS 从本地 Runtime / CLI 系统升级为“可被用户操作的 AI Product Operating System”的关键版本。

核心关系：

```text
PMOS Studio = 用户桌面 / Copilot 入口
PMOS Runtime = OS 核心 / 状态与治理层
Codex CLI = 受控执行器
Task SSOT = 系统状态真源
Proof-of-Work = 交付证据
Review Gate = 质量门禁
Version Governance = 产品记忆
```

## 固定主链

```text
Original Demand
→ Requirement
→ PageSpec
→ CodexJob
→ Code Diff
→ Preview
→ Browser Verification
→ Review Gate
→ Proof-of-Work
→ Version Writeback
```

v1.1 的所有功能、接口、状态和前端交互都必须服务这条主链。

## 文件说明

| 文件 | 说明 |
|---|---|
| `00_executive_summary.md` | v1.1 总览、必要性、价值与边界 |
| `01_design_constitution.md` | 设计宪法：禁止跑偏的硬约束 |
| `02_product_requirements.md` | 完整 PRD，不含 UI 视觉设计 |
| `03_agent_dynamic_routing.md` | Agent 动态路由与 Copilot-first 交互需求 |
| `04_domain_model_and_state_machine.md` | 核心实体、状态机、数据模型 |
| `05_api_requirements.md` | 后端 API 需求与服务拆分 |
| `06_codex_execution_gateway.md` | Codex 受控执行网关需求 |
| `07_implementation_plan.md` | 分阶段实施计划 |
| `08_acceptance_standard.md` | v1.1 验收标准 |
| `09_cli_execution_prompt.md` | 可直接贴给 CLI / Codex 的实施指令 |
| `10_non_goals_and_risks.md` | 非目标、风险与防跑偏规则 |

## 推荐执行顺序

```text
1. 阅读 00 / 01 / 02
2. 冻结 03 / 04 / 05 的实体与接口
3. 按 07 分阶段实施
4. 每阶段按 08 验收
5. 使用 09 作为 CLI 总控提示词
```
