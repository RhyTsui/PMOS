# 03. Agent 动态路由需求

## 1. 核心原则

v1.1 前端不是平铺页面，而是：

```text
Copilot-first
Agent Dynamic Routing
Dynamic Work Surface
```

用户不需要先选择模块。用户只需要表达目标，系统自动判断应该进入哪个 Agent 和哪种工作面。

## 2. Agent Router 职责

Agent Router 负责：

```text
1. 分析用户意图
2. 判断当前任务阶段
3. 选择目标 Agent
4. 创建或打开对应 PMOS 实体
5. 返回 Dynamic Work Surface 配置
6. 提供 Next Safe Step
```

## 3. Agent 列表

### 3.1 IntakeAgent

职责：

```text
原始需求 → Requirement
```

输入：

```text
自然语言需求
会议纪要
文档片段
附件
外部系统引用
```

输出：

```text
RequirementDraft
clarificationQuestions
sourceRefs
nextAction
```

### 3.2 BuilderAgent

职责：

```text
Requirement / user goal → PageSpec
```

输出：

```text
PageSpecDraft
componentRequirements
apiRequirements
acceptanceCriteria
codingInstructions
```

### 3.3 CodexAgent

职责：

```text
PageSpec → CodexJob
```

输出：

```text
CodexJobDraft
executionScope
allowedPaths
verificationCommands
riskLevel
```

### 3.4 VerifierAgent

职责：

```text
CodexJob result → VerificationReport
```

输出：

```text
buildStatus
testStatus
browserVerificationReport
blockingIssues
```

### 3.5 EvidenceAgent

职责：

```text
Verification + Review → Proof-of-Work
```

输出：

```text
ProofOfWorkBundle
acceptancePackage
missingEvidence
handoffSummary
```

### 3.6 WorkflowAgent

职责：

```text
WorkflowRun / Task SSOT → resume / rework / gate action
```

输出：

```text
currentStage
gateStatus
nextSafeStep
operatorEntries
```

### 3.7 KnowledgeAgent

职责：

```text
查询真源、知识库、上下文和 grounding 状态
```

输出：

```text
truthSourceRefs
retrievalResults
groundingStatus
contextForCodex
```

### 3.8 RuntimeAgent

职责：

```text
检查系统状态、Codex、MCP、Provider、Connector
```

输出：

```text
runtimeHealth
codexLocalState
connectorStatus
driftStatus
repairActions
```

## 4. 路由请求

```ts
type AgentRouteRequest = {
  sessionId: string;
  userInput: string;
  currentSubprojectId: string | null;
  currentTaskId: string | null;
  currentEntityRefs: Array<{
    entityType: string;
    entityId: string;
  }>;
  attachments: Array<{
    id: string;
    name: string;
    mimeType: string;
    sourcePath?: string;
  }>;
};
```

## 5. 路由响应

```ts
type AgentRouteResponse = {
  routeId: string;
  selectedAgentId:
    | 'intake-agent'
    | 'builder-agent'
    | 'codex-agent'
    | 'verifier-agent'
    | 'evidence-agent'
    | 'workflow-agent'
    | 'knowledge-agent'
    | 'runtime-agent';
  confidence: number;
  reason: string;
  targetEntityType:
    | 'requirement'
    | 'page-spec'
    | 'codex-job'
    | 'verification-report'
    | 'proof-of-work'
    | 'workflow-run'
    | 'knowledge-query'
    | 'runtime-check';
  targetEntityId: string | null;
  dynamicSurface: DynamicSurfaceDescriptor;
  nextSafeStep: string;
  blockedReason: string | null;
};
```

## 6. Dynamic Surface Descriptor

```ts
type DynamicSurfaceDescriptor = {
  id: string;
  type:
    | 'requirement-intake'
    | 'page-spec-builder'
    | 'codex-job-console'
    | 'verification-report'
    | 'proof-viewer'
    | 'workflow-operator'
    | 'knowledge-search'
    | 'runtime-inspector';
  title: string;
  entityType: string;
  entityId: string | null;
  mode: 'view' | 'edit' | 'confirm' | 'review';
  requiredUserAction:
    | 'none'
    | 'clarify'
    | 'confirm'
    | 'approve'
    | 'rework'
    | 'cancel'
    | 'writeback';
  payloadRef: string | null;
  actions: Array<{
    id: string;
    label: string;
    kind: 'primary' | 'secondary' | 'danger';
    requiresConfirmation: boolean;
  }>;
};
```

## 7. 路由示例

### 示例 1：创建页面

用户输入：

```text
做一个 v1.1 Builder 页面，能从需求生成 PageSpec。
```

路由：

```text
BuilderAgent
→ page-spec-builder surface
→ 创建 PageSpecDraft
```

### 示例 2：执行代码

用户输入：

```text
按刚才的 PageSpec 让 Codex 写出来。
```

路由：

```text
CodexAgent
→ codex-job-console surface
→ 创建 CodexJobDraft
```

### 示例 3：判断是否可交付

用户输入：

```text
这个任务现在能交付了吗？
```

路由：

```text
EvidenceAgent
→ proof-viewer surface
→ 查看 verification / review / proof
```

## 8. 路由验收标准

1. 用户不需要手动进入固定模块也能推进主链。
2. 路由结果必须解释为什么选择该 Agent。
3. 每次路由必须产生 Next Safe Step。
4. 每个 Dynamic Surface 必须绑定 PMOS 实体。
5. Agent 不能直接执行 Codex，必须通过 Runtime 创建 CodexJob。
