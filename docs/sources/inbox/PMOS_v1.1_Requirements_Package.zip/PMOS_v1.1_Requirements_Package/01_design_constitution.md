# 01. PMOS v1.1 Design Constitution

本文档是 v1.1 实施的硬约束。任何功能、接口、状态、页面或 Agent 能力都必须符合本文档。

## 1. Core Identity

PMOS v1.1 Studio Edition 不是：

```text
普通 Dashboard
普通聊天工具
Coze Clone
AI IDE
文档门户
纯 Workflow 编辑器
纯命令行包装器
```

PMOS v1.1 是：

```text
AI Product Operating System 的用户桌面和 Copilot 入口
```

## 2. 固定分层

```text
PMOS Studio / Copilot = 用户入口
Agent Router = 意图识别与动态路由
Dynamic Work Surface = 按任务动态出现的交互工作面
PMOS Runtime = OS 核心
Task SSOT = 系统状态真源
Codex CLI = 受控执行器
Proof-of-Work = 交付证据
Review Gate = 质量门禁
Version Governance = 产品记忆
```

## 3. 固定主链

```text
Original Demand
→ Requirement
→ PageSpec
→ CodexJob
→ Code Diff
→ Preview
→ Browser Verification
→ Review Gate
→ Proof-of-Work
→ Version Writeback
```

所有 v1.1 功能必须服务这条链路。

## 4. 前端交互原则

v1.1 前端采用：

```text
Copilot-first
Agent Dynamic Routing
Dynamic Work Surface
```

而不是：

```text
平铺式功能后台
全量模块 Dashboard
固定多面板堆叠
```

用户默认面对 Copilot。  
系统根据用户意图动态选择合适 Agent 和交互 Surface。

## 5. 执行边界

禁止前端直接执行 shell。  
禁止前端直接调用 Codex CLI。  
禁止绕过 Runtime 创建本地代码变更。  
禁止无状态的一键执行。  
禁止没有验证和证据的 completed 状态。

正确路径：

```text
Studio / Copilot
→ PMOS Runtime API
→ CodexExecutionService
→ CodexJob
→ Logs / Diff / Preview / Verify
→ Proof-of-Work
```

## 6. 每个功能必须回答的问题

任何新增功能必须回答：

1. 谁使用它？
2. 用户输入是什么？
3. 它创建或更新哪个 PMOS 实体？
4. 它读取哪个 Runtime 状态？
5. 它产生什么证据？
6. 它解锁什么下一步动作？
7. 它如何连接 Proof / Review / Version？
8. 它是否保持 Studio / Runtime / Codex 边界？

如果无法回答，不进入 v1.1。

## 7. 禁止方向

v1.1 禁止：

```text
1. 把 PMOS Studio 做成普通聊天页面
2. 把 PMOS Studio 做成 Coze clone
3. 把前端做成平铺式管理后台
4. 前端直接 shell 执行
5. 直接暴露 Codex CLI 给普通用户
6. 无状态运行 Codex
7. completed 状态没有 proof
8. coding 交付没有 browser verification
9. mock 数据散落在 UI 组件里
10. 新增无法对应 Requirement / PageSpec / Task / Proof 的功能
```

## 8. v1.1 的判断标准

如果用户仍然需要进入命令行才能理解和推进主链，则 v1.1 未完成。

如果用户只看到一堆页面和卡片，但不知道下一步该做什么，则 v1.1 未完成。

如果 Codex 执行没有状态机、日志、diff、验证和 proof，则 v1.1 未完成。

如果系统不能把需求推进到 PageSpec / CodexJob / Verify / Proof，则 v1.1 未完成。
