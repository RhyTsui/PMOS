# 07. v1.1 分阶段实施计划

## Phase 0：真源文档

目标：先锁定定义，不写功能代码。

新增或更新：

```text
docs/operations/pmaios-v1.1-studio-direction.md
docs/operations/pmaios-v1.1-design-constitution.md
docs/operations/pmaios-v1.1-agent-routing.md
docs/operations/codex-execution-boundary.md
docs/operations/v1.1-acceptance-standard.md
docs/operations/current-version-progress.md
README.md
CHANGELOG.md
```

验收：

```text
文档明确说明 v1.1 是 Copilot-first + Agent Dynamic Routing
文档明确说明 Studio / Runtime / Codex 边界
文档明确说明 v1.1 做什么、不做什么
```

## Phase 1：shared schema

目标：先锁实体和状态机。

新增或补齐：

```text
PageSpec
CodexJob
CodexJobEvent
CodexJobArtifact
AgentRoute
DynamicSurfaceDescriptor
StudioSession
StudioOverview
VerificationReport
```

验收：

```text
npm run build 通过
前后端可共同引用类型
状态机明确
```

## Phase 2：后端服务 skeleton

新增：

```text
AgentRouterService
DynamicSurfaceService
BuilderPageSpecService
CodexExecutionService
StudioOverviewService
PreviewService
VerificationService
```

新增 routes：

```text
studioRoutes.ts
builderRoutes.ts
codexRoutes.ts
previewRoutes.ts
verificationRoutes.ts
```

验收：

```text
API 返回结构化 mock 数据
CodexJob 可创建、读取、推进状态
不真实执行 shell
```

## Phase 3：前端 Copilot Shell

目标：实现 Copilot-first 基础结构，不做视觉终稿。

需要实现：

```text
StudioSession
Copilot 输入
Agent Route result
Dynamic Surface 容器
Next Safe Step
```

验收：

```text
用户输入目标后，可以看到路由到哪个 Agent
系统可以打开对应 Dynamic Surface
```

## Phase 4：Agent Router mock-first

实现路由规则：

```text
需求类 → IntakeAgent
页面类 → BuilderAgent
代码执行类 → CodexAgent
验证类 → VerifierAgent
证据类 → EvidenceAgent
工作流类 → WorkflowAgent
知识类 → KnowledgeAgent
系统状态类 → RuntimeAgent
```

验收：

```text
至少 8 类常见输入能路由到正确 Agent
每次路由有 reason 和 nextSafeStep
```

## Phase 5：PageSpec Builder

实现：

```text
从用户输入创建 PageSpec draft
编辑 PageSpec
mark ready
create CodexJob draft
```

验收：

```text
用户可以从一句需求生成 PageSpec
确认后创建 CodexJob draft
```

## Phase 6：CodexJob Console mock-first

实现：

```text
CodexJob 状态机
events
logs
diff mock
preview mock
verification mock
proof mock
approve / rework / cancel
```

验收：

```text
不接真实 Codex CLI，也能跑通：
PageSpec → CodexJob → verifying → proof → completed
```

## Phase 7：真实 Codex 执行接入

实现：

```text
child_process 调用 Codex CLI
stdout / stderr 捕获
git diff 捕获
verificationCommands 执行
artifact 写入
proof 生成
```

验收：

```text
前端不直接 shell
所有执行有 jobId
所有输出有 events/logs/artifacts
失败可进入 rework_required
```

## Phase 8：Evidence / Workflow / Knowledge / Runtime 收口

把现有能力接入 Dynamic Surface：

```text
proof-viewer
workflow-operator
knowledge-search
runtime-inspector
```

验收：

```text
用户能从 Copilot 问：
这个任务能交付了吗？
为什么卡住了？
Codex 状态正常吗？
需要什么证据？
```

## Phase 9：回归与发布

执行：

```bash
npm run lint
npm run build
npm run test
npm run verify:frontend-browser
npm start
```

验收：

```text
/ 可访问
/workspace 可访问
/api/health 200
主链可 mock-first 跑通
无 secrets 泄漏
文档口径一致
```
