# 09. CLI / Codex 实施指令

以下内容可直接复制给 CLI / Codex 作为 v1.1 实施总控提示词。

---

你正在 RhyTsui/PMOS 仓库中实施 PMOS v1.1 Studio Edition。

这不是普通前端改版，不是 Dashboard，不是 Coze clone，也不是 AI IDE。

PMOS v1.1 的核心定义：

```text
PMOS Studio / Copilot = 用户入口
PMOS Runtime = OS 核心
Codex CLI = 受控执行器
Task SSOT = 系统状态真源
Proof-of-Work = 交付证据
Review Gate = 质量门禁
Version Governance = 产品记忆
```

v1.1 固定主链：

```text
Original Demand
→ Requirement
→ PageSpec
→ CodexJob
→ Code Diff
→ Preview
→ Browser Verification
→ Review Gate
→ Proof-of-Work
→ Version Writeback
```

前端交互方向：

```text
Copilot-first
Agent Dynamic Routing
Dynamic Work Surface
```

不要做平铺式功能后台。不要把所有模块一次性展示给用户。用户只表达目标，Agent Router 判断意图并打开对应的 Dynamic Surface。

必须完成：

## 1. 文档

新增或更新：

```text
docs/operations/pmaios-v1.1-studio-direction.md
docs/operations/pmaios-v1.1-design-constitution.md
docs/operations/pmaios-v1.1-agent-routing.md
docs/operations/codex-execution-boundary.md
docs/operations/v1.1-acceptance-standard.md
docs/operations/current-version-progress.md
README.md
CHANGELOG.md
```

## 2. Shared Schema

新增或补齐：

```text
PageSpec
CodexJob
CodexJobEvent
CodexJobArtifact
AgentRoute
DynamicSurfaceDescriptor
StudioSession
StudioOverview
VerificationReport
```

## 3. 后端服务与路由

新增：

```text
src/backend/routes/studioRoutes.ts
src/backend/routes/builderRoutes.ts
src/backend/routes/codexRoutes.ts
src/backend/routes/previewRoutes.ts
src/backend/routes/verificationRoutes.ts

src/backend/services/agentRouterService.ts
src/backend/services/dynamicSurfaceService.ts
src/backend/services/builderPageSpecService.ts
src/backend/services/codexExecutionService.ts
src/backend/services/studioOverviewService.ts
src/backend/services/previewService.ts
src/backend/services/verificationService.ts
```

新增 API：

```text
POST /api/studio/agent-route
GET  /api/studio/overview
GET  /api/studio/surfaces/:surfaceId
POST /api/studio/surfaces/:surfaceId/actions/:actionId

POST /api/builder/page-specs
GET  /api/builder/page-specs
GET  /api/builder/page-specs/:id
PATCH /api/builder/page-specs/:id
POST /api/builder/page-specs/:id/mark-ready
POST /api/builder/page-specs/:id/create-codex-job

POST /api/codex/jobs
GET  /api/codex/jobs
GET  /api/codex/jobs/:id
PATCH /api/codex/jobs/:id
POST /api/codex/jobs/:id/queue
POST /api/codex/jobs/:id/start
POST /api/codex/jobs/:id/cancel
POST /api/codex/jobs/:id/approve
POST /api/codex/jobs/:id/rework
GET  /api/codex/jobs/:id/events
GET  /api/codex/jobs/:id/logs
GET  /api/codex/jobs/:id/diff
GET  /api/codex/jobs/:id/artifacts
POST /api/codex/jobs/:id/run-verification
POST /api/codex/jobs/:id/writeback
```

## 4. 前端结构

实现 Copilot-first 基础结构，不要求完成最终 UI 视觉设计。

需要具备：

```text
Studio Session
Copilot 输入
Agent Route 展示
Dynamic Surface 容器
Next Safe Step
PageSpec Surface
CodexJob Surface
Proof / Verification Surface
Runtime Inspector Surface
```

不要实现固定平铺 Dashboard 作为主入口。

## 5. Codex 执行边界

禁止：

```text
前端直接 shell
前端直接调用 Codex CLI
无状态执行 Codex
没有 verification 直接 completed
没有 proof 直接 writeback
```

必须：

```text
通过 CodexJob
通过 Runtime API
记录 events/logs
捕获 diff
运行 verification
生成 proof
```

## 6. Mock-first

先实现 mock-first：

```text
Agent Router 可路由
PageSpec 可创建
CodexJob 可创建
状态机可推进
events/logs/diff/verification/proof 可 mock
```

真实 Codex CLI 执行放在后续阶段接入，但接口和边界必须先固定。

## 7. 每阶段完成后输出回查表

每次修改完成后输出：

```text
1. 本次服务主链哪一环？
2. 修改了哪些文件？
3. 新增了哪些实体？
4. 新增了哪些 API？
5. 解锁了哪些用户动作？
6. 产生了什么 evidence？
7. 是否改变 Studio / Runtime / Codex 边界？
8. 是否存在前端直接 shell？
9. mock 数据是否集中在 service？
10. lint / build / test 结果？
```

## 8. 验收命令

必须通过：

```bash
npm run lint
npm run build
npm run test
npm run verify:frontend-browser
npm start
```

## 9. 不要做

不要做：

```text
完整 Coze clone
完整 AI Studio clone
完整桌面客户端
完整 workflow 拖拽编辑器
完整权限系统
完整插件市场
完整 Agent 商店
```

v1.1 只需要打穿：

```text
用户目标
→ Agent Router
→ Dynamic Surface
→ PageSpec
→ CodexJob
→ Verify
→ Proof
```
