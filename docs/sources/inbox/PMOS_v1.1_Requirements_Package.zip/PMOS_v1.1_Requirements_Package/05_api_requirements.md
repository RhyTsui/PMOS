# 05. API 与服务需求

## 1. 服务拆分目标

v1.1 后端需要新增或拆分以下服务：

```text
AgentRouterService
DynamicSurfaceService
BuilderPageSpecService
CodexExecutionService
PreviewService
StudioOverviewService
VerificationService
```

## 2. Agent Router API

### POST /api/studio/agent-route

用途：根据用户输入和当前上下文选择 Agent 和 Dynamic Surface。

请求：

```ts
AgentRouteRequest
```

响应：

```ts
AgentRouteResponse
```

## 3. Studio Overview API

### GET /api/studio/overview

用途：返回当前 Studio 运行总览。

Query：

```text
subprojectId?
sessionId?
```

响应：

```ts
StudioOverview
```

## 4. Dynamic Surface API

### GET /api/studio/surfaces/:surfaceId

用途：读取当前 Dynamic Surface 描述与绑定实体。

### POST /api/studio/surfaces/:surfaceId/actions/:actionId

用途：执行 Surface 上的用户动作，例如 confirm / approve / rework / cancel / writeback。

## 5. PageSpec API

### POST /api/builder/page-specs

创建 PageSpec draft。

### GET /api/builder/page-specs

列出 PageSpec。

### GET /api/builder/page-specs/:id

读取 PageSpec。

### PATCH /api/builder/page-specs/:id

更新 PageSpec。

### POST /api/builder/page-specs/:id/mark-ready

将 PageSpec 标记为 ready。

### POST /api/builder/page-specs/:id/create-codex-job

基于 PageSpec 创建 CodexJob draft。

## 6. CodexJob API

### POST /api/codex/jobs

创建 CodexJob draft。

### GET /api/codex/jobs

列出 CodexJob。

### GET /api/codex/jobs/:id

读取 CodexJob。

### PATCH /api/codex/jobs/:id

更新 CodexJob draft。

### POST /api/codex/jobs/:id/queue

提交到 queued。

### POST /api/codex/jobs/:id/start

开始执行。

### POST /api/codex/jobs/:id/cancel

取消执行。

### POST /api/codex/jobs/:id/approve

人工 approve。

### POST /api/codex/jobs/:id/rework

请求返工。

### GET /api/codex/jobs/:id/events

读取事件。

### GET /api/codex/jobs/:id/logs

读取日志。

### GET /api/codex/jobs/:id/diff

读取 diff。

### GET /api/codex/jobs/:id/artifacts

读取 artifacts。

### POST /api/codex/jobs/:id/run-verification

运行验证。

### POST /api/codex/jobs/:id/writeback

写入 proof / version。

## 7. Preview API

### GET /api/preview/status

读取本地 preview 状态。

### POST /api/preview/start

启动或确认 preview 服务。

### GET /api/preview/jobs/:jobId

读取 CodexJob 关联 preview。

## 8. Verification API

### POST /api/verification/jobs/:jobId/run

运行 CodexJob 的 verificationCommands 和 browser verification。

### GET /api/verification/jobs/:jobId/report

读取 VerificationReport。

## 9. Proof API 扩展

### POST /api/proof-of-work/from-codex-job/:jobId

从 CodexJob 生成 ProofOfWorkBundle。

### GET /api/proof-of-work/jobs/:jobId

读取 CodexJob 关联 proof。

## 10. API 规则

所有 API 必须：

```text
1. 返回结构化 JSON
2. 包含 error code
3. 不暴露本地 secrets
4. 不允许前端传入任意 shell command 并直接执行
5. 将执行类动作封装成 Job 状态变更
6. 支持 subprojectId 作用域
7. 关键动作写入 event log
```

## 11. Mock-first 要求

v1.1 初始实施必须先支持 mock-first：

```text
PageSpec 可以创建
CodexJob 可以创建和推进状态
events/logs/diff/verification/proof 可以返回 mock artifact
真实 Codex CLI 执行最后接入
```

目的：

```text
先验证产品主链和状态机
再接入真实执行风险
```
