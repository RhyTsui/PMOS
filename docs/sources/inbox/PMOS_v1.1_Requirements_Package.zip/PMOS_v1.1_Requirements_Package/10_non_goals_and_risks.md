# 10. 非目标、风险与防跑偏规则

## 1. v1.1 非目标

v1.1 不做：

```text
1. 完整 Coze Studio 复制
2. 完整 Google AI Studio 复制
3. 完整桌面客户端
4. 完整 Workflow 拖拽编辑器
5. 多租户 SaaS
6. 完整权限系统
7. 插件市场
8. Agent 商店
9. 外部 Bot 多渠道发布
10. 完整云端协作平台
```

## 2. 主要风险

### 2.1 做成平铺 Dashboard

风险表现：

```text
左侧菜单 + 中间多个卡片 + 右侧状态
所有能力都展示出来
用户不知道下一步
```

防范：

```text
采用 Copilot-first + Agent Dynamic Routing
默认只暴露当前意图需要的 Dynamic Surface
```

### 2.2 做成普通聊天页

风险表现：

```text
只有对话，没有结构化实体
没有 PageSpec / CodexJob / Proof
```

防范：

```text
每个 Agent 输出必须绑定 PMOS entity
每个 Surface 必须有 action 和 nextSafeStep
```

### 2.3 Codex 失控

风险表现：

```text
前端直接 shell
用户直接操作 Codex
没有状态机
没有日志
没有 diff
```

防范：

```text
所有执行进入 CodexJob
所有执行由 Runtime 调用
所有输出写入 event log / artifact
```

### 2.4 没有证据链

风险表现：

```text
任务 completed 但无法说明为什么完成
没有 verification
没有 proof
没有 review
```

防范：

```text
completed 必须有 verification report 和 proof-of-work
```

### 2.5 UI 设计先行导致流程弱

风险表现：

```text
界面好看但实体和流程不清楚
```

防范：

```text
先冻结实体、状态机和 API
UI 单独设计，但不得改变主链和边界
```

## 3. 防跑偏检查清单

每个功能进入 v1.1 前检查：

```text
1. 是否服务主链？
2. 是否创建或更新 PMOS 实体？
3. 是否有 nextSafeStep？
4. 是否有 evidence？
5. 是否经过 Runtime？
6. 是否保持 Codex 受控？
7. 是否支持 mock-first？
8. 是否能被验收命令覆盖？
```

## 4. 版本边界

### v1.1 必须完成

```text
Copilot-first shell
Agent Router
Dynamic Surface
PageSpec
CodexJob mock-first
状态机
events/logs
verification/proof mock
API skeleton
文档与验收
```

### v1.1 可选

```text
真实 Codex CLI 执行
真实 preview
真实 browser verification 自动触发
真实 version writeback 自动化
```

### v1.1.1 建议

```text
真实 Codex CLI 稳定执行
Desktop Shell
项目目录选择
本地权限提示
托盘入口
```

### v1.2 建议

```text
Workflow Canvas
多角色协作
更完整知识连接器
Coze Plugin
Gemini CLI executor
```

## 5. 最终原则

```text
Agent decides UI.
User stays in flow.
Runtime owns state.
Codex only executes.
Proof decides delivery.
```
