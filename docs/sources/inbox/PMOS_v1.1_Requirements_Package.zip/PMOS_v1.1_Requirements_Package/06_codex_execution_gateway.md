# 06. Codex Execution Gateway 需求

## 1. 定位

Codex CLI 是 PMOS 的受控执行器，不是用户直接操作的前台。

正确关系：

```text
PMOS Studio
→ PMOS Runtime
→ CodexExecutionService
→ Codex CLI
```

## 2. 目标

Codex Execution Gateway 必须实现：

```text
1. 创建 CodexJob
2. 校验工作目录和允许修改范围
3. 生成 Codex prompt
4. 调用 Codex CLI
5. 捕获 stdout / stderr
6. 记录 CodexJobEvent
7. 捕获 git diff
8. 运行 verification
9. 生成 proof 引用
10. 支持 approve / rework / cancel
```

## 3. 安全边界

禁止：

```text
前端直接执行 shell
前端传入任意命令直接运行
Codex 访问未授权路径
没有 allowedPaths 的写文件
没有 verification 的 completed
没有 proof 的 writeback
```

必须：

```text
1. 工作目录必须在允许 workspace 内
2. allowedPaths 必须显式声明
3. blockedPaths 默认包含 secrets、.env、私有记忆、系统目录
4. 所有命令必须进入 event log
5. 所有结果必须绑定 jobId
```

## 4. 执行模式

### plan-only

只让 Codex 生成计划，不改文件。

用途：

```text
需求澄清
实现方案
风险评估
```

### edit

允许 Codex 修改 allowedPaths 内的文件。

用途：

```text
普通开发任务
页面实现
重构
```

### full-auto-sandbox

允许更完整的自动执行，但必须运行在受控目录和受控命令集内。

用途：

```text
后续增强，不作为 v1.1 默认模式
```

## 5. Prompt 生成规则

Codex prompt 必须包含：

```text
1. PMOS v1.1 Design Constitution 摘要
2. 目标 PageSpec
3. linked Requirement
4. allowedPaths
5. blockedPaths
6. expectedFiles
7. verificationCommands
8. acceptanceCriteria
9. output expectations
10. 禁止直接跳过 proof / verification 的提醒
```

## 6. 日志与事件

必须记录：

```text
job_created
job_queued
job_started
prompt_prepared
codex_invoked
stdout
stderr
file_changed
diff_captured
command_started
command_completed
verification_started
verification_completed
approval_requested
approved
rework_requested
job_completed
job_failed
job_cancelled
```

## 7. Diff 捕获

CodexJob 执行后必须捕获：

```text
1. git status
2. changed files
3. diff summary
4. patch artifact path
5. 是否包含 blockedPaths
```

如果没有 diff，也必须生成 no-op 说明。

## 8. Verification

至少支持：

```text
npm run lint
npm run build
npm run test
npm run verify:frontend-browser
```

具体命令由 CodexJob.verificationCommands 指定，但必须经过 Runtime 白名单或配置校验。

## 9. Completion Gate

CodexJob 进入 completed 必须满足：

```text
1. 状态为 verifying 后通过验证
2. 有 event log
3. 有 diff summary 或 no-op reason
4. 有 verification report
5. 有 proof-of-work bundle
6. 有人工 approve 或 review decision
```

## 10. Rework

如果验证失败或用户 reject，必须进入：

```text
rework_required
```

并生成：

```text
failedChecks
reworkReason
suggestedNextAction
linkedPreviousJobId
```

## 11. v1.1 最小实现

v1.1 最小可接受版本：

```text
1. mock CodexJob 状态机完整
2. real Codex execution 可选，但接口预留
3. logs / events 可读
4. diff / verification / proof 可 mock
5. 禁止无状态直接 CLI
```

v1.1.1 或后续版本再增强真实执行稳定性。
