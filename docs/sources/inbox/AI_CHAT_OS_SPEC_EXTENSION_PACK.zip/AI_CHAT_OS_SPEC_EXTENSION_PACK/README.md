# AI Chat OS Specification Extension Pack

> 基于 `ENTERPRISE_AI_CHAT_OS_SPEC.md` 的下一阶段规范包。  
> 用途：补齐 Unified Semantic Contract、Action / Evidence / Source、Runtime Display Protocol、Component Registry / Renderer、AI Runtime UX、AI Trust UX、Frontend Engineering、Visual / Conversation / Input / Feedback 的落地文档与前端类型真源。

## 0. 包定位

本规范包不是新的顶层体系，不替代 `ENTERPRISE_AI_CHAT_OS_SPEC.md`。

它的职责是把总纲中的方向拆成可实施、可校验、可由 Codex CLI 遍历重构的二级规范与 TypeScript 类型落点。

```txt
Enterprise AI Chat OS
├─ 总纲：docs/architecture/ENTERPRISE_AI_CHAT_OS_SPEC.md
└─ 本扩展包：协议真源 + Runtime + Renderer + UX + Engineering 细则
```

## 1. 优先实施顺序

```txt
P0. Unified Semantic Contract 详细规范
P0. Action / Evidence / Source 三个统一子契约
P1. Runtime Display Protocol 详细规范
P1. Component Registry / Renderer 规范
P2. AI Runtime UX
P2. AI Trust UX
P2. Frontend Engineering System 细化
P3. Visual System 拆分
P3. Conversation UX / Input UX / Feedback UX
P3. Legacy Contract Mapping
```

## 2. 推荐放置路径

将本包内容复制到项目根目录后，推荐形成：

```txt
docs/
└─ architecture/
   ├─ ENTERPRISE_AI_CHAT_OS_SPEC.md
   ├─ 00_SPEC_INDEX.md
   ├─ semantic-contract/
   │  ├─ semantic-result-contract.md
   │  ├─ action-contract.md
   │  ├─ evidence-contract.md
   │  └─ source-contract.md
   ├─ runtime/
   │  └─ runtime-display-protocol.md
   ├─ frontend-engineering/
   │  ├─ component-registry-renderer.md
   │  └─ frontend-engineering-system.md
   ├─ interaction-system/
   │  ├─ ai-runtime-ux.md
   │  ├─ ai-trust-ux.md
   │  └─ conversation-input-feedback-ux.md
   ├─ visual-system/
   │  └─ visual-system-breakdown.md
   └─ migration/
      └─ legacy-contract-mapping.md

src/
└─ contracts/
   ├─ semantic/
   │  ├─ index.ts
   │  ├─ semantic-result-contract.ts
   │  ├─ action-contract.ts
   │  ├─ evidence-contract.ts
   │  └─ source-contract.ts
   ├─ runtime/
   │  ├─ index.ts
   │  └─ runtime-display-protocol.ts
   └─ renderer/
      ├─ index.ts
      └─ component-registry.ts
```

## 3. 核心收口原则

1. 凡是最终业务结果展示，必须进入 `SemanticResultContract`。
2. 凡是执行过程展示，必须进入 `RuntimeDisplayProtocol`。
3. 凡是具体展示形态，只能作为 `regions[].componentBinding` 的子规范。
4. 凡是用户可点击动作，只走 `ActionContract`。
5. 凡是结论、洞察、风险判断、建议、异常解释，必须挂 `EvidenceRef` / `SourceRef`。
6. 不允许 `ReportQueryViewModel`、`MetricExplainerUISchema`、`VizSpec`、`AgentProcessEvent` 各自发明独立 action、source、evidence、region 结构。

## 4. Codex CLI 推荐执行方式

第一轮只做类型与引用收口，不改视觉：

```txt
1. 搜索所有 ResponseContract / UISchema / ViewModel / VizSpec / ProcessEvent / Timeline 类型。
2. 标记是否属于 Result Plane、Runtime Plane、Renderer Plane 或纯业务 DTO。
3. 将最终前端展示结果统一映射到 SemanticResultContract。
4. 将用户动作统一映射到 ActionContract。
5. 将证据和来源统一映射到 EvidenceRef / SourceRef。
6. 将 AgentProcessEvent / process_events / Timeline 映射到 RuntimeDisplayProtocol。
7. 建立 Component Registry，不再让业务组件直接判断任意 schema。
```

第二轮再做 UI / UX / 性能重构：

```txt
1. Data Visualization 只作为 data-visualization renderer。
2. AI Runtime 只作为 ai-runtime / workflow-trace renderer。
3. 大表格、大图表、长会话、Artifact 全部按 frontend-engineering 规范改造。
4. Visual System token 化，禁止散落硬编码。
```
