# AI Chat OS Architecture Specification Index

> Canonical index for all Enterprise AI Chat OS architecture and implementation specifications.

## 1. 顶层总纲

| 文档 | 位置 | 角色 |
|---|---|---|
| Enterprise AI Chat OS 总纲 | `docs/architecture/ENTERPRISE_AI_CHAT_OS_SPEC.md` | 总体系、层级、边界、原则 |

## 2. P0：协议真源

| 文档 | 位置 | 角色 |
|---|---|---|
| Unified Semantic Contract | `docs/architecture/semantic-contract/semantic-result-contract.md` | 最终业务结果渲染协议 |
| Action Contract | `docs/architecture/semantic-contract/action-contract.md` | 用户动作统一协议 |
| Evidence Contract | `docs/architecture/semantic-contract/evidence-contract.md` | 证据统一协议 |
| Source Contract | `docs/architecture/semantic-contract/source-contract.md` | 来源统一协议 |

对应前端类型真源：

```txt
src/contracts/semantic/
```

## 3. P1：Runtime 与 Renderer

| 文档 | 位置 | 角色 |
|---|---|---|
| Runtime Display Protocol | `docs/architecture/runtime/runtime-display-protocol.md` | Agent / Tool / Workflow / Streaming 运行态展示协议 |
| Component Registry / Renderer | `docs/architecture/frontend-engineering/component-registry-renderer.md` | componentBinding 到 renderer 的工程规范 |

对应前端类型真源：

```txt
src/contracts/runtime/
src/contracts/renderer/
```

## 4. P2：体验与工程约束

| 文档 | 位置 | 角色 |
|---|---|---|
| AI Runtime UX | `docs/architecture/interaction-system/ai-runtime-ux.md` | 运行过程的用户体验规范 |
| AI Trust UX | `docs/architecture/interaction-system/ai-trust-ux.md` | 可信解释、证据、置信度、风险提示规范 |
| Frontend Engineering System | `docs/architecture/frontend-engineering/frontend-engineering-system.md` | 长会话、大表格、流式渲染、懒加载、可观测性约束 |

## 5. P3：基础体验域与迁移

| 文档 | 位置 | 角色 |
|---|---|---|
| Visual System Breakdown | `docs/architecture/visual-system/visual-system-breakdown.md` | 字体、颜色、图标、间距、动效、层级拆分 |
| Conversation / Input / Feedback UX | `docs/architecture/interaction-system/conversation-input-feedback-ux.md` | Chat OS 核心交互域 |
| Legacy Contract Mapping | `docs/architecture/migration/legacy-contract-mapping.md` | ResponseContract / MetricExplainerUISchema / VizSpec / AgentProcessEvent 映射规则 |

## 6. 总体依赖关系

```txt
Enterprise AI Chat OS Spec
        ↓
Unified Semantic Contract
        ↓
Action / Evidence / Source Contract
        ↓
Component Registry / Renderer
        ↓
Interaction UX + Frontend Engineering
```

Runtime 是并行协议线：

```txt
Runtime Display Protocol
        ↓
ai-runtime / workflow-trace renderer
        ↓
AI Runtime UX
```

## 7. 禁止事项

1. 禁止新增与 `SemanticResultContract` 平级竞争的最终 UI schema。
2. 禁止 renderer 私有定义 action、evidence、source。
3. 禁止 Runtime Trace 直接污染业务结果结构。
4. 禁止 Data Visualization UX 成为新的总协议。
5. 禁止 `VizSpec` 替代 `regions` / `componentBinding`。
6. 禁止图表、表格、报告、AI Insight 分别定义各自的导出、下钻、来源、证据结构。
