# Legacy Contract Mapping Specification

> Canonical path: `docs/architecture/migration/legacy-contract-mapping.md`  
> Scope: 旧协议、旧 ViewModel、旧 UI Schema 向 AI Chat OS 统一协议迁移的映射规则

## 1. 文档定位

本文件用于指导 Codex CLI 遍历项目中的旧结构，并迁移到：

```txt
SemanticResultContract
ActionContract
EvidenceRef
SourceRef
RuntimeDisplayProtocol
Component Registry
```

## 2. ResponseContract -> SemanticResultContract

### 2.1 文本回答

```txt
ResponseContract.content
ResponseContract.markdown
ResponseContract.answer
```

映射为：

```txt
regions[].componentBinding = "markdown-result"
regions[].type = "summary" 或 "primary-result"
```

### 2.2 结构化结果

```txt
ResponseContract.cards
ResponseContract.sections
ResponseContract.blocks
```

映射为：

```txt
SemanticResultContract.regions[]
```

### 2.3 动作

```txt
ResponseContract.actions
ResponseContract.buttons
ResponseContract.nextSteps
```

映射为：

```txt
ActionContract[]
```

### 2.4 来源与证据

```txt
ResponseContract.sources -> SourceRef[]
ResponseContract.evidence -> EvidenceRef[]
```

## 3. MetricExplainerUISchema -> SemanticResultContract

旧结构：

```txt
MetricExplainerUISchema
├─ metric
├─ explanation
├─ drivers
├─ charts
├─ table
├─ suggestions
└─ sources
```

新结构：

```txt
SemanticResultContract
├─ screenType = "metric-explainer"
├─ regions[]
│  ├─ markdown-result summary
│  ├─ data-visualization metric-card
│  ├─ data-visualization chart
│  ├─ data-visualization table
│  └─ action-bar
├─ evidenceRefs[]
└─ sourceRefs[]
```

规则：

1. `drivers` 必须变成 insight region，并挂 evidenceRefs。
2. `suggestions` 必须变成 ActionContract 或 markdown-result 的建议区。
3. 图表下钻不能留在 chart 私有 action。

## 4. VizSpec -> data-visualization region.data

`VizSpec` 不能替代 `SemanticResultContract`。

正确落点：

```txt
regions[].componentBinding = "data-visualization"
regions[].data = VizSpec-compatible local shape
```

示例：

```json
{
  "id": "region_cpa_chart",
  "type": "data-view",
  "componentBinding": "data-visualization",
  "data": {
    "kind": "line-chart",
    "metric": "CPA",
    "datasetRef": "artifact_dataset_001"
  }
}
```

规则：

1. `VizSpec.actions` 迁移为 `ActionContract[]`。
2. `VizSpec.sources` 迁移为 `SourceRef[]`。
3. `VizSpec.evidence` 迁移为 `EvidenceRef[]`。
4. `VizSpec` 只保留图表局部表达。

## 5. ReportQueryViewModel -> SemanticResultContract

旧结构常见字段：

```txt
query
result
tables
charts
filters
exports
sources
```

新结构：

```txt
screenType = "report-result"
regions:
  summary -> markdown-result
  filters -> form-input 或 action-bar
  tables -> data-visualization
  charts -> data-visualization
  export -> ActionContract(type=export)
  sources -> source-list
```

规则：

1. `filters` 的应用动作必须走 ActionContract。
2. `exports` 必须走 ActionContract(type=export)。
3. 数据来源进入 SourceRef。
4. 报告结论进入 EvidenceRef。

## 6. AgentProcessEvent -> RuntimeDisplayProtocol

旧结构：

```txt
AgentProcessEvent
process_events[]
TimelineItem
ToolCallEvent
```

映射：

```txt
AgentProcessEvent.id              -> RuntimeEvent.id
AgentProcessEvent.type            -> RuntimeEvent.type
AgentProcessEvent.status          -> RuntimeEvent.status
AgentProcessEvent.created_at      -> RuntimeEvent.timestamp
AgentProcessEvent.agent           -> AgentRuntimeState
AgentProcessEvent.tool            -> ToolCallState
AgentProcessEvent.workflow_step   -> WorkflowRuntimeState.steps[]
AgentProcessEvent.error           -> RuntimeError
```

规则：

1. Timeline UI 从 RuntimeEvent projection 生成。
2. 不得让 TimelineItem 成为新协议。
3. Runtime 产出的业务结果必须回写 SemanticResultContract。

## 7. Codex CLI 搜索关键词

```txt
ResponseContract
UISchema
ViewModel
MetricExplainer
VizSpec
ReportQuery
AgentProcessEvent
process_events
TimelineItem
ToolCall
source
sources
evidence
actions
buttons
nextSteps
```

## 8. 迁移优先级

```txt
P0 类型定义：src/contracts/*
P0 action/evidence/source 收口
P1 ResponseContract -> SemanticResultContract
P1 AgentProcessEvent -> RuntimeDisplayProtocol
P1 ComponentRegistry 接入
P2 MetricExplainer / ReportQuery / VizSpec 映射
P3 UI 视觉和交互细节调整
```

## 9. 验收清单

- [ ] 旧 UI schema 不再作为最终渲染总协议。
- [ ] 旧 actions 已迁移为 ActionContract。
- [ ] 旧 sources 已迁移为 SourceRef。
- [ ] 旧 evidence 已迁移为 EvidenceRef。
- [ ] 旧 process_events 已迁移为 RuntimeDisplayProtocol。
- [ ] VizSpec 只存在于 data-visualization region.data。
